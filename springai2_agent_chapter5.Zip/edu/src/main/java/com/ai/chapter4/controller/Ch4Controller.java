package com.ai.chapter4.controller;

import com.ai.chapter4.service.StrategicAnalysisAgentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

/**
 * Ch4Controller
 *
 * 📌 Chapter 4 — {@link StrategicAnalysisAgentService} 노출용 REST API
 *
 * 역할:
 * - Thymeleaf 실습 화면({@code pages/ch4/1_strategic_analysis})에서 호출
 * - 브라우저는 동일 {@code workflowId}로 SSE({@code /api/workflow/stream/{workflowId}})를 연 뒤 본 API를 호출해
 *   Redis에 발행된 단계 메시지를 실시간 표시
 *
 * 엔드포인트:
 * - {@code POST /ch4/strategic-analysis}
 *
 * 요청 (폼/urlencoded):
 * - {@code prompt} — 사용자 질문
 * - {@code workflowId} — UUID 문자열 (SSE 구독과 반드시 동일)
 *
 * 응답:
 * - {@code text/plain} 문자열 — 최종 보고서 또는 오류 메시지 (동기)
 */
@RestController
@RequestMapping("/ch4")
@Slf4j
@RequiredArgsConstructor
public class Ch4Controller {

    private final StrategicAnalysisAgentService strategicAnalysisAgentService;

    /**
     * strategic-analysis
     *
     * 📌 전략 분석 실행
     *
     * 처리 흐름(서비스 위임):
     *   1. Routing → 2. (STRATEGIC 시) 병렬 기술/시장 분석 → 3. Evaluator-Optimizer 루프
     *
     * @param userPrompt  사용자 입력
     * @param workflowId  SSE와 매칭되는 워크플로 UUID
     * @return 최종 문자열 응답
     */
    @PostMapping("/strategic-analysis")
    public String strategicAnalysis(
            @RequestParam("prompt") String userPrompt,
            @RequestParam String workflowId
    ) {
        UUID id = UUID.fromString(workflowId);
        log.info("Ch4 StrategicAnalysis(Agent) 요청: {}", userPrompt);
        return strategicAnalysisAgentService.executeWithMonitoring(id, userPrompt);
    }
}
