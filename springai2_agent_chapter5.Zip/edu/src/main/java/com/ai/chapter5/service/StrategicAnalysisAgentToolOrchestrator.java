package com.ai.chapter5.service;

import com.ai.chapter4.service.StrategicAnalysisAgentOrchestrator;
import com.ai.chapter5.tool.api.StrategicTool;
import com.ai.chapter5.tool.registry.ToolRegistry;
import com.ai.shared.agent.keys.StrategicAgentKeys;
import com.ai.shared.config.StrategicEvaluatorProperties;
import com.ai.shared.publisher.WorkflowStatusPublisher;
import com.ai.shared.util.EvaluationApprovalDecider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
/**
 * StrategicAnalysisAgentToolOrchestrator
 *
 * 📌 Chapter 5 — Tool-Orchestrated Multi-Agent 메인 오케스트레이터
 *
 * 아키텍처 개요:
 * 1️⃣ Router — {@link ToolRegistry}로 {@code routing} 도구 호출
 * 2️⃣ SIMPLE — {@code simple-query}로 단답 처리
 * 3️⃣ STRATEGIC — 병렬 분석(기술·시장) → Evaluator-Optimizer 루프
 *
 * 특징:
 * - “어떤 Tool을 언제 호출할지”는 본 클래스의 Java 코드가 결정 (LLM이 아님)
 * - 각 {@link StrategicTool} 내부에서 SubAgent로 LLM 호출
 * - 승인 임계점수는 {@link StrategicEvaluatorProperties}
 * - HTTP·{@code STARTED}/{@code AGENT} 래핑은 {@link StrategicAnalysisAgentToolService}
 *
 * 단계 의미는 {@link StrategicAnalysisAgentOrchestrator}와 동일합니다.
 */
@Service("ch5StrategicAnalysisOrchestrator")
@Slf4j
@RequiredArgsConstructor
public class StrategicAnalysisAgentToolOrchestrator {

    /** @see ToolRegistry — 이름 기반 StrategicTool 조회 */
    private final ToolRegistry toolRegistry;

    /** Redis/SSE 단계 발행 */
    private final WorkflowStatusPublisher statusPublisher;

    /** {@code strategic.evaluator.approval-threshold} 설정 */
    private final StrategicEvaluatorProperties evaluatorProperties;

    /**
     * 🧵 병렬 분석 전용 스레드 풀 ({@link Executors#newFixedThreadPool(int)} — 크기 4).
     *
     * <p><b>사용 이유</b>
     * <ul>
     *   <li>기술/시장 등 병렬 LLM 호출 시 공용 {@link java.util.concurrent.ForkJoinPool#commonPool()}에 부담을 주지 않고,
     *       I/O 블로킹이 있는 작업의 <strong>동시 실행 개수를 고정</strong>한다.</li>
     *   <li>싱글톤 서비스에서 공유되면 <strong>모든 HTTP 요청이 동일 풀을 사용</strong>한다.</li>
     * </ul>
     *
     * <p><b>부하·확장</b>: 동시에 처리할 수 있는 양은 코드와 인프라에서 함께 정하고, 넘치면
     * 거절·대기·수평 확장(인스턴스 증설) 등으로 다루는 것이 일반적이다.
     * 이 고정 풀은 <strong>애플리케이션 내부 병렬 단계의 동시 실행 상한</strong>만 나타내며,
     * 큐 적체 방지·전역 동시 요청 제한·타임아웃 등은 별도 설계가 필요할 수 있다.
     */
    private final ExecutorService analysisExecutor = Executors.newFixedThreadPool(4);

    /** 사용자 입력(trim) → SIMPLE / STRATEGIC — ROUTING Tool 재호출 생략 */
    private final Map<String, String> routingCategoryCache = new ConcurrentHashMap<>();

    /**
     * executeWithMonitoring
     *
     * 📌 Chapter 5 전략 분석 파이프라인 실행 (workflowId 단위)
     *
     * 처리 흐름:
     *   1. Routing
     *   2. Parallel Analysis
     *   3. Evaluator-Optimizer Loop
     *
     * @param workflowId 추적용 UUID
     * @param input      사용자 프롬프트
     * @return           최종 보고서 또는 오류 메시지
     */
    public String executeWithMonitoring(UUID workflowId, String input) {

        // =================================================
        // 🟡 1️⃣ Routing 단계
        // =================================================
        //
        // Chapter 3와 동일하게 SIMPLE / STRATEGIC 분기.
        // Chapter 5에서는 ToolRegistry 로 StrategicTool 이름(ROUTING 등)을 조회해 execute — 도구 내부에서 SubAgent LLM 호출.

        publishStatus(workflowId, "ROUTING", "질문 카테고리를 분석 중...");

        String category; // SIMPLE or STRATEGIC 저장 변수
        String cacheKey = input == null ? "" : input.trim();

        try {
            String cached = routingCategoryCache.get(cacheKey);
            if (cached != null) {
                category = cached;
                log.info("[{}] Routing 캐시 히트: {}", workflowId, category);
            } else {
                String routingRaw = toolRegistry.require(StrategicAgentKeys.ROUTING).execute(input);
                category = resolveRoutingCategory(routingRaw);
                routingCategoryCache.put(cacheKey, category);
                log.info("[{}] Routing 결과: {}", workflowId, category);
            }

        } catch (Exception e) {
            // Routing 실패 시 즉시 종료
            log.error("[{}] Routing 실패: {}", workflowId, e.getMessage(), e);
            publishStatus(workflowId, "ERROR", "Routing 단계 실패");
            return "Routing 단계 실패";
        }

        /**
         * SIMPLE 요청 처리 분기
         * - 추가 병렬 분석 없이 바로 응답 반환
         * - StrategicAgentKeys.SIMPLE_QUERY 도구 1회 호출
         */
        if ("SIMPLE".equalsIgnoreCase(category)) {
            try {
                String result = toolRegistry.require(StrategicAgentKeys.SIMPLE_QUERY).execute(input);

                publishStatus(workflowId, "COMPLETED", "단순 요청 처리 완료");
                return result;

            } catch (Exception e) {
                log.error("[{}] SIMPLE 처리 실패", workflowId, e);
                publishStatus(workflowId, "ERROR", "단순 요청 처리 실패");
                return "단순 요청 처리 실패";
            }
        }

        // =================================================
        // 🔵 2️⃣ Parallel Analysis 단계
        // =================================================

        publishStatus(workflowId, "ANALYZING", "기술 및 시장 데이터를 동시에 분석 중...");
        log.info("[{}] Parallel 분석 시작", workflowId);

        /**
         * 🔹 기술 분석 Future
         * - TECHNICAL_ANALYSIS 도구 (내부 SubAgent)
         * - analysisExecutor 사용
         */
        CompletableFuture<String> techFuture =
                CompletableFuture.supplyAsync(() -> {
                    try {
                        return toolRegistry.require(StrategicAgentKeys.TECHNICAL_ANALYSIS).execute(input);
                    } catch (Exception e) {
                        log.error("[{}] 기술 분석 실패", workflowId, e);
                        return "기술 분석 실패";
                    }
                }, analysisExecutor);

        /**
         * 🔹 시장 분석 Future
         * - MARKET_ANALYSIS 도구 (내부 SubAgent)
         */
        CompletableFuture<String> marketFuture =
                CompletableFuture.supplyAsync(() -> {
                    try {
                        return toolRegistry.require(StrategicAgentKeys.MARKET_ANALYSIS).execute(input);
                    } catch (Exception e) {
                        log.error("[{}] 시장 분석 실패", workflowId, e);
                        return "시장 분석 실패";
                    }
                }, analysisExecutor);

        String rawReport; // 병렬 분석 결과 저장 변수

        try {
            /**
             * thenCombine()
             * - 두 Future 완료 후 실행
             * - 기술 + 시장 분석 결합 (Chapter 3와 동일 문자열 형식)
             */
            rawReport = techFuture
                    .thenCombine(marketFuture, (tech, market) -> "기술분석: " + tech + "\n시장분석: " + market)
                    .join(); // blocking

            log.info("[{}] Parallel 분석 완료", workflowId);

        } catch (Exception e) {
            log.error("[{}] Parallel 처리 실패", workflowId, e);
            publishStatus(workflowId, "ERROR", "Parallel 분석 실패");
            return "병렬 분석 실패";
        }

        // =================================================
        // 🟣 3️⃣ Evaluator-Optimizer Loop
        // =================================================

        String finalReport = rawReport; // 반복 수정용 보고서 변수

        /**
         * 최대 4회 반복
         * - REPORT_EVALUATOR 도구로 평가
         * - EvaluationApprovalDecider + 임계점수로 승인 (Chapter 3의 "PASS" 검사와 대응)
         * - 미승인 시 REPORT_OPTIMIZER 도구가 2인자 execute(초안, 평가문)로 수정
         */
        for (int i = 1; i <= 4; i++) {

            publishStatus(workflowId, "EVALUATING", i + "차 검토 중...");
            log.info("[{}] Draft #{} 평가 시작", workflowId, i);

            String evaluation; // 평가 결과 저장

            try {
                evaluation = toolRegistry.require(StrategicAgentKeys.REPORT_EVALUATOR).execute(finalReport);

            } catch (Exception e) {
                log.error("[{}] 평가 실패", workflowId, e);
                publishStatus(workflowId, "ERROR", "평가 실패");
                break;
            }

            Integer score = EvaluationApprovalDecider.extractScore(evaluation);
            if (score != null) {
                publishStatus(workflowId, "EVALUATION_SCORE", i + "차 평가 점수: " + score + "점");
            } else {
                publishStatus(workflowId, "EVALUATION_SCORE", i + "차 평가 점수: 추출 실패");
            }

            if (shouldApproveEvaluation(evaluation)) {
                publishStatus(workflowId, "COMPLETED", "최종 승인 완료");
                log.info("[{}] Draft #{} 승인 완료", workflowId, i);
                break;
            }

            /**
             * Optimizer 단계
             * - 2인자 execute(초안, 평가문)
             */
            publishStatus(workflowId, "OPTIMIZING", "보고서 수정 중...");

            try {
                finalReport = toolRegistry.require(StrategicAgentKeys.REPORT_OPTIMIZER).execute(finalReport, evaluation);

            } catch (Exception e) {
                log.error("[{}] 수정 실패", workflowId, e);
                publishStatus(workflowId, "ERROR", "보고서 수정 실패");
                break;
            }
        }

        return finalReport;
    }

    /**
     * publishStatus
     *
     * 📌 Tool 기반 전략 분석 파이프라인 내부에서 공통으로 사용하는 상태 발행 메서드입니다.
     *
     * 기능:
     * - 현재 단계(step)와 설명 메시지를 {@link WorkflowStatusPublisher}를 통해 Redis Pub/Sub으로 발행합니다.
     * - 네트워크/Redis 오류로 상태 발행이 실패하더라도, 평가·개선 루프 등 메인 워크플로는 계속 진행되도록
     *   예외를 잡고 경고 로그만 남깁니다.
     *
     * @param workflowId 워크플로 추적용 UUID
     * @param step       예: {@code ROUTING}, {@code ANALYZING}, {@code EVALUATING}, {@code OPTIMIZING}, {@code COMPLETED}, {@code ERROR}
     * @param message    UI·운영자용 상태 설명 문자열
     */
    private void publishStatus(UUID workflowId, String step, String message) {
        try {
            statusPublisher.publishStatus(workflowId, step, message);
        } catch (Exception ex) {
            log.warn("[{}] 상태 발행 실패", workflowId, ex);
        }
    }

    /**
     * resolveRoutingCategory
     *
     * 📌 라우팅 Tool이 반환한 원문 문자열을 "SIMPLE" 또는 "STRATEGIC" 두 값 중 하나로 정규화합니다.
     *
     * 규칙:
     * - 대소문자와 주변 텍스트를 무시하고, "SIMPLE" 만 포함되고 "STRATEGIC" 이 없으면 SIMPLE
     * - "STRATEGIC" 이 포함되어 있으면 STRATEGIC
     * - 그 외(빈 문자열·예상치 못한 값)는 보수적으로 STRATEGIC 으로 간주합니다.
     *
     * @param raw 라우팅 Tool 원문 출력
     * @return    "SIMPLE" 또는 "STRATEGIC" 문자열
     */
    private String resolveRoutingCategory(String raw) {
        String upper = raw == null ? "" : raw.toUpperCase();
        if (upper.contains("SIMPLE") && !upper.contains("STRATEGIC")) {
            return "SIMPLE";
        }
        if (upper.contains("STRATEGIC")) {
            return "STRATEGIC";
        }
        return "STRATEGIC";
    }

    /**
     * shouldApproveEvaluation
     *
     * 📌 평가 도구가 반환한 평가 텍스트와 설정에 정의된 임계 점수를 기반으로 승인 여부를 판정합니다.
     *
     * 동작:
     * - {@link EvaluationApprovalDecider#shouldApprove(String, Integer)}에 평가 결과와
     *   {@link StrategicEvaluatorProperties#getApprovalThreshold()} 값을 넘겨 위임합니다.
     * - 점수 파싱 실패·임계값 미설정 등의 세부 규칙은 {@link EvaluationApprovalDecider} 구현을 따릅니다.
     *
     * @param evaluationText 평가 도구가 반환한 텍스트(점수·pass 여부·must_fix 포함)
     * @return               승인해야 하면 {@code true}, 재수정이 필요하면 {@code false}
     */
    private boolean shouldApproveEvaluation(String evaluationText) {
        return EvaluationApprovalDecider.shouldApprove(
                evaluationText,
                evaluatorProperties.getApprovalThreshold());
    }

    /**
     * shutdownExecutor
     *
     * 📌 애플리케이션 종료 시 병렬 분석용 스레드 풀을 정리(shutdown)합니다.
     *
     * 특징:
     * - {@link PreDestroy} 훅을 통해 컨테이너 종료 전에 호출되어,
     *   더 이상 새로운 작업을 받지 않고 현재 진행 중인 작업만 마무리하도록 합니다.
     * - 병렬 분석 전용 스레드의 누수·행잉을 방지합니다.
     */
    @PreDestroy
    public void shutdownExecutor() {
        analysisExecutor.shutdown();
    }

}
