package com.ai.chapter5.tool;

import com.ai.chapter5.tool.api.StrategicTool;
import com.ai.chapter5.tool.registry.ToolRegistry;
import com.ai.shared.agent.api.SubAgentRegistry;
import org.springframework.stereotype.Component;

/**
 * TechnicalAnalysisTool
 *
 * 📌 Chapter 5 — STRATEGIC 분기에서 "기술·아키텍처 관점 분석"을 담당하는 StrategicTool.
 *
 * 역할:
 * - {@link ToolRegistry} 에 {@code "technical-analysis"} 이름으로 등록됩니다.
 * - 실제 분석 생성은 {@link SubAgentRegistry} 를 통해
 *   같은 이름의 서브에이전트({@code strategic-tech.md})에 위임합니다.
 * - 스택 선택, 리스크, 구현 시 유의점, 트레이드오프 등을 정리해 보고서 초안의 기술 파트를 구성합니다.
 */
@Component
public class TechnicalAnalysisTool implements StrategicTool {

    private static final String TOOL_NAME = "technical-analysis";
    private final SubAgentRegistry subAgentRegistry;

    /**
     * TechnicalAnalysisTool
     *
     * 📌 기술 분석 전용 StrategicTool 인스턴스를 생성합니다.
     *
     * @param subAgentRegistry 기술 분석 서브에이전트를 이름으로 조회하는 레지스트리
     */
    public TechnicalAnalysisTool(SubAgentRegistry subAgentRegistry) {
        this.subAgentRegistry = subAgentRegistry;
    }

    @Override
    public String name() {
        return TOOL_NAME;
    }

    @Override
    public String description() {
        return "기술적 과제/해결 방향 분석";
    }

    /**
     * 기술 분석 페르소나·산출 범위를 도구에 두면, 병렬 호출되는 다른 분석 도구(시장 등)와
     * 프롬프트가 명확히 분리됩니다. 역할별로 프롬프트만 갈아끼우면 되므로 확장·튜닝이 안전하고,
     * 오케스트레이터는 "어떤 도구를 부를지"만 알면 됩니다.
     */
    @Override
    public String systemMessage() {
        return """
                당신은 시니어 기술 분석가입니다. 사용자 요청을 엔지니어링·아키텍처 관점에서 분석하세요. 스택 선택, 리스크, 구현 시 유의점, 트레이드오프를 다룹니다. 사용자가 다른 언어로 쓰지 않았다면 한국어로 작성합니다.
                """;
    }

    /**
     * execute
     *
     * 📌 STRATEGIC 분기에서 기술·아키텍처 관점의 분석 초안을 생성합니다.
     *
     * 동작:
     * - {@link SubAgentRegistry}에서 {@code "technical-analysis"} 서브에이전트를 조회하여
     *   {@link #systemMessage()}와 함께 호출합니다.
     * - 결과 텍스트는 병렬 분석 단계에서 시장 분석 결과와 함께 결합되어 최종 보고서의 일부가 됩니다.
     *
     * @param input 사용자 프롬프트 또는 상위 단계에서 가공한 입력
     * @return      기술 분석 결과 텍스트
     */
    @Override
    public String execute(String input) {
        return subAgentRegistry.require(name()).execute(input, systemMessage());
    }

}
