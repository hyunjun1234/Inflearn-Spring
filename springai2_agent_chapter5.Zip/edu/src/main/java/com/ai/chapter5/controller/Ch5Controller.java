package com.ai.chapter5.controller;

import com.ai.chapter5.service.StrategicAnalysisAgentToolService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

/**
 * Ch5Controller
 *
 * 📌 Chapter 5 — {@link StrategicAnalysisAgentToolService} 노출용 REST API
 *
 * 역할:
 * - Thymeleaf 실습 화면({@code pages/ch5/1_strategic_analysis})에서 호출
 * - 브라우저는 동일 {@code workflowId}로 SSE({@code /api/workflow/stream/{workflowId}})를 연 뒤 본 API를 호출하여
 *   Redis에 발행된 Tool-Orchestrated Multi-Agent 단계 메시지를 실시간으로 확인합니다.
 *
 * 엔드포인트:
 * - {@code POST /ch5/strategic-analysis}
 *
 * 요청 (폼/urlencoded):
 * - {@code prompt}    — 사용자 질문
 * - {@code workflowId} — UUID 문자열 (SSE 구독과 반드시 동일)
 *
 * 응답:
 * - {@code text/plain} 문자열 — Tool 기반 전략 분석의 최종 결과 또는 오류 메시지 (동기)
 */
@RestController
@RequestMapping("/ch5")
@Slf4j
@RequiredArgsConstructor
public class Ch5Controller {

    private final StrategicAnalysisAgentToolService strategicAnalysisAgentToolTaskService;

    /**
     * strategic-analysis
     *
     * 📌 Chapter 5 Tool-Orchestrated Multi-Agent 전략 분석 실행
     *
     * 처리 흐름(서비스 위임):
     *   1. Routing 도구로 SIMPLE/STRATEGIC 분기
     *   2. STRATEGIC 시 기술/시장 분석 Tool 조합 실행
     *   3. 평가/개선 Tool을 통한 최종 보고서 정리
     *
     * @param userPrompt  사용자 입력
     * @param workflowId  SSE와 매칭되는 워크플로 UUID
     * @return 최종 문자열 응답
     */
    @PostMapping("/strategic-analysis")
    public String strategicAnalysis(@RequestParam("prompt") String userPrompt, @RequestParam String workflowId) {
        UUID id = UUID.fromString(workflowId);
        log.info("Ch5 StrategicAnalysis(Tool) request: {}", userPrompt);
        return strategicAnalysisAgentToolTaskService.executeWithMonitoring(id, userPrompt);
    }
}