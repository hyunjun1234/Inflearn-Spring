package com.ai.chapter5.tool.api;

import com.ai.chapter5.tool.registry.ToolRegistry;
import com.ai.shared.agent.api.SubAgentRegistry;

/**
 * StrategicTool
 *
 * 📌 Chapter 5 — 오케스트레이터가 이름으로 조회하는 실행 단위 (≈ Spring AI @Tool 계층)
 *
 * 아키텍처 개요:
 * 1️⃣ {@link ToolRegistry}가 모든 빈을 {@link #name()} 맵으로 수집
 * 2️⃣ 오케스트레이터가 단계마다 {@code require(키)}로 조회 후 {@link #execute(String)} 호출
 *
 * 특징:
 * - 구현체는 보통 {@link SubAgentRegistry}에 LLM 호출 위임
 * - {@link #systemMessage()}가 비어 있지 않으면 서브에이전트 호출 시 시스템 프롬프트로 전달 가능
 */
public interface StrategicTool {

    /**
     * name
     *
     * 📌 ToolRegistry에서 이 도구를 식별할 때 사용하는 고유 이름입니다.
     *
     * 규칙:
     * - 예: {@code "routing"}, {@code "technical-analysis"}, {@code "market-analysis"} 등
     * - {@link ToolRegistry} 생성 시 키로 사용되며, 중복되면 애플리케이션 부팅이 실패합니다.
     *
     * @return 도구 식별용 이름 문자열
     */
    String name();

    /**
     * description
     *
     * 📌 문서·UI·로그 등에 노출할 수 있는 짧은 설명 텍스트입니다.
     *
     * 용도:
     * - Swagger/OpenAPI, 내부 관리 화면 등에서 각 도구의 역할을 요약해 보여줄 때 사용 가능합니다.
     * - 오케스트레이터 로직에는 직접 사용되지 않지만, 운영 시 “이 도구가 무엇을 하는지”를 빠르게 파악하는 데 도움을 줍니다.
     *
     * @return 사람 친화적인 도구 설명
     */
    String description();

    /**
     * systemMessage
     *
     * 📌 서브에이전트에 전달할 선택적 시스템 메시지입니다.
     *
     * 특징:
     * - 기본 구현은 빈 문자열을 반환하며, 필요 시 구현체에서 오버라이드합니다.
     * - 기술 분석/시장 분석/평가/개선 등 “역할·톤·출력 형식”을 고정하고 싶을 때, 이 메서드에
     *   프롬프트를 정의해 두고 서브에이전트 호출 시 함께 전달합니다.
     *
     * @return 서브에이전트 시스템 프롬프트(없으면 빈 문자열)
     */
    default String systemMessage() {
        return "";
    }

    /**
     * execute
     *
     * 📌 단일 입력(사용자 프롬프트 또는 이전 단계 산출물)을 받아 도구를 실행합니다.
     *
     * 사용 예:
     * - Routing, Simple Query, Technical / Market Analysis, Report Evaluator 등
     *   대부분의 도구가 이 시그니처를 기본 진입점으로 사용합니다.
     *
     * @param input 사용자 입력 또는 상위 단계에서 생성된 텍스트
     * @return      도구 실행 결과 문자열(보고서 조각, 평가 JSON 등)
     */
    String execute(String input);

    /**
     * execute (input, feedback)
     *
     * 📌 평가 피드백 등 2번째 인자가 필요한 도구용 확장 시그니처입니다(예: report-optimizer).
     *
     * 특징:
     * - 기본 구현은 {@link UnsupportedOperationException}을 던지며, 2인자가 필요한 도구만 오버라이드합니다.
     * - 예: 초안(report)과 평가 피드백(feedback)을 함께 받아 개선된 보고서를 생성하는 도구.
     *
     * @param input    주 입력(예: 현재 보고서 초안)
     * @param feedback 보조 입력(예: 평가 피드백, 검토 코멘트 등)
     * @return         도구 실행 결과 문자열
     * @throws UnsupportedOperationException 구현체가 2인자 호출을 지원하지 않는 경우
     */
    default String execute(String input, String feedback) {
        throw new UnsupportedOperationException("This tool does not support feedback input.");
    }
}
