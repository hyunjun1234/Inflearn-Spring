package com.ai.chapter5.tool;

import com.ai.chapter5.tool.registry.ToolRegistry;
import com.ai.shared.agent.api.SubAgentRegistry;
import com.ai.shared.config.StrategicEvaluatorProperties;
import com.ai.chapter5.tool.api.StrategicTool;
import com.ai.shared.util.EvaluationApprovalDecider;
import org.springframework.stereotype.Component;

/**
 * ReportEvaluatorTool
 *
 * 📌 Chapter 5 — 전략 보고서 초안을 채점하는 StrategicTool
 *
 * 아키텍처 개요:
 * 1️⃣ 오케스트레이터가 병합 초안을 {@link #execute(String)}에 전달
 * 2️⃣ 서브에이전트가 JSON(점수·pass 등) 또는 텍스트로 응답
 * 3️⃣ 승인 여부는 {@link EvaluationApprovalDecider} + {@link StrategicEvaluatorProperties}
 *
 * 특징:
 * - {@link ToolRegistry} 키 {@code "report-evaluator"}
 * - 실제 LLM 호출은 {@link SubAgentRegistry} → {@code strategic-evaluator.md}
 * - 시스템 프롬프트의 임계점수는 {@link StrategicEvaluatorProperties#getApprovalThreshold()}와 동기화
 */
@Component
public class ReportEvaluatorTool implements StrategicTool {

    private static final String TOOL_NAME = "report-evaluator";
    private final SubAgentRegistry subAgentRegistry;
    private final StrategicEvaluatorProperties evaluatorProperties;

    /**
     * ReportEvaluatorTool
     *
     * 📌 전략 보고서 평가용 Tool 인스턴스를 생성합니다.
     *
     * @param subAgentRegistry       평가 서브에이전트를 이름으로 조회하는 레지스트리
     * @param evaluatorProperties    평가 임계 점수 등 설정값을 담은 프로퍼티 객체
     */
    public ReportEvaluatorTool(
            SubAgentRegistry subAgentRegistry,
            StrategicEvaluatorProperties evaluatorProperties) {
        this.subAgentRegistry = subAgentRegistry;
        this.evaluatorProperties = evaluatorProperties;
    }

    @Override
    public String name() {
        return TOOL_NAME;
    }

    @Override
    public String description() {
        return "보고서 품질 평가 및 PASS 판정";
    }

    /**
     * 평가 기준·JSON 스키마·PASS 규칙을 도구에 두면 임계값({@link StrategicEvaluatorProperties})과
     * 같은 출처로 맞출 수 있고, 오케스트레이터는 초안만 넘기면 됩니다. 채점 로직 변경 시
     * 평가 도구만 수정하면 되어 회귀 범위가 작고, "평가 행동"을 도구 단위로 재사용하기 좋습니다.
     */
    @Override
    public String systemMessage() {
        int threshold = evaluatorProperties.getApprovalThreshold();
        return """
                당신은 전략 보고서 심사관입니다. 반드시 JSON 하나만 반환하세요(코드블록/설명문 금지).
                
                평가 항목(합계 100):
                - clarity: 0~25 (표현 명확성)
                - completeness: 0~35 (근거·범위 완결성)
                - feasibility: 0~40 (실행 가능성·로드맵·KPI)
                
                강제 감점 규칙:
                - 시장/기술 근거가 약하면 completeness를 최소 10점 이상 감점
                - 수익모델 수치(가정·단위·민감도)가 없으면 feasibility를 최소 10점 이상 감점
                - 리스크/대응전략이 없으면 completeness를 최소 8점 이상 감점
                - 실행 로드맵(단계·기간·KPI)이 없으면 feasibility를 최소 8점 이상 감점
                
                점수 캘리브레이션:
                - 치명적 결함 1개라도 있으면 total_score는 84점 초과 금지
                - 중대한 결함 2개 이상이면 total_score는 74점 초과 금지
                - 모든 항목이 구체적 근거로 충족될 때만 90점 이상 허용
                
                PASS 규칙:
                - total_score >= %d 이고 must_fix가 비어 있을 때만 pass=true
                - 그 외에는 pass=false
                
                반드시 아래 스키마로만 응답:
                {"clarity":int,"completeness":int,"feasibility":int,"total_score":int,"pass":boolean,"must_fix":["..."],"reasons":["..."]}
                """.formatted(threshold);
    }

    /**
     * execute
     *
     * 📌 병합된 전략 보고서 초안을 입력으로 받아, 서브에이전트를 통해 점수·PASS 여부를 평가합니다.
     *
     * 동작:
     * - {@link SubAgentRegistry}에서 {@code "report-evaluator"} 서브에이전트를 조회해
     *   {@link #systemMessage()}와 함께 호출합니다.
     * - 반환 값은 JSON 문자열 형식(점수·pass·must_fix 등)이며,
     *   오케스트레이터에서 {@link EvaluationApprovalDecider}로 해석·판단에 사용됩니다.
     *
     * @param report 기술·시장 분석을 병합한 보고서 초안 텍스트
     * @return       평가 결과 JSON 문자열
     */
    @Override
    public String execute(String report) {
        return subAgentRegistry.require(name()).execute(report, systemMessage());
    }

}
