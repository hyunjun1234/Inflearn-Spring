package com.ai.chapter5.tool.registry;

import com.ai.chapter5.tool.api.StrategicTool;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * ToolRegistry
 *
 * 📌 Chapter 5 — 등록된 모든 {@link StrategicTool} 빈을 이름으로 조회
 *
 * 아키텍처 개요:
 * 1️⃣ Spring이 주입한 {@code List<StrategicTool>}을 맵으로 변환
 * 2️⃣ 오케스트레이터는 {@link #require(String)}으로만 단계 실행
 *
 */
@Component
public class ToolRegistry {

    private final Map<String, StrategicTool> byName;

    /**
     * ToolRegistry
     *
     * 📌 애플리케이션에 등록된 모든 {@link StrategicTool} 빈을 이름 기준 맵으로 구축하는 생성자입니다.
     *
     * 동작:
     * - 주입된 {@code List<StrategicTool>}을 순회하면서 {@link StrategicTool#name()} 값을 키로 사용해
     *   변경 불가능한 맵을 만듭니다.
     * - 이름이 중복될 경우 {@link IllegalStateException}을 발생시켜, 부팅 시점에 문제를 조기에 발견합니다.
     *
     * @param tools 컨테이너에 등록된 모든 StrategicTool 구현체 목록
     */
    public ToolRegistry(List<StrategicTool> tools) {
        this.byName = tools.stream()
                .collect(Collectors.toUnmodifiableMap(
                        StrategicTool::name,
                        Function.identity(),
                        (a, b) -> {
                            throw new IllegalStateException(
                                    "중복된 StrategicTool 이름: " + a.name());
                        }));
    }

    /**
     * require
     *
     * 📌 이름으로 {@link StrategicTool}을 조회하고, 없으면 예외를 던집니다.
     *
     * @return    조회된 StrategicTool 구현체
     * @throws IllegalArgumentException 등록되지 않은 이름인 경우
     */
    public StrategicTool require(String name) {
        StrategicTool tool = byName.get(name);
        if (tool == null) {
            throw new IllegalArgumentException(
                    "등록되지 않은 Tool: " + name + ", 등록된 이름=" + byName.keySet());
        }
        return tool;
    }
}
