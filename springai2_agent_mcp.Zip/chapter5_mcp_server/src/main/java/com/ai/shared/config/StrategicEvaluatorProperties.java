package com.ai.shared.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * {@code strategic.evaluator.approval-threshold} 바인딩.
 * 보고서 평가 텍스트에서 추출한 점수가 이 값 이상이면 승인으로 처리합니다.
 */
@Component
@ConfigurationProperties(prefix = "strategic.evaluator")
public class StrategicEvaluatorProperties {

    /** 0–100, 기본 75 */
    private int approvalThreshold = 75;

    public int getApprovalThreshold() {
        return approvalThreshold;
    }

    public void setApprovalThreshold(int approvalThreshold) {
        this.approvalThreshold = approvalThreshold;
    }
}
