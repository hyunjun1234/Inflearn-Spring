package com.ai.shared.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.google.genai.GoogleGenAiChatModel;
import org.springframework.ai.ollama.OllamaChatModel;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Spring AI {@link ChatClient} 빈 — SubAgent 구현체에서 {@link Qualifier}로 주입받아 호출합니다.
 * <p>
 * 모델별 API 키·엔드포인트는 {@code application.yml} 및 환경 변수(또는 .env)를 따릅니다.
 */
@Configuration
@Slf4j
public class ChatClientConfig {

    /** OpenAI 계열 호출용 */
    @Bean
    @Qualifier("gpt")
    public ChatClient openAiChatClient(OpenAiChatModel openAiChatModel) {
        return ChatClient.builder(openAiChatModel)
                .defaultSystem("당신은 OpenAI가 제공하는 친절한 AI 조수입니다.")
                .build();
    }

    /** Google Gemini 호출용 */
    @Bean
    @Qualifier("gemini")
    public ChatClient geminiChatClient(GoogleGenAiChatModel googleGenAiChatModel) {
        return ChatClient.builder(googleGenAiChatModel)
                .defaultSystem("당신은 Google의 Gemini 모델을 기반으로 한 전문가입니다.")
                .build();
    }

    /** 로컬 Ollama(Llama 등) 호출용 */
    @Bean
    @Qualifier("llama")
    public ChatClient llamaClient(OllamaChatModel model) {
        log.info("Llama Chat Client(ChatClientConfig)");
        return ChatClient.builder(model)
                .defaultSystem("당신은 로컬에서 구동되는 Llama 3.2 모델입니다.")
                .build();
    }
}
