package com.ai.shared.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.core.json.JsonReadFeature;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * EvaluationApprovalDecider
 *
 * 📌 LLM 평가 텍스트(JSON/자연어)에서 점수를 추출하고 승인 여부를 판정하는 유틸리티입니다.
 */
public final class EvaluationApprovalDecider {

    private static final Pattern LABELED_SCORE_PATTERN = Pattern.compile(
            "(?:평가\\s*점수|평가점수|점수|총점|score)\\s*[:=]?\\s*(?:는|은|이|가)?\\s*\\**\\s*(100|[1-9]?\\d)(?!\\d)"
                    + "\\s*\\**\\s*(?:/\\s*100|점)?",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern JSON_SCORE_PATTERN = Pattern.compile(
            "[\"']?(?:score|total_score|totalScore|evaluationScore|평가점수)[\"']?\\s*[:=]\\s*(100|[1-9]?\\d)(?!\\d)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern RELAXED_AFTER_LABEL_PATTERN = Pattern.compile(
            "(?:평가\\s*점수|평가점수|총점|score)\\s*[:=]\\s*[^0-9]{0,120}?(100|[1-9]?\\d)(?!\\d)(?:\\s*점|\\s*/\\s*100)?",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern FRACTION_SCORE_PATTERN =
            Pattern.compile("(?<!\\d)(100|[1-9]?\\d)(?!\\d)\\s*/\\s*100");
    private static final Pattern KOREAN_POINT_SCORE_PATTERN =
            Pattern.compile("(?<!\\d)(100|[1-9]?\\d)(?!\\d)\\s*점");

    /**
     * JSON 바깥 설명·코드펜스가 있어도 {@code total_score} 등을 잡기 위한 완화 패턴
     * (키 뒤 줄바꿈·공백·콜론 변형 허용, 끝 {@code \\b} 생략).
     */
    private static final Pattern TOTAL_SCORE_INLINE_PATTERN = Pattern.compile(
            "(?:total_score|totalScore|evaluationScore)\\s*[:=]\\s*(100|[1-9]?\\d)(?!\\d)",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    /** {@code total_score} 가 문자열이거나 소수인 경우 */
    private static final Pattern TOTAL_SCORE_STRING_OR_FLOAT_PATTERN = Pattern.compile(
            "(?:total_score|totalScore|evaluationScore)\\s*[:=]\\s*"
                    + "(?:\"(\\d+(?:\\.\\d+)?)\"|'(\\d+(?:\\.\\d+)?)'|(\\d+(?:\\.\\d+)?))",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    /** 따옴표 있는 루브릭 필드 (엄격 JSON) */
    private static final Pattern RUBRIC_CLARITY_PATTERN =
            Pattern.compile("\"clarity\"\\s*:\\s*(\\d+(?:\\.\\d+)?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern RUBRIC_COMPLETENESS_PATTERN =
            Pattern.compile("\"completeness\"\\s*:\\s*(\\d+(?:\\.\\d+)?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern RUBRIC_FEASIBILITY_PATTERN =
            Pattern.compile("\"feasibility\"\\s*:\\s*(\\d+(?:\\.\\d+)?)", Pattern.CASE_INSENSITIVE);

    /**
     * 따옴표 없는 JS 스타일 객체 ({@code clarity: 20}) — 일부 모델이 이렇게만 출력.
     */
    private static final Pattern UNQUOTED_CLARITY_PATTERN =
            Pattern.compile("(?i)\\bclarity\\s*:\\s*(\\d+(?:\\.\\d+)?)");
    private static final Pattern UNQUOTED_COMPLETENESS_PATTERN =
            Pattern.compile("(?i)\\bcompleteness\\s*:\\s*(\\d+(?:\\.\\d+)?)");
    private static final Pattern UNQUOTED_FEASIBILITY_PATTERN =
            Pattern.compile("(?i)\\bfeasibility\\s*:\\s*(\\d+(?:\\.\\d+)?)");

    /** ``` 또는 ```json 으로 감싼 블록 */
    private static final Pattern MARKDOWN_FENCE_PATTERN =
            Pattern.compile("(?is)```(?:json)?\\s*\\R?(.*?)\\R?```");

    /** Standalone English PASS verdict (avoids PASSWORD, PASSED, etc.). */
    private static final Pattern PASS_AS_WORD =
            Pattern.compile("\\bPASS\\b", Pattern.CASE_INSENSITIVE);

    /**
     * 긍정 “통과”만 인정 ({@code 미통과}, {@code 불통과}, {@code 비통과} 등 부정형 제외).
     * 뒤에 조사/어미(통과함, 통과합니다)가 와도 인정합니다.
     */
    private static final Pattern PASSED_KOREAN =
            Pattern.compile("(?<!미)(?<!불)(?<!비)통과");

    /** 따옴표 없는 필드·후행 쉼표 등 관대하게 파싱 */
    private static final ObjectMapper LENIENT_JSON = JsonMapper.builder()
            .enable(JsonReadFeature.ALLOW_UNQUOTED_FIELD_NAMES)
            .enable(JsonReadFeature.ALLOW_SINGLE_QUOTES)
            .enable(JsonReadFeature.ALLOW_TRAILING_COMMA)
            .build();

    /** 표준 JSON용 (유효한 RFC JSON 응답 전용) */
    private static final ObjectMapper STRICT_JSON = new ObjectMapper();

    private EvaluationApprovalDecider() {
    }

    /**
     * 평가 텍스트와 임계 점수를 기반으로 승인 여부를 판정합니다.
     *
     * 규칙:
     * - 점수 추출에 성공하면 숫자만 사용: {@code score >= scoreThreshold} 일 때만 승인
     * - 점수 추출 실패 시에만 보조 규칙: 단어 단위 {@code PASS} 또는 독립된 {@code 통과}가 있으면 승인
     *
     * @param evaluationText 평가 결과 텍스트
     * @param scoreThreshold 승인 임계 점수(0~100)
     * @return               승인 조건을 만족하면 {@code true}, 아니면 {@code false}
     */
    public static boolean shouldApprove(String evaluationText, int scoreThreshold) {
        if (evaluationText == null || evaluationText.isBlank()) {
            return false;
        }

        Integer score = extractScore(evaluationText);
        if (score != null) {
            return score >= scoreThreshold;
        }

        return PASS_AS_WORD.matcher(evaluationText).find()
                || PASSED_KOREAN.matcher(evaluationText).find();
    }

    /**
     * 평가 텍스트에서 0~100 점수를 추출합니다.
     *
     * 전략:
     * - BOM·유니코드 따옴표 정규화, 마크다운 코드 펜스 제거, JSON 객체 부분 문자열 후보 나열
     * - 정규식 + Jackson(관대 모드·엄격 모드) 병행
     *
     * @param evaluation 평가 결과 텍스트
     * @return           추출된 점수 또는 {@code null}
     */
    public static Integer extractScore(String evaluation) {
        if (evaluation == null || evaluation.isBlank()) {
            return null;
        }
        String normalized = normalizeEvaluatorPayload(evaluation);

        for (String candidate : buildScoreCandidates(normalized)) {
            Integer v = extractScoreFromText(candidate);
            if (v != null) {
                return v;
            }
            v = extractScoreFromJson(candidate, LENIENT_JSON);
            if (v != null) {
                return v;
            }
            v = extractScoreFromJson(candidate, STRICT_JSON);
            if (v != null) {
                return v;
            }
        }

        return null;
    }

    /** 원문·펜스 제거·중괄호 구간 등 중복 없이 순서대로 시도 */
    private static List<String> buildScoreCandidates(String normalized) {
        Set<String> ordered = new LinkedHashSet<>();
        ordered.add(normalized);

        String unfenced = stripMarkdownCodeFence(normalized);
        ordered.add(unfenced);

        String b1 = extractBracedJson(normalized);
        if (b1 != null) {
            ordered.add(b1);
        }
        String b2 = extractBracedJson(unfenced);
        if (b2 != null) {
            ordered.add(b2);
        }

        List<String> list = new ArrayList<>();
        for (String s : ordered) {
            if (s != null && !s.isBlank()) {
                list.add(s);
            }
        }
        return list;
    }

    private static Integer extractScoreFromJson(String text, ObjectMapper mapper) {
        if (text == null || text.isBlank()) {
            return null;
        }
        String payload = text.trim();
        if (!payload.startsWith("{") && !payload.startsWith("[")) {
            String braced = extractBracedJson(payload);
            if (braced != null) {
                payload = braced;
            }
        }
        if (!payload.startsWith("{") && !payload.startsWith("[")) {
            return null;
        }
        try {
            JsonNode n = mapper.readTree(payload);
            if (n.has("total_score")) {
                int r = (int) Math.round(n.get("total_score").asDouble());
                if (r >= 0 && r <= 100) {
                    return r;
                }
            }
            if (n.has("clarity") && n.has("completeness") && n.has("feasibility")) {
                int sum = (int) Math.round(
                        n.get("clarity").asDouble()
                                + n.get("completeness").asDouble()
                                + n.get("feasibility").asDouble());
                if (sum >= 0 && sum <= 100) {
                    return sum;
                }
            }
        } catch (Exception ignored) {
            // 다음 후보 또는 정규식으로 계속
        }
        return null;
    }

    private static Integer extractScoreFromText(String text) {
        Integer v = parseFirstValid(LABELED_SCORE_PATTERN, text);
        if (v != null) {
            return v;
        }
        v = parseFirstValid(JSON_SCORE_PATTERN, text);
        if (v != null) {
            return v;
        }
        v = parseFirstValid(TOTAL_SCORE_INLINE_PATTERN, text);
        if (v != null) {
            return v;
        }
        v = parseTotalScoreStringOrFloat(text);
        if (v != null) {
            return v;
        }
        v = parseFirstValid(RELAXED_AFTER_LABEL_PATTERN, text);
        if (v != null) {
            return v;
        }
        v = parseFirstValid(FRACTION_SCORE_PATTERN, text);
        if (v != null) {
            return v;
        }
        v = sumRubricScoresQuoted(text);
        if (v != null) {
            return v;
        }
        v = sumRubricScoresUnquoted(text);
        if (v != null) {
            return v;
        }
        return parseFirstValid(KOREAN_POINT_SCORE_PATTERN, text);
    }

    /** {@code "total_score":"72"} 또는 {@code total_score: 72.4} */
    private static Integer parseTotalScoreStringOrFloat(String text) {
        Matcher m = TOTAL_SCORE_STRING_OR_FLOAT_PATTERN.matcher(text);
        while (m.find()) {
            String raw = m.group(1);
            if (raw == null) {
                raw = m.group(2);
            }
            if (raw == null) {
                raw = m.group(3);
            }
            if (raw == null) {
                continue;
            }
            try {
                double d = Double.parseDouble(raw);
                int rounded = (int) Math.round(d);
                if (rounded >= 0 && rounded <= 100) {
                    return rounded;
                }
            } catch (NumberFormatException ignored) {
                // next match
            }
        }
        return null;
    }

    private static Integer sumRubricScoresQuoted(String text) {
        return sumThree(RUBRIC_CLARITY_PATTERN, RUBRIC_COMPLETENESS_PATTERN, RUBRIC_FEASIBILITY_PATTERN, text);
    }

    private static Integer sumRubricScoresUnquoted(String text) {
        return sumThree(UNQUOTED_CLARITY_PATTERN, UNQUOTED_COMPLETENESS_PATTERN, UNQUOTED_FEASIBILITY_PATTERN, text);
    }

    private static Integer sumThree(Pattern p1, Pattern p2, Pattern p3, String text) {
        Double c = matchFirstDouble(p1, text);
        Double co = matchFirstDouble(p2, text);
        Double f = matchFirstDouble(p3, text);
        if (c == null || co == null || f == null) {
            return null;
        }
        int sum = (int) Math.round(c + co + f);
        if (sum >= 0 && sum <= 100) {
            return sum;
        }
        return null;
    }

    private static Double matchFirstDouble(Pattern pattern, String text) {
        Matcher m = pattern.matcher(text);
        if (!m.find()) {
            return null;
        }
        try {
            return Double.parseDouble(m.group(1));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** ``` / ```json 펜스가 있으면 내부만 남깁니다(JSON·total_score 포함 블록 우선). */
    private static String stripMarkdownCodeFence(String s) {
        Matcher m = MARKDOWN_FENCE_PATTERN.matcher(s);
        String firstCandidate = null;
        while (m.find()) {
            String inner = m.group(1).trim();
            if (inner.startsWith("{") || inner.contains("total_score") || inner.contains("totalScore")) {
                return inner;
            }
            if (firstCandidate == null) {
                firstCandidate = inner;
            }
        }
        return firstCandidate != null ? firstCandidate : s;
    }

    /** 첫 '{' 부터 마지막 '}' 까지 잘라 JSON 유사 구간만 씁니다(서술형 앞뒤 제거). */
    private static String extractBracedJson(String s) {
        int start = s.indexOf('{');
        int end = s.lastIndexOf('}');
        if (start < 0 || end <= start) {
            return null;
        }
        return s.substring(start, end + 1);
    }

    /**
     * 평가 응답 정규화: BOM 제거, 스마트 따옴표 → ASCII, 전각 숫자 → 반각.
     */
    private static String normalizeEvaluatorPayload(String s) {
        String t = s.trim();
        if (!t.isEmpty() && t.charAt(0) == '\uFEFF') {
            t = t.substring(1).trim();
        }
        t = t.replace('\u201c', '"').replace('\u201d', '"');
        t = t.replace('\u2018', '\'').replace('\u2019', '\'');
        return normalizeFullWidthDigits(t);
    }

    /**
     * 전각 숫자를 반각 숫자로 치환해 정규식 매칭을 안정화합니다.
     *
     * @param s 원본 문자열
     * @return  전각 숫자가 반각으로 치환된 문자열
     */
    private static String normalizeFullWidthDigits(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '０' && c <= '９') {
                sb.append((char) ('0' + (c - '０')));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /**
     * 주어진 패턴으로 첫 번째 유효한(0~100) 점수를 찾습니다.
     *
     * @param pattern 점수 추출용 정규식 패턴
     * @param text    검사할 문자열
     * @return        유효 점수 또는 {@code null}
     */
    private static Integer parseFirstValid(Pattern pattern, String text) {
        Matcher matcher = pattern.matcher(text);
        while (matcher.find()) {
            try {
                int n = Integer.parseInt(matcher.group(1));
                if (n >= 0 && n <= 100) {
                    return n;
                }
            } catch (NumberFormatException ignored) {
                // next match
            }
        }
        return null;
    }
}
