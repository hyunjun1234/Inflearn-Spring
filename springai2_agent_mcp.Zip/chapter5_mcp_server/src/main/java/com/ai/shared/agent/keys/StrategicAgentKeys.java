package com.ai.shared.agent.keys;

import com.ai.shared.agent.api.SubAgentRegistry;

/**
 * 전략 분석 에이전트 계열(Chapter 4~7)에서 공통으로 사용하는 단계/역할 키 모음입니다.
 * <p>
 * - Chapter 4: {@link SubAgentRegistry} 에 등록되는 SubAgent 키<br>
 * - Chapter 5 (본 MCP 서버): {@code StrategicTool#name()} 및 동일 키로 SubAgent 위임<br>
 * - Chapter 6~7: 동일 의미의 Task / 노드 이름과 매핑됩니다.
 */
public final class StrategicAgentKeys {

    /** 라우팅 단계 — SIMPLE / STRATEGIC 분기 */
    public static final String ROUTING = "routing";
    public static final String SIMPLE_QUERY = "simple-query";
    public static final String TECHNICAL_ANALYSIS = "technical-analysis";
    public static final String MARKET_ANALYSIS = "market-analysis";
    public static final String REPORT_EVALUATOR = "report-evaluator";
    public static final String REPORT_OPTIMIZER = "report-optimizer";

    /** 유틸리티 클래스 — 인스턴스화 금지 */
    private StrategicAgentKeys() {
    }
}

