package com.ai.mcp.tools;

import com.ai.chapter5.service.StrategicAnalysisAgentToolService;
import com.ai.shared.util.ModelContentPlainTextExtractor;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * MCP에 노출하는 Chapter 5 도구. 내부적으로 edu 강의와 동일한
 * {@link StrategicAnalysisAgentToolService} 파이프라인을 호출합니다.
 *
 * @apiNote 이 모듈은 HTTP 컨트롤러 없이 MCP STDIO로만 진입합니다. edu가 자식 프로세스로 기동할 때
 *           동일 JAR이 실행됩니다.
 */
@Service
public class Chapter5McpToolService {

    private final StrategicAnalysisAgentToolService strategicAnalysisAgentToolService;

    public Chapter5McpToolService(@Lazy StrategicAnalysisAgentToolService strategicAnalysisAgentToolService) {
        this.strategicAnalysisAgentToolService = strategicAnalysisAgentToolService;
    }

    @Tool(description = """
            Chapter 5 Tool-Orchestrated Multi-Agent 전략 분석을 실행합니다.
            라우팅(SIMPLE/STRATEGIC) → STRATEGIC 시 기술·시장 병렬 분석 → 평가·최적화 루프까지 포함한 최종 보고서(또는 단순 응답) 문자열을 반환합니다.
            workflowId는 edu 등 클라이언트가 SSE 구독과 맞추기 위해 전달하는 UUID 문자열입니다. 비우면 서버가 임의 UUID를 사용합니다.
            """)
    public String strategic_analysis(String userPrompt, String workflowId) {
        UUID id = parseOrRandomWorkflowId(workflowId);
        return ModelContentPlainTextExtractor.unwrap(
                strategicAnalysisAgentToolService.executeWithMonitoring(id, userPrompt));
    }

    private static UUID parseOrRandomWorkflowId(String workflowId) {
        if (workflowId == null || workflowId.isBlank()) {
            return UUID.randomUUID();
        }
        try {
            return UUID.fromString(workflowId.trim());
        } catch (IllegalArgumentException e) {
            return UUID.randomUUID();
        }
    }
}
