package com.ai.mcp.config;

import com.ai.mcp.tools.Chapter5McpToolService;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * MCP 서버에 노출할 도구 콜백을 등록합니다.
 * <p>
 * {@link Chapter5McpToolService}의 {@code @Tool} 메서드가 MCP 클라이언트에 스키마로 노출됩니다.
 */
@Configuration
public class McpChapter5ToolConfig {

    @Bean
    public MethodToolCallbackProvider chapter5McpTools(Chapter5McpToolService chapter5McpToolService) {
        return MethodToolCallbackProvider.builder()
                .toolObjects(chapter5McpToolService)
                .build();
    }
}
