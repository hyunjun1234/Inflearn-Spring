package com.ai.mcp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * chapter5_mcp_server 진입점.
 * <p>
 * 웹 서버 없이 MCP STDIO 서버만 기동합니다. 부모 프로세스(edu MCP 클라이언트)가
 * {@code java -jar …chapter5_mcp_server-….jar} 로 띄우며, 표준 입출력으로 MCP 세션을 맺습니다.
 */
@SpringBootApplication(scanBasePackages = "com.ai")
public class McpChapter5Application {

    public static void main(String[] args) {
        SpringApplication.run(McpChapter5Application.class, args);
    }
}
