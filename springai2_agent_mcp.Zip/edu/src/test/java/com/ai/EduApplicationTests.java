package com.ai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/** Spring 컨텍스트 기동 스모크 테스트(MCP 비활성 프로파일). */
@SpringBootTest
@ActiveProfiles("test")
class EduApplicationTests {

    @Test
    void contextLoads() {
        // 빈 로드만 검증; 외부 MCP·Redis는 application-test.yml 로 최소화
    }

}
