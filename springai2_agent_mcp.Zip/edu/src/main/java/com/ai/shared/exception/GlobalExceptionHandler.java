package com.ai.shared.exception;


import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.net.ConnectException;

/**
 * REST API 전역 예외 처리 — 메시지 문자열을 그대로 반환(간단한 실습용).
 * <p>프로덕션에서는 상태 코드·본문 구조를 통일하는 편이 좋습니다.
 */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(Exception.class)
    public String handleException(Exception ex) {
        return ex.getMessage();
    }

    @ExceptionHandler(ConnectException.class)
    public String handleConnectException(Exception ex) {
        return ex.getMessage();
    }
}
