package com.ai.shared.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Thymeleaf 페이지 라우팅 — {@code layout/main}에 left/center 또는 {@code pages/...} 조각을 끼웁니다.
 */
@Controller
@Slf4j
public class MainController {

    /** 홈: 왼쪽 메뉴 {@code main}, 본문 {@code fragments/main}. */
    @GetMapping("/")
    public String main(Model model){
        model.addAttribute("left", "main");
        model.addAttribute("center", "fragments/main");
        return "layout/main";
    }

    /** 챕터 목차만: {@code fragments/{chapter}} 를 center에 삽입 (예: ch1, ch2, ch5, ch6). */
    @GetMapping("/go/{chapter}")
    public String page(Model model, @PathVariable(name = "chapter") String chapter ){
        model.addAttribute("left", chapter);
        model.addAttribute("center", "fragments/"+chapter);
        return "layout/main";
    }

    /** 실습·설정 페이지: {@code pages/{chapter}/{content}} 를 전체 본문으로 로드. */
    @GetMapping("/go/{chapter}/{content}")
    public String content(Model model, @PathVariable(name = "content") String content, @PathVariable(name = "chapter") String chapter ){
        model.addAttribute("left", chapter);
        model.addAttribute("page", "pages/"+chapter+"/"+content);
        return "layout/main";
    }

}