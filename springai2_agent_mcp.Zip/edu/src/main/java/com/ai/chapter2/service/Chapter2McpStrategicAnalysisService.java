package com.ai.chapter2.service;

import com.ai.shared.util.ModelContentPlainTextExtractor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.ai.mcp.SyncMcpToolCallbackProvider;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.definition.ToolDefinition;
import org.springframework.stereotype.Service;

/**
 * Chapter 2 — edu JVM 안에서 LLM을 직접 호출하지 않고,
 * MCP(HTTP)로 연결된 {@code chapter6_mcp_server}의 {@code strategic_analysis_ch6} 도구만 호출합니다.
 */
@Service
public class Chapter2McpStrategicAnalysisService {

    /** chapter6_mcp_server의 @Tool 메서드명(strategic_analysis_ch6)과 일치해야 하는 MCP 도구 식별자입니다. */
    private static final String TOOL_NAME = "strategic_analysis_ch6";

    private final SyncMcpToolCallbackProvider mcpToolCallbackProvider;
    private final ObjectMapper objectMapper = new ObjectMapper();

    /** Spring AI가 수집한 MCP 도구 콜백 제공자(HTTP 연결된 chapter6 등). */
    public Chapter2McpStrategicAnalysisService(SyncMcpToolCallbackProvider mcpToolCallbackProvider) {
        this.mcpToolCallbackProvider = mcpToolCallbackProvider;
    }

    /**
     * MCP 도구 {@code strategic_analysis_ch6}에 인자를 넘겨 실행합니다.
     *
     * @param userPrompt  사용자 질문
     * @param workflowId  SSE·Redis와 맞출 UUID 문자열
     */
    public String analyze(String userPrompt, String workflowId) {
        // MCP 도구 호출에 전달할 JSON 객체를 구성하기 시작합니다.
        ObjectNode args = objectMapper.createObjectNode();
        // 전략 분석용 사용자 질문을 도구 인자로 설정합니다.
        args.put("userPrompt", userPrompt);
        // 비동기 상태 추적(SSE/Redis)과 연결될 workflowId를 함께 전달합니다.
        args.put("workflowId", workflowId);
        // 직렬화된 JSON 문자열을 담을 변수입니다.
        String json;
        try {
            // 객체를 JSON 문자열로 변환하여 MCP callback 입력 형식에 맞춥니다.
            json = objectMapper.writeValueAsString(args);
        } catch (Exception e) {
            // JSON 생성 실패 시 호출 자체가 불가능하므로 예외를 발생시킵니다.
            throw new IllegalStateException("MCP 인자 JSON 직렬화 실패", e);
        }

        // 현재는 chapter5/chapter6처럼 여러 MCP 서버 도구가 함께 등록될 수 있어,
        // 목표 도구명을 가진 콜백을 찾기 위해 전체 목록을 순회합니다.
        for (ToolCallback callback : mcpToolCallbackProvider.getToolCallbacks()) {
            // ToolCallback의 등록된 도구명을 기준으로 목표 도구인지 확인합니다.
            ToolDefinition definition = callback.getToolDefinition();
            if (definition == null) {
                // 정의 정보가 없는 콜백은 이름 비교가 불가능하므로 건너뜁니다.
                continue;
            }
            String registered = definition.name();
            // 완전 일치 또는 "prefix_strategic_analysis_ch6" 형태의 접미 일치를 허용합니다.
            if (TOOL_NAME.equals(registered) || registered.endsWith("_" + TOOL_NAME)) {
                // MCP 응답의 텍스트 본문만 꺼내 반환해 상위 계층에서 바로 사용하게 합니다.
                return ModelContentPlainTextExtractor.unwrap(callback.call(json));
            }
        }
        // 목표 도구를 찾지 못하면 연결/기동 상태 확인이 필요하므로 예외를 반환합니다.
        throw new IllegalStateException(
                "MCP 도구 '" + TOOL_NAME + "' 를 찾지 못했습니다. chapter6_mcp_server 기동 및 도구 이름을 확인하세요.");
    }
}
