package com.ai.chapter2.controller;

import com.ai.chapter2.service.Chapter2McpStrategicAnalysisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

/**
 * Chapter 2 — MCP Client 실습. Chapter 6과 동일한 Task-Orchestrated 전략 분석을 MCP로만 호출합니다.
 * <p>{@code chapter6_mcp_server}(기본 {@code http://localhost:8096/mcp})를 기동하고 edu의 streamable-http 연결과 맞춰야 합니다.
 * <p>SSE {@code /api/workflow/stream/{workflowId}} — MCP 서버가 edu와 같은 Redis로 AGENT_TODO·ROUTING 등을 발행합니다.
 */
@RestController
@RequestMapping("/ch2")
@Slf4j
@RequiredArgsConstructor
@ConditionalOnProperty(prefix = "spring.ai.mcp.client", name = "enabled", havingValue = "true", matchIfMissing = true)
public class Ch2Controller {

    private final Chapter2McpStrategicAnalysisService chapter2McpStrategicAnalysisService;

    /**
     * Chapter 6 MCP 도구 {@code strategic_analysis_ch6} 호출 — 응답 본문 문자열.
     *
     * @param userPrompt  사용자 프롬프트
     * @param workflowId  UUID 문자열(SSE 구독과 동일해야 함)
     */
    @PostMapping("/mcp-strategic-analysis")
    public String mcpStrategicAnalysis(
            @RequestParam("prompt") String userPrompt,
            @RequestParam String workflowId) {
        UUID.fromString(workflowId);
        log.info("Ch2 MCP strategic analysis (ch6 server) request: {}", userPrompt);
        try {
            return chapter2McpStrategicAnalysisService.analyze(userPrompt, workflowId);
        } catch (Exception e) {
            log.error("Ch2 MCP tool call failed", e);
            return "MCP 호출 실패: " + e.getMessage();
        }
    }
}
