package com.ai.chapter1.service;

import com.ai.shared.util.ModelContentPlainTextExtractor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.ai.mcp.SyncMcpToolCallbackProvider;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.definition.ToolDefinition;
import org.springframework.stereotype.Service;

/**
 * Chapter 1 — <strong>MCP 서버로만</strong> 요청합니다.
 * <p>
 * {@code ChatModel}/{@code ChatClient} 등 edu 프로세스 내 직접 LLM 호출은 하지 않습니다.
 * {@link org.springframework.ai.mcp.SyncMcpToolCallbackProvider}로 {@code chapter5_mcp_server}의 {@code strategic_analysis} 도구만 실행합니다.
 */
@Service
public class Chapter1McpStrategicAnalysisService {

    /** chapter5_mcp_server의 @Tool 메서드명(strategic_analysis)과 일치해야 하는 MCP 도구 식별자입니다. */
    private static final String TOOL_NAME = "strategic_analysis";

    private final SyncMcpToolCallbackProvider mcpToolCallbackProvider;
    private final ObjectMapper objectMapper = new ObjectMapper();

    /** Spring AI가 수집한 MCP 도구 콜백 제공자(STDIO 연결된 chapter5 등). */
    public Chapter1McpStrategicAnalysisService(SyncMcpToolCallbackProvider mcpToolCallbackProvider) {
        this.mcpToolCallbackProvider = mcpToolCallbackProvider;
    }

    /**
     * MCP 도구 {@code strategic_analysis}에 {@code userPrompt}, {@code workflowId}를 넘겨 실행합니다.
     * {@code workflowId}는 MCP 서버가 Redis로 발행하는 SSE 이벤트와 브라우저 구독을 맞추는 데 사용됩니다.
     */
    public String analyze(String userPrompt, String workflowId) {
        // MCP 도구 호출 인자 JSON의 루트 객체를 생성합니다.
        ObjectNode args = objectMapper.createObjectNode();
        // 사용자가 입력한 자연어 프롬프트를 MCP 도구 입력값에 넣습니다.
        args.put("userPrompt", userPrompt);
        // SSE/Redis 상관관계 추적용 workflowId를 동일하게 전달합니다.
        args.put("workflowId", workflowId);
        // 최종적으로 callback.call(...)에 넘길 JSON 문자열 변수를 선언합니다.
        String json;
        try {
            // ObjectNode를 직렬화해 MCP 도구가 이해할 수 있는 JSON 텍스트를 만듭니다.
            json = objectMapper.writeValueAsString(args);
        } catch (Exception e) {
            // 인자 직렬화 실패 시 도구 호출을 진행할 수 없으므로 즉시 중단합니다.
            throw new IllegalStateException("MCP 인자 JSON 직렬화 실패", e);
        }

        // 현재는 chapter5/chapter6처럼 여러 MCP 서버 도구가 함께 등록될 수 있어,
        // 목표 도구명을 가진 콜백을 찾기 위해 전체 목록을 순회합니다.
        for (ToolCallback callback : mcpToolCallbackProvider.getToolCallbacks()) {
            // ToolCallback의 등록된 도구명을 기준으로 목표 도구인지 확인합니다.
            ToolDefinition definition = callback.getToolDefinition();
            if (definition == null) {
                // 정의 정보가 없는 콜백은 이름 비교가 불가능하므로 건너뜁니다.
                continue;
            }
            String registered = definition.name();
            // 완전 일치 또는 "prefix_strategic_analysis" 형태의 접미 일치를 허용합니다.
            if (TOOL_NAME.equals(registered) || registered.endsWith("_" + TOOL_NAME)) {
                // MCP 응답 래퍼를 평문으로 변환해 컨트롤러 계층에 반환합니다.
                return ModelContentPlainTextExtractor.unwrap(callback.call(json));
            }
        }
        // 목표 도구를 찾지 못하면 연결/기동 상태 확인이 필요하므로 예외를 반환합니다.
        throw new IllegalStateException(
                "MCP 도구 '" + TOOL_NAME + "' 를 찾지 못했습니다. chapter5_mcp_server 기동 및 도구 이름을 확인하세요.");
    }

}
