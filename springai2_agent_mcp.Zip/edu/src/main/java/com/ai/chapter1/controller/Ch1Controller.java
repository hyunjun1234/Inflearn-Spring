package com.ai.chapter1.controller;

import com.ai.chapter1.service.Chapter1McpStrategicAnalysisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

/**
 * Chapter 1 — MCP Client 실습용 API. <strong>edu는 LLM을 호출하지 않고 MCP 서버로만 요청합니다.</strong>
 * <p>Chapter 5 MCP는 edu가 STDIO로 {@code java -jar chapter5_mcp_server} 자식 프로세스를 띄웁니다({@code mcp-servers.json}의 JAR 경로·{@code bootJar} 산출물과 일치해야 함).
 * STDIO JAR 경로는 {@code mcp-servers.json}의 {@code mcpServers.chapter5-mcp-server.args}와 실제 bootJar 산출물이 맞아야 합니다.
 * <p>브라우저는 Chapter 5 실습과 동일하게 동일 {@code workflowId}로 SSE({@code /api/workflow/stream/{workflowId}})를 연 뒤 본 API를 호출합니다.
 * MCP 서버는 edu와 같은 Redis로 단계 메시지를 발행합니다.
 */
@RestController
@RequestMapping("/ch1")
@Slf4j
@RequiredArgsConstructor
@ConditionalOnProperty(prefix = "spring.ai.mcp.client", name = "enabled", havingValue = "true", matchIfMissing = true)
public class Ch1Controller {

    private final Chapter1McpStrategicAnalysisService chapter1McpStrategicAnalysisService;

    /**
     * Chapter 5 MCP 도구 {@code strategic_analysis} 호출 — 응답 본문 문자열.
     *
     * @param userPrompt  사용자 프롬프트
     * @param workflowId  UUID 문자열(SSE 구독과 동일해야 함)
     */
    @PostMapping("/mcp-strategic-analysis")
    public String mcpStrategicAnalysis(
            @RequestParam("prompt") String userPrompt,
            @RequestParam String workflowId) {
        UUID.fromString(workflowId);
        log.info("Ch1 MCP strategic analysis request: {}", userPrompt);
        try {
            return chapter1McpStrategicAnalysisService.analyze(userPrompt, workflowId);
        } catch (Exception e) {
            log.error("Ch1 MCP tool call failed", e);
            return "MCP 호출 실패: " + e.getMessage();
        }
    }
}
