package com.ai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * edu 애플리케이션 진입점 — Thymeleaf UI, MCP 클라이언트(Ch1·Ch2), Redis/SSE.
 */
@SpringBootApplication
public class EduApplication {

    public static void main(String[] args) {
        SpringApplication.run(EduApplication.class, args);
    }

}
