package com.ai.shared.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 전략 보고서 평가 단계 설정 — {@code strategic.evaluator.approval-threshold}(기본 75).
 * <p>{@link com.ai.shared.util.EvaluationApprovalDecider}와 함께 쓰입니다.
 */
@Component
@ConfigurationProperties(prefix = "strategic.evaluator")
public class StrategicEvaluatorProperties {

    /** 이 점수 이상이면 평가 통과로 간주(0–100). */
    private int approvalThreshold = 75;

    public int getApprovalThreshold() {
        return approvalThreshold;
    }

    public void setApprovalThreshold(int approvalThreshold) {
        this.approvalThreshold = approvalThreshold;
    }
}
