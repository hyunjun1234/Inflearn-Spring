package com.ai.shared.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.google.genai.GoogleGenAiChatModel;
import org.springframework.ai.ollama.OllamaChatModel;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 범용 {@link ChatClient} 빈 — 모델별 {@code @Qualifier}(gpt / gemini / llama).
 * <p>전략 분석 TaskTool 전용 구성은 {@link com.ai.chapter6.config.StrategicAnalysisAgentConfig} 등에서 별도로 만듭니다.
 */
@Configuration
@Slf4j
public class ChatClientConfig {

    @Bean
    @Qualifier("gpt")
    public ChatClient openAiChatClient(OpenAiChatModel openAiChatModel) {
        return ChatClient.builder(openAiChatModel)
                .defaultSystem("당신은 OpenAI가 제공하는 친절한 AI 조수입니다.")
                .build();
    }

    @Bean
    @Qualifier("gemini")
    public ChatClient geminiChatClient(GoogleGenAiChatModel googleGenAiChatModel) {
        return ChatClient.builder(googleGenAiChatModel)
                .defaultSystem("당신은 Google의 Gemini 모델을 기반으로 한 전문가입니다.")
                .build();
    }

    @Bean
    @Qualifier("llama")
    public ChatClient llamaClient(OllamaChatModel model) {
        log.info("Llama Chat Client(ChatClientConfig)");
        return ChatClient.builder(model)
                .defaultSystem("당신은 로컬에서 구동되는 Llama 3.2 모델입니다.")
                .build();
    }
}
