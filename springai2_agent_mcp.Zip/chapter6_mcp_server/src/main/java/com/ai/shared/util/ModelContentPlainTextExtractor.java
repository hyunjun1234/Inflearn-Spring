package com.ai.shared.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 일부 모델·MCP 경로에서 LLM 응답이 {@code [{"text":"..."}]} 같은 JSON 조각 문자열로 올 때
 * 사람이 읽을 본문만 뽑습니다. 이미 평문이면 그대로 둡니다.
 */
public final class ModelContentPlainTextExtractor {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private ModelContentPlainTextExtractor() {}

    public static String unwrap(String raw) {
        if (raw == null || raw.isEmpty()) {
            return raw;
        }
        String s = raw;
        for (int i = 0; i < 5; i++) {
            String t = s.trim();
            if (!looksLikeStructuredContent(t)) {
                return decodeLiteralEscapes(s);
            }
            String next = unwrapOnce(t);
            if (next == null || next.equals(s)) {
                return decodeLiteralEscapes(s);
            }
            s = next;
        }
        return decodeLiteralEscapes(s);
    }

    /**
     * 모델이 본문 안에 JSON 이스케이프를 그대로 넣어 {@code \n} 두 글자로 보내는 경우 실제 줄바꿈으로 바꿉니다.
     */
    private static String decodeLiteralEscapes(String s) {
        if (s == null || !s.contains("\\")) {
            return s;
        }
        if (!(s.contains("\\n") || s.contains("\\r") || s.contains("\\t"))) {
            return s;
        }
        return s.replace("\\r\\n", "\n")
                .replace("\\n", "\n")
                .replace("\\r", "\n")
                .replace("\\t", "\t");
    }

    private static boolean looksLikeStructuredContent(String t) {
        if (t.isEmpty()) {
            return false;
        }
        if (t.startsWith("[") && t.contains("\"text\"")) {
            return true;
        }
        return t.startsWith("{") && t.contains("\"text\"");
    }

    private static String unwrapOnce(String t) {
        try {
            JsonNode root = MAPPER.readTree(t);
            if (root.isArray()) {
                StringBuilder sb = new StringBuilder();
                for (JsonNode el : root) {
                    sb.append(extractFromPart(el));
                }
                String out = sb.toString();
                return out.isEmpty() ? t : out;
            }
            if (root.isObject()) {
                String part = extractFromPart(root);
                return part.isEmpty() ? t : part;
            }
        } catch (Exception ignored) {
            return t;
        }
        return t;
    }

    private static String extractFromPart(JsonNode el) {
        if (el == null || el.isNull()) {
            return "";
        }
        if (el.isTextual()) {
            return el.asText();
        }
        if (!el.isObject()) {
            return "";
        }
        if (el.has("text")) {
            JsonNode text = el.get("text");
            if (text.isTextual()) {
                return text.asText();
            }
            if (text.isObject() && text.has("value") && text.get("value").isTextual()) {
                return text.get("value").asText();
            }
        }
        if (el.has("content")) {
            JsonNode c = el.get("content");
            if (c.isTextual()) {
                return c.asText();
            }
            if (c.isArray()) {
                StringBuilder sb = new StringBuilder();
                for (JsonNode x : c) {
                    sb.append(extractFromPart(x));
                }
                return sb.toString();
            }
        }
        return "";
    }
}
