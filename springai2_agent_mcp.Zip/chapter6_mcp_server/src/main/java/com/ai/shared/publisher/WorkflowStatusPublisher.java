package com.ai.shared.publisher;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * 워크플로 단계 이벤트를 Redis Pub/Sub 및 히스토리 리스트에 기록합니다.
 * <p>채널 {@code workflow:status:{workflowId}} — edu 쪽 SSE 구독과 동일 규약입니다.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class WorkflowStatusPublisher {

    private static final Duration STATUS_BUFFER_TTL = Duration.ofMinutes(15);
    private static final int STATUS_BUFFER_MAX_SIZE = 200;

    private final RedisTemplate<String, Object> redisTemplate;

    public void publishStatus(UUID workflowId, String step, String message) {
        Map<String, Object> statusUpdate = Map.of(
                "workflowId", workflowId.toString(),
                "step", step,
                "message", message,
                "timestamp", LocalDateTime.now().toString());

        String channel = "workflow:status:" + workflowId;
        String historyKey = "workflow:status:history:" + workflowId;

        redisTemplate.convertAndSend(channel, statusUpdate);
        redisTemplate.opsForList().rightPush(historyKey, statusUpdate);
        redisTemplate.opsForList().trim(historyKey, -STATUS_BUFFER_MAX_SIZE, -1);
        redisTemplate.expire(historyKey, STATUS_BUFFER_TTL);

        log.info("[Redis Publish] step={}, message={}", step, message);
    }
}
