package com.ai.mcp.tools;

import com.ai.chapter6.service.StrategicAnalysisAgentToolTaskService;
import com.ai.shared.util.ModelContentPlainTextExtractor;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * MCP에 노출하는 Chapter 6 실습용 도구 — edu {@code Ch6Controller} / {@code POST /ch6/strategic-analysis} 와
 * 동일하게 {@link StrategicAnalysisAgentToolTaskService}(TaskTool + Markdown 서브에이전트 + TodoWrite) 파이프라인을 실행합니다.
 * <p>도구 이름 {@code strategic_analysis_ch6}는 chapter5 MCP의 {@code strategic_analysis}와 구분합니다.
 */
@Service
public class Chapter6McpToolService {

    private final StrategicAnalysisAgentToolTaskService strategicAnalysisAgentToolTaskService;

    /**
     * @param strategicAnalysisAgentToolTaskService TaskTool 파이프라인 실행 서비스({@code @Lazy}: 순환 참조 방지)
     */
    public Chapter6McpToolService(
            @Lazy StrategicAnalysisAgentToolTaskService strategicAnalysisAgentToolTaskService) {
        this.strategicAnalysisAgentToolTaskService = strategicAnalysisAgentToolTaskService;
    }

    @Tool(description = """
            Chapter 6 Task-Orchestrated 전략 분석: TaskTool로 classpath:/chapter6/agents/strategic/*.md 서브에이전트를 호출하고,
            TodoWrite 진행이 Redis/SSE(AGENT_TODO)로 발행됩니다. edu Chapter 2 MCP 클라이언트가 사용합니다.
            인자: userPrompt(사용자 질문), workflowId(UUID, edu SSE /api/workflow/stream/{id} 와 동일해야 함). 비우면 서버가 임의 UUID를 씁니다.
            """)
    public String strategic_analysis_ch6(String userPrompt, String workflowId) {
        UUID id = parseOrRandomWorkflowId(workflowId);
        return ModelContentPlainTextExtractor.unwrap(
                strategicAnalysisAgentToolTaskService.executeWithMonitoring(id, userPrompt));
    }

    private static UUID parseOrRandomWorkflowId(String workflowId) {
        if (workflowId == null || workflowId.isBlank()) {
            return UUID.randomUUID();
        }
        try {
            return UUID.fromString(workflowId.trim());
        } catch (IllegalArgumentException e) {
            return UUID.randomUUID();
        }
    }
}
