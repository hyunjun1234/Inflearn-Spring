package com.ai.mcp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Chapter 6 MCP 서버 진입점 — {@code com.ai} 이하 전역 스캔.
 * <p>Streamable HTTP MCP({@code spring-ai-starter-mcp-server-webmvc})와 TaskTool 기반 전략 분석 도구
 * {@code strategic_analysis_ch6}를 제공합니다.
 */
@SpringBootApplication(scanBasePackages = "com.ai")
public class McpChapter6Application {

    public static void main(String[] args) {
        SpringApplication.run(McpChapter6Application.class, args);
    }
}
