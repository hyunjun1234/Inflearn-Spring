package com.ai.mcp.config;

import com.ai.mcp.tools.Chapter6McpToolService;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * MCP에 노출할 Spring AI 도구 콜백 — {@link Chapter6McpToolService}의 {@code @Tool} 메서드를
 * MCP 런타임에 등록합니다.
 */
@Configuration
public class McpChapter6ToolConfig {

    /**
     * Chapter 6 단일 도구 빈({@code strategic_analysis_ch6})을 MCP에 연결합니다.
     */
    @Bean
    public MethodToolCallbackProvider chapter6McpTools(Chapter6McpToolService chapter6McpToolService) {
        return MethodToolCallbackProvider.builder()
                .toolObjects(chapter6McpToolService)
                .build();
    }
}
