package com.ai.chapter7.service;

import com.ai.chapter7.dagengine.core.DagWorkflowEngine;
import com.ai.chapter7.dagengine.core.WorkflowContext;
import com.ai.shared.publisher.WorkflowStatusPublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * StrategicAnalysisDagWorkflowService
 *
 * 📌 Chapter 7 — DAG 워크플로 진입 서비스 (HTTP → 엔진)
 *
 * 아키텍처 개요:
 * 1️⃣ 본 클래스 — {@link WorkflowContext} 조립 후 {@link DagWorkflowEngine#run(WorkflowContext)} 호출
 * 2️⃣ {@link DagWorkflowEngine} — Router 이후 노드 그래프 실행
 *
 * 역할:
 * - 컨트롤러가 호출하는 유일한 서비스 진입점(동기 결과 반환)
 * - {@link WorkflowContext}에 workflowId·사용자 입력·{@link WorkflowStatusPublisher} 주입
 *
 * 특징:
 * - 엔진 내부는 {@link java.util.concurrent.CompletableFuture} 비동기 체인
 * - 본 클래스는 {@code join()}으로 최종 문자열을 동기 반환 (ch4~ch6 API와 동일 계약)
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class StrategicAnalysisDagWorkflowService {

    /** DAG 노드 체인 실행 엔진 */
    private final DagWorkflowEngine dagWorkflowEngine;

    /** 워크플로 단계를 Redis/SSE로 발행하기 위한 컨텍스트 주입용 */
    private final WorkflowStatusPublisher statusPublisher;

    /**
     * executeWithMonitoring
     *
     * 📌 전략 분석 워크플로우 실행 (DAG 버전)
     *
     * @param workflowId  SSE/Redis와 매칭되는 추적용 UUID
     * @param input       사용자 프롬프트
     * @return            최종 보고서 또는 오류 메시지 문자열
     */
    public String executeWithMonitoring(UUID workflowId, String input) {
        WorkflowContext ctx = new WorkflowContext(workflowId, input, statusPublisher);
        try {
            return dagWorkflowEngine.run(ctx).join();
        } catch (Exception e) {
            log.error("[{}] DAG 워크플로우 실패", workflowId, e);
            ctx.publish("ERROR", "DAG 워크플로우 실행 실패");
            return "DAG 워크플로우 실행 실패: " + e.getMessage();
        }
    }
}
