package com.ai.chapter7.dagengine.nodes;

import com.ai.chapter7.dagengine.core.DagWorkflowEngine;
import com.ai.chapter7.dagengine.core.NodeResult;
import com.ai.chapter7.dagengine.core.WorkflowContext;
import com.ai.chapter7.dagengine.core.WorkflowNode;
import com.ai.shared.agent.api.SubAgentRegistry;
import com.ai.shared.config.StrategicEvaluatorProperties;
import com.ai.shared.util.EvaluationApprovalDecider;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * EvaluationNode
 *
 * 📌 현재 초안({@link WorkflowContext#getCurrentReport()})에 대한 품질 평가 노드
 *
 * 아키텍처 개요:
 * 1️⃣ {@link SubAgentRegistry} 키 {@code report-evaluator}로 서브에이전트 호출
 * 2️⃣ 응답에서 점수 추출 → {@link WorkflowContext#publish} 로 {@code EVALUATION_SCORE} 발행
 * 3️⃣ 승인·루프 종료 여부는 {@link DagWorkflowEngine}이
 *    {@link EvaluationApprovalDecider} + {@link StrategicEvaluatorProperties}로 판단
 *
 * 특징:
 * - 레지스트리 키·{@link #id()} 모두 {@code report-evaluator} (Chapter 4~6와 동일)
 * - 회차 표시는 {@link WorkflowContext#getEvaluationRound()}
 */
@Component
@RequiredArgsConstructor
public class EvaluationNode implements WorkflowNode {

    private static final String AGENT_REPORT_EVALUATOR = "report-evaluator";

    /** Markdown/서브에이전트 기반 평가 실행 */
    private final SubAgentRegistry subAgentRegistry;

    @Override
    public String id() {
        return AGENT_REPORT_EVALUATOR;
    }

    /**
     * execute
     *
     * 📌 현재 초안 보고서를 평가 서브에이전트에 넘기고, 평가 결과와 점수를 컨텍스트·상태에 반영합니다.
     *
     * 동작:
     * - {@link WorkflowContext#getCurrentReport()}를 {@code report-evaluator} 서브에이전트에 전달해 평가 문자열을 얻습니다.
     * - 평가 결과를 {@link WorkflowContext#setLastEvaluation(String)}에 저장하고,
     *   {@link EvaluationApprovalDecider#extractScore(String)}로 점수를 추출해 {@code EVALUATION_SCORE} 상태를 발행합니다.
     *
     * @param ctx      현재 워크플로 컨텍스트
     * @param executor 실행에 사용할 스레드 풀
     * @return         평가 결과 문자열을 payload로 갖는 {@link NodeResult}
     */
    @Override
    public CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            int round = ctx.getEvaluationRound();
            ctx.publish("EVALUATING", round + "차 품질 평가 중...");
            try {
                String evaluation = subAgentRegistry.require(AGENT_REPORT_EVALUATOR).execute(ctx.getCurrentReport());
                ctx.setLastEvaluation(evaluation);
                Integer score = EvaluationApprovalDecider.extractScore(evaluation);
                if (score != null) {
                    ctx.publish("EVALUATION_SCORE", round + "차 평가 점수: " + score + "점");
                } else {
                    ctx.publish("EVALUATION_SCORE", round + "차 평가 점수: 추출 실패");
                }
                return NodeResult.ok(evaluation);
            } catch (Exception e) {
                return NodeResult.fail("평가 실패: " + e.getMessage());
            }
        }, executor);
    }

}
