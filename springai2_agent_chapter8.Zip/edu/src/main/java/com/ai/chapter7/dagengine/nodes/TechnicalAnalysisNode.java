package com.ai.chapter7.dagengine.nodes;

import com.ai.chapter7.dagengine.core.DagWorkflowEngine;
import com.ai.chapter7.dagengine.core.NodeResult;
import com.ai.chapter7.dagengine.core.WorkflowContext;
import com.ai.chapter7.dagengine.core.WorkflowNode;
import com.ai.shared.agent.api.SubAgentRegistry;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * TechnicalAnalysisNode
 *
 * 📌 STRATEGIC 경로 — 기술 관점 분석 (레지스트리 키 {@code technical-analysis})
 *
 * 아키텍처 개요:
 * 1️⃣ {@link DagWorkflowEngine}이 Market 노드와 병렬 실행
 * 2️⃣ 결과는 {@link WorkflowContext#setTechnicalAnalysis(String)}에 저장
 *
 * 특징:
 * - 예외 시에도 플레이스홀더 문자열을 넣어 병렬 구간이 끊기지 않도록 함 (Chapter 4와 동일 취지)
 */
@Component
@RequiredArgsConstructor
public class TechnicalAnalysisNode implements WorkflowNode {

    private static final String AGENT_TECHNICAL_ANALYSIS = "technical-analysis";

    /** SubAgent 기반 기술 분석 */
    private final SubAgentRegistry subAgentRegistry;

    @Override
    public String id() {
        return AGENT_TECHNICAL_ANALYSIS;
    }

    /**
     * execute
     *
     * 📌 STRATEGIC 경로에서 기술 관점 분석을 수행하는 노드입니다.
     *
     * 동작:
     * - {@code technical-analysis} 서브에이전트를 호출해 기술 분석 결과를 생성하고,
     *   {@link WorkflowContext#setTechnicalAnalysis(String)}에 저장합니다.
     * - 예외가 발생하면 "기술 분석 실패"라는 플레이스홀더를 저장하여
     *   이후 병합 단계가 중단되지 않도록 합니다.
     *
     * @param ctx      현재 워크플로 컨텍스트
     * @param executor 실행에 사용할 스레드 풀
     * @return         기술 분석 결과 또는 실패 플레이스홀더를 담은 {@link NodeResult}
     */
    @Override
    public CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            ctx.publish("TECH", "기술 관점 분석 중...");
            try {
                String tech = subAgentRegistry.require(AGENT_TECHNICAL_ANALYSIS).execute(ctx.getUserInput());
                ctx.setTechnicalAnalysis(tech);
                return NodeResult.ok(tech);
            } catch (Exception e) {
                ctx.setTechnicalAnalysis("기술 분석 실패");
                return NodeResult.ok("기술 분석 실패");
            }
        }, executor);
    }
}
