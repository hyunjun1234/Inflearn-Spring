package com.ai.chapter7.dagengine.nodes;

import com.ai.chapter4.service.StrategicAnalysisAgentOrchestrator;
import com.ai.chapter7.dagengine.core.NodeResult;
import com.ai.chapter7.dagengine.core.WorkflowContext;
import com.ai.chapter7.dagengine.core.WorkflowNode;
import com.ai.shared.agent.api.SubAgentRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;

/**
 * RouterNode
 *
 * 📌 DAG 진입 노드 — 사용자 요청을 SIMPLE / STRATEGIC 으로 분류
 *
 * 아키텍처 개요:
 * 1️⃣ {@link SubAgentRegistry#require(String)} 로 키 {@code routing} 호출
 * 2️⃣ 원문 응답을 {@link #resolveRoutingCategory(String)}로 정규화
 * 3️⃣ {@link WorkflowContext#setRouteCategory(String)} 저장 → 엔진이 분기 그래프 선택
 *
 * 특징:
 * - Chapter 4 {@link StrategicAnalysisAgentOrchestrator}와 동일한 라우팅 키
 * - {@link #id()} = 레지스트리 키 {@code routing}
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class RouterNode implements WorkflowNode {

    private static final String AGENT_ROUTING = "routing";

    /** 사용자 입력(trim) → SIMPLE / STRATEGIC — routing 서브에이전트 재호출 생략 (ch8/ch9 YAML 엔진 동일 노드) */
    private final Map<String, String> routingCategoryCache = new ConcurrentHashMap<>();

    /** 서브에이전트(예: strategic-router.md) 조회·실행 */
    private final SubAgentRegistry subAgentRegistry;

    @Override
    public String id() {
        return AGENT_ROUTING;
    }

    /**
     * execute
     *
     * 📌 routing 서브에이전트를 호출해 SIMPLE/STRATEGIC 라우팅을 수행하고, 컨텍스트에 결과를 저장합니다.
     *
     * 동작:
     * - {@link WorkflowContext#publish(String, String)}로 {@code ROUTING} 단계를 발행합니다.
     * - 서브에이전트 {@code routing}을 호출한 뒤, {@link #resolveRoutingCategory(String)}로
     *   결과를 정규화하여 {@link WorkflowContext#setRouteCategory(String)}에 저장합니다.
     *
     * @param ctx      현재 워크플로 컨텍스트
     * @param executor 실행에 사용할 스레드 풀
     * @return         성공 시 카테고리(SIMPLE/STRATEGIC)를 payload로 갖는 {@link NodeResult}
     */
    @Override
    public CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            ctx.publish("ROUTING", "요청 라우팅 분석 중...");
            try {
                String userInput = ctx.getUserInput();
                String cacheKey = userInput == null ? "" : userInput.trim();
                String category;
                String cached = routingCategoryCache.get(cacheKey);
                if (cached != null) {
                    category = cached;
                    log.info("[{}] Routing 캐시 히트: {}", ctx.getWorkflowId(), category);
                } else {
                    String routingRaw = subAgentRegistry.require(AGENT_ROUTING).execute(userInput);
                    category = resolveRoutingCategory(routingRaw);
                    routingCategoryCache.put(cacheKey, category);
                }
                ctx.setRouteCategory(category);
                return NodeResult.ok(category);
            } catch (Exception e) {
                return NodeResult.fail("Routing 실패: " + e.getMessage());
            }
        }, executor);
    }

    /**
     * 라우터 LLM 출력에서 SIMPLE/STRATEGIC 토큰만 해석합니다. 애매하면 STRATEGIC.
     */
    private String resolveRoutingCategory(String raw) {
        String upper = raw == null ? "" : raw.toUpperCase();
        if (upper.contains("SIMPLE") && !upper.contains("STRATEGIC")) {
            return "SIMPLE";
        }
        if (upper.contains("STRATEGIC")) {
            return "STRATEGIC";
        }
        return "STRATEGIC";
    }
}
