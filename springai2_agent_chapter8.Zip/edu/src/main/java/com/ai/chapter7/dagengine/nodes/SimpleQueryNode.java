package com.ai.chapter7.dagengine.nodes;

import com.ai.chapter7.dagengine.core.DagWorkflowEngine;
import com.ai.chapter7.dagengine.core.NodeResult;
import com.ai.chapter7.dagengine.core.WorkflowContext;
import com.ai.chapter7.dagengine.core.WorkflowNode;
import com.ai.shared.agent.api.SubAgentRegistry;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * SimpleQueryNode
 *
 * 📌 SIMPLE 분기 전용 — 단일 응답 서브에이전트 호출
 *
 * 아키텍처 개요:
 * 1️⃣ {@link DagWorkflowEngine}이 Router 결과가 SIMPLE일 때만 실행
 * 2️⃣ 응답은 {@link WorkflowContext#setSimpleResponse(String)}
 *
 * 특징:
 * - 레지스트리 키 {@code simple-query} (Chapter 4~6와 동일)
 * - STRATEGIC 경로에서는 호출되지 않음
 */
@Component
@RequiredArgsConstructor
public class SimpleQueryNode implements WorkflowNode {

    private static final String AGENT_SIMPLE_QUERY = "simple-query";

    /** 단순 대화/단답용 서브에이전트 */
    private final SubAgentRegistry subAgentRegistry;

    @Override
    public String id() {
        return AGENT_SIMPLE_QUERY;
    }

    /**
     * execute
     *
     * 📌 SIMPLE 분기에서만 실행되는 단일 응답 노드입니다.
     *
     * 동작:
     * - {@code simple-query} 서브에이전트를 호출해 사용자 입력에 대한 최종 응답을 생성합니다.
     * - 결과를 {@link WorkflowContext#setSimpleResponse(String)}에 저장하고, 성공 시 {@link NodeResult#ok(String)}로 반환합니다.
     *
     * @param ctx      현재 워크플로 컨텍스트
     * @param executor 실행에 사용할 스레드 풀
     * @return         응답 문자열을 담은 {@link NodeResult}
     */
    @Override
    public CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            ctx.publish("SIMPLE", "단순 요청 처리 중...");
            try {
                String result = subAgentRegistry.require(AGENT_SIMPLE_QUERY).execute(ctx.getUserInput());
                ctx.setSimpleResponse(result);
                return NodeResult.ok(result);
            } catch (Exception e) {
                return NodeResult.fail("단순 요청 처리 실패: " + e.getMessage());
            }
        }, executor);
    }
}
