import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const src = path.join(
  "D:",
  "SPRINGAI_EDU",
  "springai2_agnet_FINAL",
  "springai2_agent_temp",
  "edu",
  "src",
  "main",
  "resources",
  "templates",
  "fragments",
  "main.html"
);
const t = fs.readFileSync(src, "utf8");
const lines = t.split(/\r?\n/);
const styleStart = lines.findIndex((l) => l.trim() === "<style>");
const styleEnd = lines.findIndex((l) => l.trim() === "</style>");
if (styleStart < 0 || styleEnd < 0) throw new Error("style bounds");
const css = lines
  .slice(styleStart + 1, styleEnd)
  .map((l) => l.replace(/^    /, ""))
  .join("\n");
const mainStart = lines.findIndex(
  (l) => l.includes('class="course-main"') && l.includes("<div")
);
const thBlock = lines.findIndex((l) => l.trim() === "</th:block>");
if (mainStart < 0 || thBlock < 0) throw new Error("th:block");
// Outer wrapper: <div class="course-main"> ... </div> immediately before </th:block>
let mainEnd = -1;
for (let i = thBlock - 1; i > mainStart; i--) {
  if (lines[i].trim() === "</div>") {
    mainEnd = i;
    break;
  }
}
if (mainStart < 0 || mainEnd < 0) throw new Error("main bounds " + mainStart + " " + mainEnd);
let html = lines.slice(mainStart, mainEnd + 1).join("\n");
html = html.replace(/<a\s+th:href="@\{\/go\/ch(\d+)\}">/g, '<a href="/chapter$1">');
html = html.replace(
  /<a\s+th:href="@\{\/go\/ch(\d+)\/desc\}">/g,
  '<a href="/chapter$1/desc">'
);
const outDir = path.join(__dirname, "..", "src", "pages");
fs.writeFileSync(path.join(outDir, "mainCourse.css"), css, "utf8");
fs.writeFileSync(path.join(outDir, "mainCourseBody.html"), html, "utf8");
console.log("Wrote mainCourse.css, mainCourseBody.html from", src);
console.log("css length", css.length, "html length", html.length);
