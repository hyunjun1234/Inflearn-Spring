/**
 * Spring fragments/ch2~ch9.html → src/pages/chapterN/chNFragment.html
 * (th:href / th:src → React 경로)
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoEdu = path.resolve(__dirname, '..', '..', 'springai2_agent', 'edu', 'src', 'main', 'resources', 'templates', 'fragments');
const pagesRoot = path.resolve(__dirname, '..', 'src', 'pages');

function transform(html) {
  let s = html;
  s = s.replace(/th:href="@\{([^}]+)\}"/g, (_, p) => {
    const m = String(p).match(/^\/go\/ch(\d+)(.*)$/);
    if (!m) return `href="${p}"`;
    return `href="/chapter${m[1]}${m[2] || ''}"`;
  });
  s = s.replace(/th:src="@\{([^}]+)\}"/g, (_, p) => `src="${p}"`);
  return s;
}

function extractThBlockInner(raw) {
  const m = raw.match(/<th:block>\s*([\s\S]*?)\s*<\/th:block>/i);
  if (!m) throw new Error('no th:block');
  return m[1].trim();
}

for (let n = 2; n <= 9; n++) {
  const srcFile = path.join(repoEdu, `ch${n}.html`);
  const outDir = path.join(pagesRoot, `chapter${n}`);
  const outFile = path.join(outDir, `ch${n}Fragment.html`);
  if (!fs.existsSync(srcFile)) {
    console.warn('skip missing', srcFile);
    continue;
  }
  const raw = fs.readFileSync(srcFile, 'utf8');
  let inner = extractThBlockInner(raw);
  inner = transform(inner);
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(outFile, inner + '\n', 'utf8');
  console.log('wrote', path.relative(path.join(__dirname, '..'), outFile));
}
