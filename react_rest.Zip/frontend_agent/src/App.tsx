import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Chapter1Index from './pages/chapter1';
import Ch1Desc from './pages/chapter1/Desc';
import MultiLLM from './pages/chapter1/MultiLLM';
import MultiLLMStream from './pages/chapter1/MultiLLMStream';
import Ch1Fallback from './pages/chapter1/Fallback';
import Ch1Router from './pages/chapter1/Router';
import Ch1Security from './pages/chapter1/Security';
import Chapter2Index from './pages/chapter2';
import Ch2Desc from './pages/chapter2/Desc';
import Ch2Chain from './pages/chapter2/ChainWorkflow';
import Ch2Parallel from './pages/chapter2/ParallelizationWorkflow';
import Ch2Routing from './pages/chapter2/RoutingWorkflow';
import Ch2Orch from './pages/chapter2/OrchestratorWorkers';
import Ch2Eval from './pages/chapter2/EvaluatorOptimizer';
import Chapter3Index from './pages/chapter3';
import Ch3Desc from './pages/chapter3/Desc';
import Ch3Strategic from './pages/chapter3/StrategicAnalysis';
import Ch3Precision from './pages/chapter3/PrecisionExecution';
import Ch3Voting from './pages/chapter3/VotingAnalysis';
import Ch3AutoPatternRouting from './pages/chapter3/AutoPatternRouting';
import Chapter4Index from './pages/chapter4';
import Ch4Desc from './pages/chapter4/Desc';
import Ch4Strategic from './pages/chapter4/StrategicAnalysis';
import Chapter5Index from './pages/chapter5';
import Ch5Desc from './pages/chapter5/Desc';
import Ch5Strategic from './pages/chapter5/StrategicAnalysis';
import Chapter6Index from './pages/chapter6';
import Ch6Desc from './pages/chapter6/Desc';
import Ch6Strategic from './pages/chapter6/StrategicAnalysis';
import Chapter7Index from './pages/chapter7';
import Ch7Desc from './pages/chapter7/Desc';
import Ch7Strategic from './pages/chapter7/StrategicAnalysis';
import Chapter8Index from './pages/chapter8';
import Ch8Desc from './pages/chapter8/Desc';
import Ch8Strategic from './pages/chapter8/StrategicAnalysis';
import Chapter9Index from './pages/chapter9';
import Ch9Desc from './pages/chapter9/Desc';
import Ch9Strategic from './pages/chapter9/StrategicAnalysis';
import SettingReact from './pages/setting/ReactPage';
import SettingIntellij from './pages/setting/IntellijPage';
import SettingOpenAi from './pages/setting/OpenAiPage';
import SettingGemini from './pages/setting/GeminiPage';
import SettingOllama from './pages/setting/OllamaPage';
import SettingSpringAi from './pages/setting/SpringAiPage';
import SettingRedis from './pages/setting/RedisPage';
import SettingPostgreSQL from './pages/setting/PostgreSQLPage';
import './App.css';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />

          {/* Chapter 1 — React (springai2_agent pages/ch1 + /ch1 API) */}
          <Route path="chapter1" element={<Chapter1Index />} />
          <Route path="chapter1/desc" element={<Ch1Desc />} />
          <Route path="chapter1/1_multi_llm" element={<MultiLLM />} />
          <Route path="chapter1/2_multi_llm_stream" element={<MultiLLMStream />} />
          <Route path="chapter1/3_fallback" element={<Ch1Fallback />} />
          <Route path="chapter1/4_router" element={<Ch1Router />} />
          <Route path="chapter1/5_security" element={<Ch1Security />} />

          {/* Chapter 2 — Spring /ch2 API */}
          <Route path="chapter2" element={<Chapter2Index />} />
          <Route path="chapter2/desc" element={<Ch2Desc />} />
          <Route path="chapter2/1_chain_workflow" element={<Ch2Chain />} />
          <Route path="chapter2/2_parallelization_workflow" element={<Ch2Parallel />} />
          <Route path="chapter2/3_routing_workflow" element={<Ch2Routing />} />
          <Route path="chapter2/4_orchestrator_workers" element={<Ch2Orch />} />
          <Route path="chapter2/5_evaluator_optimizer" element={<Ch2Eval />} />

          {/* Chapter 3 */}
          <Route path="chapter3" element={<Chapter3Index />} />
          <Route path="chapter3/desc" element={<Ch3Desc />} />
          <Route path="chapter3/1_strategic_analysis" element={<Ch3Strategic />} />
          <Route path="chapter3/2_precision_execution" element={<Ch3Precision />} />
          <Route path="chapter3/3_voting_analysis" element={<Ch3Voting />} />
          <Route path="chapter3/4_auto_pattern_routing" element={<Ch3AutoPatternRouting />} />

          {/* Chapters 4–9 */}
          <Route path="chapter4" element={<Chapter4Index />} />
          <Route path="chapter4/desc" element={<Ch4Desc />} />
          <Route path="chapter4/1_strategic_analysis" element={<Ch4Strategic />} />

          <Route path="chapter5" element={<Chapter5Index />} />
          <Route path="chapter5/desc" element={<Ch5Desc />} />
          <Route path="chapter5/1_strategic_analysis" element={<Ch5Strategic />} />

          <Route path="chapter6" element={<Chapter6Index />} />
          <Route path="chapter6/desc" element={<Ch6Desc />} />
          <Route path="chapter6/1_strategic_analysis" element={<Ch6Strategic />} />

          <Route path="chapter7" element={<Chapter7Index />} />
          <Route path="chapter7/desc" element={<Ch7Desc />} />
          <Route path="chapter7/1_strategic_analysis" element={<Ch7Strategic />} />

          <Route path="chapter8" element={<Chapter8Index />} />
          <Route path="chapter8/desc" element={<Ch8Desc />} />
          <Route path="chapter8/1_strategic_analysis" element={<Ch8Strategic />} />

          <Route path="chapter9" element={<Chapter9Index />} />
          <Route path="chapter9/desc" element={<Ch9Desc />} />
          <Route path="chapter9/1_strategic_analysis" element={<Ch9Strategic />} />

          {/* Setting — React: src/pages/setting (Thymeleaf 본문은 fragment + Page) */}
          <Route path="setting/intellij" element={<SettingIntellij />} />
          <Route path="setting/springai" element={<SettingSpringAi />} />
          <Route path="setting/openai" element={<SettingOpenAi />} />
          <Route path="setting/gemini" element={<SettingGemini />} />
          <Route path="setting/ollama" element={<SettingOllama />} />
          <Route path="setting/redis" element={<SettingRedis />} />
          <Route path="setting/postgresql" element={<SettingPostgreSQL />} />
          <Route path="setting/react" element={<SettingReact />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
