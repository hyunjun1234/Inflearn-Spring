import ch9DescFragment from './ch9DescFragment.html?raw';

/**
 * pages/ch9/desc.html 과 동일 본문 (링크는 React 라우트로 치환)
 */
export default function Ch9Desc() {
  return (
    <div className="col-sm-12" dangerouslySetInnerHTML={{ __html: ch9DescFragment }} />
  );
}
