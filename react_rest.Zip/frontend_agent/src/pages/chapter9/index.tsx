import ch9Fragment from './ch9Fragment.html?raw';
import '../mainCourse.css';

/** Spring fragments/ch9.html 과 동일 본문 */
export default function Chapter9Index() {
  return (
    <div className="main-course-host col-sm-12" dangerouslySetInnerHTML={{ __html: ch9Fragment }} />
  );
}
