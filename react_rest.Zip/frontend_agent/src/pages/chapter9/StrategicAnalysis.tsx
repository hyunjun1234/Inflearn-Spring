import StrategicOnlyChapter from '../../shared/chapters/StrategicOnlyChapter';

const WORKFLOW_OPTIONS = [
  { value: 'strategic-analysis', label: 'strategic-analysis (YAML)' },
  { value: 'strategic-analysis-dsl', label: 'strategic-analysis-dsl (JSON)' },
];

export default function Ch9StrategicAnalysis() {
  return (
    <StrategicOnlyChapter
      chapterPrefix="ch9"
      title="1. Strategic Analysis (Validated DSL)"
      workflowDefinitionOptions={WORKFLOW_OPTIONS}
      workflowDefinitionDefault="strategic-analysis"
    />
  );
}
