import ch6DescFragment from './ch6DescFragment.html?raw';

/**
 * pages/ch6/desc.html 과 동일 본문 (링크는 React 라우트로 치환)
 */
export default function Ch6Desc() {
  return (
    <div className="col-sm-12" dangerouslySetInnerHTML={{ __html: ch6DescFragment }} />
  );
}
