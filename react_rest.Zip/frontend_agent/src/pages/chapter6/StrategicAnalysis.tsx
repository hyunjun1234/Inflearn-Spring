import StrategicOnlyChapter from '../../shared/chapters/StrategicOnlyChapter';

export default function Ch6StrategicAnalysis() {
  return <StrategicOnlyChapter chapterPrefix="ch6" title="1. Strategic Analysis" />;
}
