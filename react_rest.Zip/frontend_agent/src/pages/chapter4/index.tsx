import ch4Fragment from './ch4Fragment.html?raw';
import '../mainCourse.css';

/** Spring edu/.../templates/fragments/ch4.html 과 동일 본문 (링크는 React Router 경로) */
export default function Chapter4Index() {
  return (
    <div className="main-course-host col-sm-12" dangerouslySetInnerHTML={{ __html: ch4Fragment }} />
  );
}
