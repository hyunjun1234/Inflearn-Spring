import ch4DescFragment from './ch4DescFragment.html?raw';

/**
 * pages/ch4/desc.html 과 동일 본문 (인라인 스타일·다이어그램·링크는 React 라우트로 치환)
 */
export default function Ch4Desc() {
  return (
    <div className="col-sm-12" dangerouslySetInnerHTML={{ __html: ch4DescFragment }} />
  );
}
