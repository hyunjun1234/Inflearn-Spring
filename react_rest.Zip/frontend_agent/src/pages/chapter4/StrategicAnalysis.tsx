import StrategicOnlyChapter from '../../shared/chapters/StrategicOnlyChapter';

export default function Ch4StrategicAnalysis() {
  return <StrategicOnlyChapter chapterPrefix="ch4" title="1. Strategic Analysis" />;
}
