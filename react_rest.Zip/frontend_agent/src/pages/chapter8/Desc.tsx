import ch8DescFragment from './ch8DescFragment.html?raw';

/**
 * pages/ch8/desc.html 과 동일 본문 (링크는 React 라우트로 치환)
 */
export default function Ch8Desc() {
  return (
    <div className="col-sm-12" dangerouslySetInnerHTML={{ __html: ch8DescFragment }} />
  );
}
