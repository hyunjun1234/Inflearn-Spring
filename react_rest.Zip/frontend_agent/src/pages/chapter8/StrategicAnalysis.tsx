import StrategicOnlyChapter from '../../shared/chapters/StrategicOnlyChapter';

const EXTRA = { workflowDefinition: 'strategic-analysis' };

export default function Ch8StrategicAnalysis() {
  return (
    <StrategicOnlyChapter chapterPrefix="ch8" title="1. Strategic Analysis (YAML)" extraFormFields={EXTRA} />
  );
}
