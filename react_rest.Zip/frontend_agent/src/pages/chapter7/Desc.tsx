import ch7DescFragment from './ch7DescFragment.html?raw';

/**
 * pages/ch7/desc.html 과 동일 본문 (링크는 React 라우트로 치환)
 */
export default function Ch7Desc() {
  return (
    <div className="col-sm-12" dangerouslySetInnerHTML={{ __html: ch7DescFragment }} />
  );
}
