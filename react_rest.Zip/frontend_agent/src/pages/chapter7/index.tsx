import ch7Fragment from './ch7Fragment.html?raw';
import '../mainCourse.css';

/** Spring `edu/.../templates/fragments/ch7.html` 과 동일 본문 (`ch7Fragment.html`, Thymeleaf 링크는 React 경로로 치환) */
export default function Chapter7Index() {
  return (
    <div className="main-course-host col-sm-12" dangerouslySetInnerHTML={{ __html: ch7Fragment }} />
  );
}
