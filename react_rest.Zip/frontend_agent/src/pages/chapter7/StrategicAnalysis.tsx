import StrategicOnlyChapter from '../../shared/chapters/StrategicOnlyChapter';

export default function Ch7StrategicAnalysis() {
  return <StrategicOnlyChapter chapterPrefix="ch7" title="1. Strategic Analysis" />;
}
