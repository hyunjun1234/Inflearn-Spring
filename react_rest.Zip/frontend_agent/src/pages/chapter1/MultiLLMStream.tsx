import { useState, useCallback } from 'react';
import { streamRequest } from '../../api/client';
import { ch1Img } from './ch1Assets';

/**
 * pages/ch1/2_multi_llm_stream.html — POST /ch1/multi_llm_stream (스트리밍)
 */
export default function MultiLLMStream() {
  const [type, setType] = useState('openai');
  const [question, setQuestion] = useState('서울의 맛집 알려줘');
  const [loading, setLoading] = useState(false);
  const [blocks, setBlocks] = useState<{ id: string; kind: 'user' | 'bot'; text: string; time: string }[]>([]);

  const send = useCallback(async () => {
    const q = question.trim();
    if (!q || loading) return;

    const t = new Date().toLocaleTimeString('ko-KR');
    const uid = crypto.randomUUID();
    setBlocks((b) => [{ id: uid, kind: 'user', text: `${type}:${q}`, time: t }, ...b]);
    setQuestion('');
    setLoading(true);

    const botId = crypto.randomUUID();
    setBlocks((b) => [{ id: botId, kind: 'bot', text: '', time: new Date().toLocaleTimeString('ko-KR') }, ...b]);

    try {
      await streamRequest(
        '/ch1/multi_llm_stream',
        new URLSearchParams({ prompt: q, type }),
        (full) => {
          setBlocks((prev) =>
            prev.map((x) => (x.id === botId ? { ...x, text: full } : x))
          );
        }
      );
    } catch (e) {
      console.error(e);
      setBlocks((prev) =>
        prev.map((x) =>
          x.id === botId
            ? { ...x, text: `오류: ${e instanceof Error ? e.message : String(e)}` }
            : x
        )
      );
    } finally {
      setLoading(false);
    }
  }, [question, type, loading]);

  return (
    <div className="col-sm-12">
      <h2 className="text-center">2. Multi LLM - Reactive Streams</h2>
      <div className="container py-5">
        <div className="row d-flex justify-content-center">
          <div className="col-sm-10">
            <button className="btn btn-primary" disabled type="button" style={{ visibility: loading ? 'visible' : 'hidden' }}>
              <span className="spinner-border spinner-border-sm" role="status" />
              Loading..
            </button>
            <div className="row justify-content-center">
              <div className="col-sm-5">
                <div className="input-group p-1">
                  <span className="input-group-text">구분</span>
                  <select className="form-control" value={type} onChange={(e) => setType(e.target.value)}>
                    <option value="openai">OpenAI</option>
                    <option value="gemini">Gemini</option>
                    <option value="llama">Llama</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="card">
              <div className="card-header text-muted d-flex justify-content-start align-items-center p-3">
                <div className="input-group mb-0 w-100">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Type message"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && send()}
                  />
                  <button type="button" className="btn btn-primary" onClick={send} disabled={loading}>
                    Send
                  </button>
                </div>
              </div>
              <div className="card-body">
                {blocks.map((msg) => (
                  <div key={msg.id} className="mb-3">
                    {msg.kind === 'user' ? (
                      <>
                        <div className="d-flex justify-content-between">
                          <p className="small mb-1">User</p>
                          <p className="small mb-1 text-muted">{msg.time}</p>
                        </div>
                        <div className="d-flex flex-row justify-content-start align-items-start">
                          <img
                            src={ch1Img('/imgs/user.jpg')}
                            alt="User"
                            width={45}
                            height={45}
                            style={{ width: 45, height: 45, objectFit: 'cover', flexShrink: 0 }}
                          />
                          <div>
                            <p className="small p-2 ms-3 mb-3 rounded-3 bg-warning">{msg.text}</p>
                          </div>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="d-flex justify-content-between">
                          <p className="small mb-1 text-muted">{msg.time}</p>
                          <p className="small mb-1">Chatbot</p>
                        </div>
                        <div className="d-flex flex-row justify-content-end align-items-start mb-4 pt-1">
                          <div className="small p-2 me-3 mb-3 rounded-3 bg-info" style={{ overflow: 'auto' }}>
                            <pre className="text-white mb-0" style={{ fontWeight: 'bold', whiteSpace: 'pre-wrap' }}>
                              {msg.text}
                            </pre>
                          </div>
                          <img
                            src={ch1Img('/imgs/chatbot.png')}
                            alt="Chat Bot"
                            width={45}
                            height={45}
                            style={{ width: 45, height: 45, objectFit: 'cover', flexShrink: 0 }}
                          />
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
