import { useState, useCallback } from 'react';
import { postRequest } from '../../api/client';
import Ch1ExamplePanel from '../../shared/ch1/Ch1ExamplePanel';
import { CH1_ROUTER_EXAMPLES } from '../../shared/ch1/ch1ExamplePrompts';
import { ch1Img } from './ch1Assets';

type Msg = { id: string; role: 'user' | 'bot'; text: string; time: string };

/**
 * pages/ch1/4_router.html — POST /ch1/router (prompt only)
 */
export default function RouterPage() {
  const [question, setQuestion] = useState('이차 방정식에 대한 기본 예제를 만들어줘');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);

  const send = useCallback(async () => {
    const q = question.trim();
    if (!q || loading) return;

    const time = new Date().toLocaleTimeString('ko-KR');
    setMessages((m) => [{ id: crypto.randomUUID(), role: 'user', text: q, time }, ...m]);
    setQuestion('');
    setLoading(true);

    try {
      const text = await postRequest(
        '/ch1/router',
        new URLSearchParams({ prompt: q }),
        { Accept: 'text/plain' }
      );
      setMessages((m) => [
        { id: crypto.randomUUID(), role: 'bot', text, time: new Date().toLocaleTimeString('ko-KR') },
        ...m,
      ]);
    } catch (e) {
      console.error(e);
      setMessages((m) => [
        {
          id: crypto.randomUUID(),
          role: 'bot',
          text: `오류: ${e instanceof Error ? e.message : String(e)}`,
          time: new Date().toLocaleTimeString('ko-KR'),
        },
        ...m,
      ]);
    } finally {
      setLoading(false);
    }
  }, [question, loading]);

  return (
    <div className="col-sm-12">
      <h2 className="text-center">4. Router</h2>
      <Ch1ExamplePanel title="입력 예시 (RouterService 분류: CREATIVE / TECHNICAL / GENERAL — 화면 기본값과 같은 문장을 붙여 넣어 볼 수 있습니다)">
        <ul className="mb-0 ps-3" style={{ lineHeight: 1.65 }}>
          {CH1_ROUTER_EXAMPLES.map((ex, i) => (
            <li key={ex.badge} className={i === CH1_ROUTER_EXAMPLES.length - 1 ? 'mb-0' : 'mb-2'}>
              <span className="badge bg-secondary me-1">{ex.badge}</span>
              <span className="text-muted small me-1">({ex.hint})</span>
              <br />
              <code className="small text-dark" style={{ color: '#212529' }}>
                {ex.text}
              </code>
            </li>
          ))}
        </ul>
      </Ch1ExamplePanel>
      <div className="container py-5">
        <div className="row d-flex justify-content-center">
          <div className="col-sm-10">
            <button className="btn btn-primary" disabled type="button" style={{ visibility: loading ? 'visible' : 'hidden' }}>
              <span className="spinner-border spinner-border-sm" role="status" />
              Loading..
            </button>
            <div className="card">
              <div className="card-header text-muted d-flex justify-content-start align-items-center p-3">
                <div className="input-group mb-0 w-100">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Type message"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && send()}
                  />
                  <button type="button" className="btn btn-primary" onClick={send} disabled={loading}>
                    Send
                  </button>
                </div>
              </div>
              <div className="card-body">
                {messages.map((msg) => (
                  <div key={msg.id} className="mb-3">
                    {msg.role === 'user' ? (
                      <>
                        <div className="d-flex justify-content-between">
                          <p className="small mb-1">User</p>
                          <p className="small mb-1 text-muted">{msg.time}</p>
                        </div>
                        <div className="d-flex flex-row justify-content-start align-items-start">
                          <img
                            src={ch1Img('/imgs/user.jpg')}
                            alt="User"
                            width={45}
                            height={45}
                            style={{ width: 45, height: 45, objectFit: 'cover', flexShrink: 0 }}
                          />
                          <div>
                            <p className="small p-2 ms-3 mb-3 rounded-3 bg-warning">{msg.text}</p>
                          </div>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="d-flex justify-content-between">
                          <p className="small mb-1 text-muted">{msg.time}</p>
                          <p className="small mb-1">Chatbot</p>
                        </div>
                        <div className="d-flex flex-row justify-content-end align-items-start mb-4 pt-1">
                          <div className="small p-2 me-3 mb-3 rounded-3 bg-info" style={{ overflow: 'auto' }}>
                            <pre className="text-white mb-0" style={{ fontWeight: 'bold', whiteSpace: 'pre-wrap' }}>
                              {msg.text}
                            </pre>
                          </div>
                          <img
                            src={ch1Img('/imgs/chatbot.png')}
                            alt="Chat Bot"
                            width={45}
                            height={45}
                            style={{ width: 45, height: 45, objectFit: 'cover', flexShrink: 0 }}
                          />
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
