import ch1DescFragment from './ch1DescFragment.html?raw';

/**
 * pages/ch1/desc.html 과 동일 본문
 * (실습 표, Resilience4j 의존성, CircuitBreaker vs try/catch 비교·장단점, YAML 예시 주석)
 */
export default function Desc() {
  return (
    <div className="col-sm-12" dangerouslySetInnerHTML={{ __html: ch1DescFragment }} />
  );
}
