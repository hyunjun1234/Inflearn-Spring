import { useState, useCallback } from 'react';
import { postRequest } from '../../api/client';
import { ch1Img } from './ch1Assets';

type Msg = { id: string; role: 'user' | 'bot'; text: string; time: string };

/**
 * pages/ch1/1_multi_llm.html — POST /ch1/multi_llm (prompt, type)
 */
export default function MultiLLM() {
  const [type, setType] = useState('openai');
  const [question, setQuestion] = useState('서울의 맛집 알려줘');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);

  const send = useCallback(async () => {
    const q = question.trim();
    if (!q || loading) return;

    const time = new Date().toLocaleTimeString('ko-KR');
    const userMsg: Msg = {
      id: crypto.randomUUID(),
      role: 'user',
      text: `${type}:${q}`,
      time,
    };
    setMessages((m) => [userMsg, ...m]);
    setQuestion('');
    setLoading(true);

    try {
      const text = await postRequest(
        '/ch1/multi_llm',
        new URLSearchParams({ prompt: q, type }),
        { Accept: 'text/plain' }
      );
      setMessages((m) => [
        {
          id: crypto.randomUUID(),
          role: 'bot',
          text,
          time: new Date().toLocaleTimeString('ko-KR'),
        },
        ...m,
      ]);
    } catch (e) {
      console.error(e);
      setMessages((m) => [
        {
          id: crypto.randomUUID(),
          role: 'bot',
          text: `오류: ${e instanceof Error ? e.message : String(e)}`,
          time: new Date().toLocaleTimeString('ko-KR'),
        },
        ...m,
      ]);
    } finally {
      setLoading(false);
    }
  }, [question, type, loading]);

  return (
    <div className="col-sm-12">
      <h2 className="text-center">1. Multi LLM</h2>
      <div className="container py-5">
        <div className="row d-flex justify-content-center">
          <div className="col-sm-10">
            <button className="btn btn-primary" disabled type="button" style={{ visibility: loading ? 'visible' : 'hidden' }}>
              <span className="spinner-border spinner-border-sm" role="status" />
              Loading..
            </button>
            <div className="row justify-content-center">
              <div className="col-sm-5">
                <div className="input-group p-1">
                  <span className="input-group-text">구분</span>
                  <select className="form-control" value={type} onChange={(e) => setType(e.target.value)}>
                    <option value="openai">OpenAI</option>
                    <option value="gemini">Gemini</option>
                    <option value="llama">Llama</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="card">
              <div className="card-header text-muted d-flex justify-content-start align-items-center p-3">
                <div className="input-group mb-0 w-100">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Type message"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && send()}
                  />
                  <button type="button" className="btn btn-primary" onClick={send} disabled={loading}>
                    Send
                  </button>
                </div>
              </div>
              <div className="card-body">
                {messages.map((msg) => (
                  <div key={msg.id} className="mb-3">
                    {msg.role === 'user' ? (
                      <>
                        <div className="d-flex justify-content-between">
                          <p className="small mb-1">User</p>
                          <p className="small mb-1 text-muted">{msg.time}</p>
                        </div>
                        <div className="d-flex flex-row justify-content-start align-items-start">
                          <img
                            src={ch1Img('/imgs/user.jpg')}
                            alt="User"
                            width={45}
                            height={45}
                            style={{ width: 45, height: 45, objectFit: 'cover', flexShrink: 0 }}
                          />
                          <div>
                            <p className="small p-2 ms-3 mb-3 rounded-3 bg-warning">{msg.text}</p>
                          </div>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="d-flex justify-content-between">
                          <p className="small mb-1 text-muted">{msg.time}</p>
                          <p className="small mb-1">Chatbot</p>
                        </div>
                        <div className="d-flex flex-row justify-content-end align-items-start mb-4 pt-1">
                          <div className="small p-2 me-3 mb-3 rounded-3 bg-info" style={{ overflow: 'auto' }}>
                            <pre className="text-white mb-0" style={{ fontWeight: 'bold', whiteSpace: 'pre-wrap' }}>
                              {msg.text}
                            </pre>
                          </div>
                          <img
                            src={ch1Img('/imgs/chatbot.png')}
                            alt="Chat Bot"
                            width={45}
                            height={45}
                            style={{ width: 45, height: 45, objectFit: 'cover', flexShrink: 0 }}
                          />
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
