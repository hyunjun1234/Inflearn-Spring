import ch1Fragment from './ch1Fragment.html?raw';
import '../mainCourse.css';

/**
 * Spring edu/.../templates/fragments/ch1.html 과 동일 본문 (React 라우트 경로로 링크만 치환)
 */
export default function Chapter1Index() {
  return (
    <div className="main-course-host col-sm-12" dangerouslySetInnerHTML={{ __html: ch1Fragment }} />
  );
}
