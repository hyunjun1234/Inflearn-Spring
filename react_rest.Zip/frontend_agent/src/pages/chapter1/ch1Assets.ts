import { springImg as ch1Img } from '../../shared/chat/springImg';

export { ch1Img };
