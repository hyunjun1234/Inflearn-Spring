import mainCourseBody from './mainCourseBody.html?raw';
import './mainCourse.css';

/**
 * springai2_agent_temp `edu/.../fragments/main.html` 과 동일 본문 (npm run sync:main 으로 갱신)
 * Thymeleaf `th:href` 는 React 경로(`/chapterN`, `/chapterN/desc`)로 치환됨.
 * 앵커 `#ch1`…`#app-b` 는 그대로; 상세 장은 /chapter1 … 라우트.
 */
export default function Home() {
  return (
    <div className="main-course-host col-sm-12" dangerouslySetInnerHTML={{ __html: mainCourseBody }} />
  );
}
