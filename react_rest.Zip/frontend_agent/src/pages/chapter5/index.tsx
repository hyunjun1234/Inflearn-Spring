import ch5Fragment from './ch5Fragment.html?raw';
import '../mainCourse.css';

/** Spring edu/.../templates/fragments/ch5.html 과 동일 본문 (링크는 React Router 경로) */
export default function Chapter5Index() {
  return (
    <div className="main-course-host col-sm-12" dangerouslySetInnerHTML={{ __html: ch5Fragment }} />
  );
}
