import StrategicOnlyChapter from '../../shared/chapters/StrategicOnlyChapter';

export default function Ch5StrategicAnalysis() {
  return <StrategicOnlyChapter chapterPrefix="ch5" title="1. Strategic Analysis" />;
}
