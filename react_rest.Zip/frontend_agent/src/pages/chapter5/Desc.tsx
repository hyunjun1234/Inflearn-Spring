import ch5DescFragment from './ch5DescFragment.html?raw';

/**
 * Spring `edu/src/main/resources/templates/pages/ch5/desc.html` 과 동일 본문.
 * `ch5DescFragment.html`에 두고, Thymeleaf 링크만 React 경로(`/chapter5/…`, `/chapter4/desc#…`)로 치환합니다.
 */
export default function Ch5Desc() {
  return (
    <div className="col-sm-12" dangerouslySetInnerHTML={{ __html: ch5DescFragment }} />
  );
}
