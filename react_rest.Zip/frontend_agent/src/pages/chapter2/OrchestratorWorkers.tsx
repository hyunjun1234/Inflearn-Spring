import NdjsonPromptLab from '../../shared/ch2/NdjsonPromptLab';
import Ch2ExamplePanel from '../../shared/ch2/Ch2ExamplePanel';
import { CH2_ORCHESTRATOR_ALT, CH2_ORCHESTRATOR_DEFAULT } from '../../shared/ch2/ch2ExamplePrompts';

export default function OrchestratorWorkers() {
  return (
    <NdjsonPromptLab
      title="4. Orchestrator-Workers"
      endpoint="/ch2/orchestrator-workers"
      defaultQuestion={CH2_ORCHESTRATOR_DEFAULT}
      exampleBanner={
        <Ch2ExamplePanel title="입력 예시 (기본값·추가 예시 문장)">
          <ul className="mb-0 ps-3">
            <li className="mb-2">
              <span className="badge bg-secondary me-1">예시 1 · 기본값</span>
              <strong>K-푸드 유럽 진출</strong> —{' '}
              <code className="small text-dark" style={{ color: '#212529' }}>
                {CH2_ORCHESTRATOR_DEFAULT}
              </code>
            </li>
            <li className="mb-0">
              <span className="badge bg-secondary me-1">예시 2</span>
              <strong>전고체 배터리 분석</strong> —{' '}
              <code className="small text-dark" style={{ color: '#212529' }}>
                {CH2_ORCHESTRATOR_ALT}
              </code>
            </li>
          </ul>
        </Ch2ExamplePanel>
      }
    />
  );
}
