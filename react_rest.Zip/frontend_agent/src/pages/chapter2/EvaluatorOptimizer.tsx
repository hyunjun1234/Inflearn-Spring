import NdjsonPromptLab from '../../shared/ch2/NdjsonPromptLab';
import Ch2ExamplePanel from '../../shared/ch2/Ch2ExamplePanel';
import { CH2_EVALUATOR_ALT, CH2_EVALUATOR_DEFAULT } from '../../shared/ch2/ch2ExamplePrompts';

export default function EvaluatorOptimizer() {
  return (
    <NdjsonPromptLab
      title="5. Evaluator-Optimizer"
      endpoint="/ch2/evaluator-optimizer"
      defaultQuestion={CH2_EVALUATOR_DEFAULT}
      exampleBanner={
        <Ch2ExamplePanel title="입력 예시 (기본값·추가 예시 문장)">
          <ul className="mb-0 ps-3">
            <li className="mb-2">
              <span className="badge bg-secondary me-1">예시 1 · 기본값</span>
              <strong>엘리베이터 피치</strong> —{' '}
              <code className="small text-dark" style={{ color: '#212529' }}>
                {CH2_EVALUATOR_DEFAULT}
              </code>
            </li>
            <li className="mb-0">
              <span className="badge bg-secondary me-1">예시 2</span>
              <strong>SQL 튜닝 가이드</strong> —{' '}
              <code className="small text-dark" style={{ color: '#212529' }}>
                {CH2_EVALUATOR_ALT}
              </code>
            </li>
          </ul>
        </Ch2ExamplePanel>
      }
    />
  );
}
