import NdjsonPromptLab from '../../shared/ch2/NdjsonPromptLab';
import Ch2ExamplePanel from '../../shared/ch2/Ch2ExamplePanel';
import {
  CH2_ROUTING_COMPLEX,
  CH2_ROUTING_SEARCH,
  CH2_ROUTING_SIMPLE,
} from '../../shared/ch2/ch2ExamplePrompts';

export default function RoutingWorkflow() {
  return (
    <NdjsonPromptLab
      title="3. Routing Workflow"
      endpoint="/ch2/routing-workflow"
      defaultQuestion={CH2_ROUTING_SIMPLE}
      exampleBanner={
        <Ch2ExamplePanel title="라우팅(SIMPLE / COMPLEX / SEARCH) 검증용 예시 문장">
          <ul className="mb-0 ps-3">
            <li className="mb-2">
              <span className="badge bg-success me-1">SIMPLE</span>
              <strong>단순 대화</strong> —{' '}
              <code className="small text-dark" style={{ color: '#212529' }}>
                {CH2_ROUTING_SIMPLE}
              </code>
            </li>
            <li className="mb-2">
              <span className="badge bg-primary me-1">COMPLEX</span>
              <strong>복잡한 설계·아키텍처</strong> —{' '}
              <code className="small text-dark" style={{ color: '#212529' }}>
                {CH2_ROUTING_COMPLEX}
              </code>
            </li>
            <li className="mb-0">
              <span className="badge bg-info text-dark me-1">SEARCH</span>
              <strong>최신 트렌드·뉴스</strong> —{' '}
              <code className="small text-dark" style={{ color: '#212529' }}>
                {CH2_ROUTING_SEARCH}
              </code>
            </li>
          </ul>
        </Ch2ExamplePanel>
      }
    />
  );
}
