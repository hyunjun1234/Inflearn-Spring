import ch2DescFragment from './ch2DescFragment.html?raw';

/**
 * pages/ch2/desc.html 과 동일 본문
 */
export default function Ch2Desc() {
  return (
    <div className="col-sm-12" dangerouslySetInnerHTML={{ __html: ch2DescFragment }} />
  );
}
