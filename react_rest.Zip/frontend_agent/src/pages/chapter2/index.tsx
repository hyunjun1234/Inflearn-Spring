import ch2Fragment from './ch2Fragment.html?raw';
import '../mainCourse.css';

/** Spring edu/.../templates/fragments/ch2.html 과 동일 본문 (링크는 React Router 경로) */
export default function Chapter2Index() {
  return (
    <div className="main-course-host col-sm-12" dangerouslySetInnerHTML={{ __html: ch2Fragment }} />
  );
}
