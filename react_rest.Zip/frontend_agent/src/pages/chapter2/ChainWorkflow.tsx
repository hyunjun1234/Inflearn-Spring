import NdjsonPromptLab from '../../shared/ch2/NdjsonPromptLab';
import Ch2ExamplePanel from '../../shared/ch2/Ch2ExamplePanel';
import { ChainWorkflowHints } from '../../shared/ch2/chainHints';
import {
  CH2_CHAIN_EXAMPLE_COFFEE,
  CH2_CHAIN_EXAMPLE_JEJU,
  CH2_CHAIN_EXAMPLE_QUANTUM,
} from '../../shared/ch2/ch2ExamplePrompts';

export default function ChainWorkflow() {
  return (
    <NdjsonPromptLab
      title="1. Chain Workflow"
      endpoint="/ch2/chain-workflow"
      defaultQuestion={CH2_CHAIN_EXAMPLE_COFFEE}
      hints={<ChainWorkflowHints />}
      exampleBanner={
        <Ch2ExamplePanel title="입력 예시 (화면 기본값과 같은 문장을 붙여 넣어 볼 수 있습니다)">
          <ul className="mb-0 ps-3">
            <li className="mb-2">
              <span className="badge bg-secondary me-1">예시 1</span>
              <strong>힐링 여행 아이디어</strong> —{' '}
              <code className="small text-dark" style={{ color: '#212529' }}>
                {CH2_CHAIN_EXAMPLE_JEJU}
              </code>
            </li>
            <li className="mb-2">
              <span className="badge bg-secondary me-1">예시 2</span>
              <strong>기술 리포트 주제</strong> —{' '}
              <code className="small text-dark" style={{ color: '#212529' }}>
                {CH2_CHAIN_EXAMPLE_QUANTUM}
              </code>
            </li>
            <li className="mb-0">
              <span className="badge bg-secondary me-1">예시 3 · 기본값</span>
              <strong>스타트업 아이디어</strong> —{' '}
              <code className="small text-dark" style={{ color: '#212529' }}>
                {CH2_CHAIN_EXAMPLE_COFFEE}
              </code>
            </li>
          </ul>
        </Ch2ExamplePanel>
      }
    />
  );
}
