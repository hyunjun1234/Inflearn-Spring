export { default } from '../../shared/ch2/ParallelWorkflowLab';
