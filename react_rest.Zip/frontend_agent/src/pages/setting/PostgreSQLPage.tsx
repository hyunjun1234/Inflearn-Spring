import postgresqlFragment from './postgresqlFragment.html?raw';

/**
 * pages/setting/postgresql.html 과 동일 본문 (설정 하단 링크는 React 라우트)
 */
export default function PostgreSQLPage() {
  return (
    <div className="col-sm-12" dangerouslySetInnerHTML={{ __html: postgresqlFragment }} />
  );
}
