import SettingFooter from './SettingFooter';
import './setting.css';

const WIN_GENERATE = [
  'curl http://localhost:11434/api/generate ^',
  '      -H "Content-Type: application/json" ^',
  '      -d "{\\"model\\":\\"llama3.2\\",\\"prompt\\":\\"Hello\\",\\"stream\\":false}"',
].join('\n');

export default function OllamaPage() {
  return (
    <div className="setting-course-main">
      <header className="setting-course-hero">
        <h1>Ollama 환경 설정</h1>
      </header>

      <div className="setting-course-overview">
        <p className="meta">Docker · Ollama 이미지·컨테이너 · LLaMA 3.2 로컬 모델 · API 동작 확인</p>
        <p>
          로컬에서 LLM을 쓰기 위해 Docker로 <strong>Ollama</strong> 서버를 띄우고, 컨테이너 안에서 모델을 받아 <code>localhost:11434</code>로 호출합니다. Spring
          AI의 Ollama 연동 실습 전제가 되는 절차입니다.
        </p>
      </div>

      <nav className="setting-course-toc" aria-label="목차">
        <p className="setting-course-toc-title">목차</p>
        <ol>
          <li>
            <a href="#ol-s1">Docker 설치</a>
          </li>
          <li>
            <a href="#ol-s2">Ollama 이미지 다운로드 및 컨테이너 실행</a>
          </li>
          <li>
            <a href="#ol-s3">LLaMA 3.2 모델 준비</a>
          </li>
          <li>
            <a href="#ol-s4">Ollama 및 llama3.2 접속 확인</a>
          </li>
        </ol>
      </nav>

      <div className="setting-course-content">
        <hr className="setting-course-divider" />

        <h3 id="ol-s1">1. Docker 설치</h3>
        <p>
          <a href="https://docs.docker.com/get-started/get-docker/" target="_blank" rel="noopener noreferrer">
            Docker — Get Docker
          </a>
          — OS에 맞는 <strong>Docker Desktop</strong>(또는 Linux의 Docker Engine)을 설치합니다. 설치 후 터미널에서 <code>docker version</code>으로 클라이언트와 엔진이
          모두 응답하는지 확인하세요.
        </p>

        <h6>설치 시 주의 사항</h6>
        <ul>
          <li>
            <strong>Windows</strong>: Docker Desktop은 보통 <strong>WSL 2</strong> 기반입니다. BIOS/UEFI에서 가상화(VT-x/AMD-V)가 켜져 있어야 하고, WSL2 설치·업데이트는 공식
            가이드를 따릅니다.
          </li>
          <li>
            <strong>리소스</strong>: Docker Desktop → <strong>Settings → Resources</strong>에서 CPU·메모리·디스크를 할당합니다. Ollama·모델 이미지는 디스크와 RAM을 많이 사용합니다.
          </li>
          <li>
            <strong>포트</strong>: 다음 절에서 쓰는 <code>11434</code> 포트가 로컬의 다른 서비스와 겹치지 않는지 확인합니다.
          </li>
          <li>
            <strong>회사망·보안</strong>: 프록시/VPN/백신이 Docker Hub 접속이나 <code>docker pull</code>을 막을 수 있습니다. 필요하면 IT 정책에 맞게 설정합니다.
          </li>
          <li>
            <strong>관리자 권한</strong>: 설치·업데이트 시 관리자 권한이 필요할 수 있습니다.
          </li>
        </ul>

        <h6>문제 발생 시 해결 방안</h6>
        <ul>
          <li>
            <code>docker</code>를 찾을 수 없음 → Docker Desktop이 설치되어 있고 <strong>실행 중</strong>인지(시스템 트레이) 확인합니다.
          </li>
          <li>
            <code>Cannot connect to the Docker daemon</code> → Docker Desktop을 완전히 종료 후 다시 실행하거나 PC 재부팅 후 재시도합니다.
          </li>
          <li>
            <code>port is already allocated</code> → <code>11434</code>를 쓰는 프로세스·컨테이너를 종료하거나, 다음 절의 <code>docker run</code>에서 호스트 포트만 다른 값(예:{' '}
            <code>-p 11435:11434</code>)으로 바꿉니다.
          </li>
          <li>이미지 <code>pull</code> 실패 → 네트워크·DNS·방화벽을 확인하고, 잠시 후 재시도하거나 Docker 공식 문서의 네트워크/프록시 항목을 참고합니다.</li>
          <li>
            WSL 관련 오류(Windows) → Docker Desktop → <strong>Settings → Resources → WSL integration</strong>에서 배포판 연동을 켜고, <code>wsl --update</code> 등으로 환경을
            점검합니다.
          </li>
        </ul>

        <hr className="setting-course-divider" />

        <h3 id="ol-s2">2. Ollama 이미지 다운로드 및 컨테이너 실행</h3>
        <p>
          <strong>Docker Desktop을 실행</strong> 후 명령 프롬프트에서 이미지를 받은 다음 컨테이너를 띄웁니다. <br />
          컨테이너 이름은 <code>ollama-server</code>, 포트는 <code>11434</code>로 맞춥니다.
        </p>
        <pre>docker pull ollama/ollama:latest</pre>
        <pre>docker run -d --name ollama-server -p 11434:11434 ollama/ollama:latest</pre>
        <p>설치 후 Docker Desktop의 Containers에서 상태를 확인할 수 있습니다.</p>

        <hr className="setting-course-divider" />

        <h3 id="ol-s3">3. LLaMA 3.2 모델 준비</h3>
        <p>컨테이너 안에서 LLaMA 3.2 모델을 받습니다.</p>
        <pre>docker exec -it ollama-server ollama pull llama3.2</pre>
        <p>이후 Docker Desktop → Containers에서 해당 컨테이너를 중지·시작할 수 있습니다.</p>

        <hr className="setting-course-divider" />

        <h3 id="ol-s4">4. Ollama 및 llama3.2 접속 확인</h3>
        <p>
          <strong>1)</strong> Ollama API 태그 목록 - 명령 프롬프트에서 실행
        </p>
        <pre>curl http://localhost:11434/api/tags</pre>
        <p>
          <strong>2)</strong> llama3.2 생성 요청
          <br /> Windows 명령 프롬프트
        </p>
        <pre>{WIN_GENERATE}</pre>
        <p>Mac / Linux (bash, zsh)</p>
        <pre>{`curl http://localhost:11434/api/generate -d '{
  "model": "llama3.2",
  "prompt": "Hello",
  "stream": false
}'`}</pre>
        <p>
          <strong>로컬 LLM 환경에서 llama3.2 기반 호출이 가능한 상태입니다.</strong>
        </p>

        <SettingFooter />
      </div>
    </div>
  );
}
