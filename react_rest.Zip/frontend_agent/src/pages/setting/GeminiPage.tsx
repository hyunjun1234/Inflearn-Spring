import { springImg } from '../../shared/chat/springImg';
import SettingFooter from './SettingFooter';
import './setting.css';

export default function GeminiPage() {
  return (
    <div className="setting-course-main">
      <header className="setting-course-hero">
        <h1>Gemini 환경 설정</h1>
      </header>

      <div className="setting-course-overview">
        <p className="meta">
          Google AI Studio API 키 · 프로젝트 연결 · Spring Boot <code>.env</code> 연동
        </p>
        <p>
          Gemini API는 <strong>Google AI Studio</strong>에서 프로젝트와 API 키를 만든 뒤, Spring AI 설정의 <code>GEMINI_KEY</code> 등과 연결합니다. 키와 프로젝트 ID는
          버전 관리에 포함하지 않습니다.
        </p>
      </div>

      <nav className="setting-course-toc" aria-label="목차">
        <p className="setting-course-toc-title">목차</p>
        <ol>
          <li>
            <a href="#gm-s1">API 키 발급</a>
          </li>
          <li>
            <a href="#gm-s2">Gemini 문서</a>
          </li>
          <li>
            <a href="#gm-s3">Spring Boot 프로젝트에 키 입력</a>
          </li>
        </ol>
      </nav>

      <div className="setting-course-content">
        <hr className="setting-course-divider" />

        <h3 id="gm-s1">1. API 키 발급</h3>
        <p>
          <a href="https://aistudio.google.com/api-keys" target="_blank" rel="noopener noreferrer">
            Google AI Studio — API Keys
          </a>
        </p>
        <ol>
          <li>
            <strong>Projects</strong> → 새 프로젝트 생성
          </li>
          <li>
            <strong>API Keys</strong> → <em>Create API key</em> — 키를 만들 때 위에서 만든 프로젝트를 선택합니다.
          </li>
        </ol>
        <figure>
          <img src={springImg('/imgs/gemini.png')} alt="Gemini API 키 생성 화면 예시" />
        </figure>

        <hr className="setting-course-divider" />

        <h3 id="gm-s2">2. Gemini 문서</h3>
        <p>
          <a href="https://ai.google.dev/gemini-api/docs" target="_blank" rel="noopener noreferrer">
            Gemini API Documentation
          </a>
        </p>

        <hr className="setting-course-divider" />

        <h3 id="gm-s3">3. Spring Boot 프로젝트에 키 정보 입력</h3>
        <p>
          프로젝트 루트에 <code>.env</code>를 두고 키를 저장합니다. Git에는 올리지 않도록 <code>.gitignore</code>에 등록합니다.
        </p>
        <figure>
          <img src={springImg('/imgs/env.png')} alt=".env 파일 예시" />
        </figure>
        <pre>{`OPEN_AI_KEY=sk-proj-TcdDCv
GEMINI_KEY=AIzaSyDkpW5sh1I`}</pre>
        <p>Spring Boot가 <code>.env</code>를 읽도록 yml에 다음을 추가합니다.</p>
        <pre>{`spring:
  config:
    import: optional:file:.env[.properties]`}</pre>

        <SettingFooter />
      </div>
    </div>
  );
}
