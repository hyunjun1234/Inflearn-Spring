import { Link, useLocation } from 'react-router-dom';

const LINKS: { to: string; label: string }[] = [
  { to: '/setting/intellij', label: 'IntelliJ' },
  { to: '/setting/springai', label: 'Spring AI' },
  { to: '/setting/openai', label: 'OpenAI' },
  { to: '/setting/gemini', label: 'Gemini' },
  { to: '/setting/ollama', label: 'Ollama' },
  { to: '/setting/redis', label: 'Redis' },
  { to: '/setting/postgresql', label: 'PostgreSQL' },
  { to: '/setting/react', label: 'React' },
];

/** Thymeleaf 하단 “다른 환경 설정 가이드” — React Router 링크 */
export default function SettingFooter() {
  const { pathname } = useLocation();
  const items = LINKS.filter((l) => l.to !== pathname);

  return (
    <div className="setting-course-footer-actions">
      <p style={{ fontSize: '0.88rem', color: '#64748b', marginBottom: '0.5rem' }}>다른 환경 설정 가이드</p>
      <p style={{ marginBottom: 0 }}>
        {items.map((l, i) => (
          <span key={l.to}>
            {i > 0 && ' · '}
            <Link to={l.to} className="setting-footer-link">
              {l.label}
            </Link>
          </span>
        ))}
      </p>
    </div>
  );
}
