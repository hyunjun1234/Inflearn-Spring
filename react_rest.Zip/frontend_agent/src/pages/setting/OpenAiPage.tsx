import { springImg } from '../../shared/chat/springImg';
import SettingFooter from './SettingFooter';
import './setting.css';

export default function OpenAiPage() {
  return (
    <div className="setting-course-main">
      <header className="setting-course-hero">
        <h1>OpenAI 환경 설정</h1>
      </header>

      <div className="setting-course-overview">
        <p className="meta">
          API 키 발급 · 결제·크레딧 · 문서 · Spring Boot <code>.env</code> 연동
        </p>
        <p>
          Spring AI에서 OpenAI 모델을 쓰려면 <strong>Platform API Key</strong>와 결제(크레딧) 설정이 필요합니다. 키는 저장소에 올리지 말고 <code>.env</code>로
          관리하고, <code>application.yml</code>에서 선택적으로 불러옵니다.
        </p>
      </div>

      <nav className="setting-course-toc" aria-label="목차">
        <p className="setting-course-toc-title">목차</p>
        <ol>
          <li>
            <a href="#oa-s1">API 키 발급</a>
          </li>
          <li>
            <a href="#oa-s2">OpenAI 문서</a>
          </li>
          <li>
            <a href="#oa-s3">Spring Boot 프로젝트에 키 입력</a>
          </li>
        </ol>
      </nav>

      <div className="setting-course-content">
        <hr className="setting-course-divider" />

        <h3 id="oa-s1">1. API 키 발급</h3>
        <p>
          <a href="https://platform.openai.com/" target="_blank" rel="noopener noreferrer">
            OpenAI Platform
          </a>
          에 로그인한 뒤 키를 발급합니다.
        </p>
        <ol>
          <li>
            상단 톱니(설정) → <strong>API Keys</strong> → <em>Create new secret key</em> — 프로젝트는 default, 권한은 All 등 과정 안내에 맞게 선택
          </li>
          <li>
            <strong>Billing</strong> → <strong>Payment methods</strong>에서 카드 등록 후 크레딧 충전. <strong>Auto recharge</strong>는 반드시 꺼 두는 것을 권장합니다.
          </li>
        </ol>
        <figure>
          <img src={springImg('/imgs/openai2.png')} alt="OpenAI API Keys 화면 예시" />
        </figure>
        <figure>
          <img src={springImg('/imgs/openai3.png')} alt="OpenAI Billing 화면 예시" />
        </figure>

        <hr className="setting-course-divider" />

        <h3 id="oa-s2">2. OpenAI 문서</h3>
        <p>
          <a href="https://platform.openai.com/docs/overview" target="_blank" rel="noopener noreferrer">
            OpenAI Documentation
          </a>
        </p>

        <hr className="setting-course-divider" />

        <h3 id="oa-s3">3. Spring Boot 프로젝트에 키 정보 입력</h3>
        <p>
          프로젝트 루트에 <code>.env</code> 파일을 만들고 키를 넣습니다. Git에 올릴 때는 <code>.gitignore</code>에 <code>.env</code>를 반드시 추가합니다.
        </p>
        <figure>
          <img src={springImg('/imgs/env.png')} alt=".env 파일 예시" />
        </figure>
        <pre>{`OPEN_AI_KEY=sk-proj-TcdDCv
GEMINI_KEY=AIzaSyDkpW5sh1I`}</pre>
        <p>
          Spring Boot가 <code>.env</code>를 읽도록 <code>application.yml</code>(또는 프로필별 yml)에 다음을 둡니다.
        </p>
        <pre>{`spring:
  config:
    import: optional:file:.env[.properties]`}</pre>

        <SettingFooter />
      </div>
    </div>
  );
}
