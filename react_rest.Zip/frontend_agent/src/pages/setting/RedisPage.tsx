import redisFragment from './redisFragment.html?raw';

/**
 * pages/setting/redis.html 과 동일 본문 (설정 하단 링크는 React 라우트)
 */
export default function RedisPage() {
  return (
    <div className="col-sm-12" dangerouslySetInnerHTML={{ __html: redisFragment }} />
  );
}
