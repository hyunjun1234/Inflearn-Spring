import { springImg } from '../../shared/chat/springImg';
import SettingFooter from './SettingFooter';
import './setting.css';

export default function IntellijPage() {
  return (
    <div className="setting-course-main">
      <header className="setting-course-hero">
        <h1>IntelliJ 환경 설정</h1>
      </header>

      <div className="setting-course-overview">
        <p className="meta">JDK 설치 · IntelliJ IDEA 설치 · 자동 빌드·인코딩·Hot Swap — 본 과정 Spring Boot 실습을 위한 IDE 준비</p>
        <p>
          이 문서는 로컬 개발에 필요한 <strong>JDK</strong>와 <strong>IntelliJ IDEA</strong> 설치 링크, 그리고 저장 시 재실행·UTF-8 인코딩 등 본 저장소 예제를
          따라가기 위한 최소 설정을 정리합니다. 이후 Chapter 실습은 이 환경을 전제로 합니다.
        </p>
      </div>

      <nav className="setting-course-toc" aria-label="목차">
        <p className="setting-course-toc-title">목차</p>
        <ol>
          <li>
            <a href="#ij-s1">JDK</a>
          </li>
          <li>
            <a href="#ij-s2">IntelliJ IDEA 다운로드</a>
          </li>
          <li>
            <a href="#ij-s3">IDE 기본 설정 (탐색기·자동 빌드·인코딩·Update)</a>
          </li>
        </ol>
      </nav>

      <div className="setting-course-content">
        <hr className="setting-course-divider" />

        <h3 id="ij-s1">1. JDK</h3>
        <p>
          <a href="https://www.oracle.com/kr/java/technologies/downloads/" target="_blank" rel="noopener noreferrer">
            JDK Download (Oracle)
          </a>
          — 프로젝트는 Java 17(Java 21 버전 사용 가능) 을 사용합니다.
          <br />
          설치 후 명령 프롬프트에서 <code>java -version</code>으로 버전을 확인하세요.
        </p>

        <hr className="setting-course-divider" />

        <h3 id="ij-s2">2. IntelliJ IDEA 다운로드</h3>
        <p>
          <a href="https://www.jetbrains.com/ko-kr/idea/download/" target="_blank" rel="noopener noreferrer">
            IntelliJ IDEA Download
          </a>
          — Community 또는 Ultimate 중 환경에 맞는 에디션을 선택합니다.
        </p>

        <hr className="setting-course-divider" />

        <h3 id="ij-s3">3. IntelliJ 환경 설정</h3>

        <h6>Project Explorer</h6>
        <figure>
          <img src={springImg('/imgs/intellij1.png')} alt="IntelliJ Project Explorer 설정 예시" />
        </figure>

        <h6>Rerun as soon as you save the code (저장 시 클래스·리소스 반영)</h6>
        <ol>
          <li>
            <strong>Settings</strong> → <strong>Advanced Settings</strong> → Compiler → <em>Allow auto-make to start even if developed application is currently running</em>{' '}
            ✓
          </li>
          <li>
            <strong>Settings</strong> → <strong>Build, Execution, Deployment</strong> → <strong>Compiler</strong> → <em>Build project automatically</em> ✓
          </li>
          <li>
            <strong>Settings</strong>에서 <code>encoding</code> 검색 후 전역·프로젝트 인코딩을 <strong>UTF-8</strong>로 통일
          </li>
          <li>
            <strong>Run/Debug Configurations</strong> → 해당 Spring Boot 실행 항목 → <strong>Modify options</strong> → <strong>On &apos;Update&apos; action</strong> →{' '}
            <em>Update classes and resources</em> ✓
            <figure>
              <img src={springImg('/imgs/intellij2.png')} alt="Run Configuration Update 옵션" />
            </figure>
            <figure>
              <img src={springImg('/imgs/intellij3.png')} alt="Update classes and resources 선택" />
            </figure>
          </li>
        </ol>

        <SettingFooter />
      </div>
    </div>
  );
}
