import StrategicAnalysisLab from '../../shared/workflow/StrategicAnalysisLab';
import { CH3_VOTING_EXAMPLE_QUESTION } from '../../shared/workflow/strategicDefaults';

export default function VotingAnalysis() {
  return (
    <StrategicAnalysisLab
      title="3. Voting Analysis"
      defaultQuestion={CH3_VOTING_EXAMPLE_QUESTION}
      postPath="/ch3/voting-analysis"
      showRoutingBadge={false}
    />
  );
}
