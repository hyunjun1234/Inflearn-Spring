import StrategicAnalysisLab from '../../shared/workflow/StrategicAnalysisLab';
import { CH3_PRECISION_EXAMPLE_QUESTION } from '../../shared/workflow/strategicDefaults';

export default function PrecisionExecution() {
  return (
    <StrategicAnalysisLab
      title="2. Precision Execution"
      defaultQuestion={CH3_PRECISION_EXAMPLE_QUESTION}
      postPath="/ch3/precision-execution"
      showRoutingBadge={false}
    />
  );
}
