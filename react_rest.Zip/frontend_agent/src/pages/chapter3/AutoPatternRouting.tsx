import StrategicAnalysisLab from '../../shared/workflow/StrategicAnalysisLab';
import {
  CH3_PRECISION_EXAMPLE_QUESTION,
  CH3_VOTING_EXAMPLE_QUESTION,
  UAM_STRATEGIC_QUESTION,
} from '../../shared/workflow/strategicDefaults';

export default function Ch3AutoPatternRouting() {
  return (
    <div className="col-sm-12">
      <h2 className="text-center">4. Auto Pattern Routing</h2>
      <div className="container py-2">
        <div className="alert alert-light border small shadow-sm mb-3" role="note">
          <p className="mb-2 fw-bold">
            실습 1~3번 입력창 기본 문장과 기대 라우팅 (동일 문장을 붙여 넣어 검증할 수 있습니다)
          </p>
          <ul className="mb-0 ps-3">
            <li className="mb-2">
              <span className="badge bg-primary me-1">STRATEGIC</span>
              <strong>1. Strategic Analysis</strong> —{' '}
              <code className="small text-dark" style={{ color: '#212529' }}>
                {UAM_STRATEGIC_QUESTION}
              </code>
            </li>
            <li className="mb-2">
              <span className="badge bg-info text-dark me-1">PRECISION</span>
              <strong>2. Precision Execution</strong> —{' '}
              <code className="small text-dark" style={{ color: '#212529' }}>
                {CH3_PRECISION_EXAMPLE_QUESTION}
              </code>
            </li>
            <li className="mb-0">
              <span className="badge bg-success me-1">VOTING</span>
              <strong>3. Voting Analysis</strong> —{' '}
              <code className="small text-dark" style={{ color: '#212529' }}>
                {CH3_VOTING_EXAMPLE_QUESTION}
              </code>
            </li>
          </ul>
        </div>
      </div>
      <StrategicAnalysisLab
        title="4. Auto Pattern Routing"
        omitTitle
        defaultQuestion={UAM_STRATEGIC_QUESTION}
        postPath="/ch3/auto-pattern-routing"
        showRoutingBadge={false}
      />
    </div>
  );
}
