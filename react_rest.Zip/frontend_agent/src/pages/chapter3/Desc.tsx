import ch3DescFragment from './ch3DescFragment.html?raw';

/**
 * pages/ch3/desc.html 과 동일 본문
 */
export default function Ch3Desc() {
  return (
    <div className="col-sm-12" dangerouslySetInnerHTML={{ __html: ch3DescFragment }} />
  );
}
