import StrategicAnalysisLab from '../../shared/workflow/StrategicAnalysisLab';
import { UAM_STRATEGIC_QUESTION } from '../../shared/workflow/strategicDefaults';

export default function Ch3StrategicAnalysis() {
  return (
    <StrategicAnalysisLab title="1. Strategic Analysis" defaultQuestion={UAM_STRATEGIC_QUESTION} postPath="/ch3/strategic-analysis" />
  );
}
