import { Outlet, Link, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';

const Layout = () => {
  const location = useLocation();
  const currentPath = location.pathname;

  const getCurrentChapter = () => {
    const match = currentPath.match(/^\/(chapter\d+)/);
    return match ? match[1] : null;
  };

  const currentChapter = getCurrentChapter();

  return (
    <div
      className="d-flex flex-column"
      style={{ minHeight: '100vh' }}
    >
      <div className="jumbotron text-center" style={{ marginBottom: 0 }}>
        <h1>Spring AI Project - Part 2</h1>
        <h5>Multi-LLM & Orchestrated Multi-Agent System</h5>
      </div>

      <ul className="nav justify-content-end">
        <li className="nav-item">
          <Link className="nav-link" style={{ color: 'black', fontWeight: 'bold' }} to="/setting/intellij">
            Intellij
          </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" style={{ color: 'black', fontWeight: 'bold' }} to="/setting/springai">
            SpringAI
          </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" style={{ color: 'black', fontWeight: 'bold' }} to="/setting/openai">
            OpenAI
          </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" style={{ color: 'black', fontWeight: 'bold' }} to="/setting/gemini">
            Gemini
          </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" style={{ color: 'black', fontWeight: 'bold' }} to="/setting/ollama">
            Ollama
          </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" style={{ color: 'black', fontWeight: 'bold' }} to="/setting/redis">
            Redis
          </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" style={{ color: 'black', fontWeight: 'bold' }} to="/setting/postgresql">
            PostgreSQL
          </Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" style={{ color: 'black', fontWeight: 'bold' }} to="/setting/react">
            React
          </Link>
        </li>
      </ul>

      <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
        <Link className="navbar-brand" to="/">
          Home
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#collapsibleNavbar"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="collapsibleNavbar">
          <ul className="navbar-nav" style={{ fontWeight: 'bold' }}>
            <li className="nav-item">
              <Link className="nav-link" to="/chapter1">
                chapter1
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/chapter2">
                chapter2
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/chapter3">
                chapter3
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/chapter4">
                chapter4
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/chapter5">
                chapter5
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/chapter6">
                chapter6
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/chapter7">
                chapter7
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/chapter8">
                chapter8
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/chapter9">
                chapter9
              </Link>
            </li>
          </ul>
        </div>
      </nav>

      <div className="container-fluid flex-fill" style={{ marginTop: 30 }}>
        <div className="row">
          <div className="col-sm-2">
            <Sidebar
              currentPage={
                currentChapter ||
                (currentPath === '/' ? 'main' : currentPath.includes('/setting/') ? 'setting' : null)
              }
            />
          </div>
          <div className="col-sm-10">
            <Outlet />
          </div>
        </div>
      </div>

      {/* Spring layout/main.html 하단 영역과 동일 */}
      <div className="text-center bg-dark text-white" style={{ marginBottom: 0, marginTop: 'auto' }}>
        <p className="mb-0 py-2">React</p>
      </div>
    </div>
  );
};

export default Layout;
