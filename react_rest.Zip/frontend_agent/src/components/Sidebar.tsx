import { Link } from 'react-router-dom';

interface SidebarProps {
  currentPage: string | null;
}

/** springai2_agent fragments/left.html 과 동일한 메뉴 */
const Sidebar = ({ currentPage }: SidebarProps) => {
  if (currentPage === 'main' || currentPage === 'setting' || currentPage === null) {
    return (
      <ul className="nav nav-pills flex-column" style={{ fontWeight: 'bold', fontSize: 'small' }}>
        <li className="nav-item">
          <Link to="/chapter1" className="btn btn-secondary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            1. Multi-LLM Architecture
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter2" className="btn btn-secondary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            2. Agentic Workflow Patterns
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter3" className="btn btn-secondary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            3. Orchestrated Multi-Agent Patterns
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter4" className="btn btn-secondary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            4. Multi-Agent
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter5" className="btn btn-secondary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            5. Tool-Orchestrated Multi-Agent
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter6" className="btn btn-secondary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            6. Task-Orchestrated Multi-Agent
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter7" className="btn btn-secondary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            7. DAG-Orchestrated Multi-Agent
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter8" className="btn btn-secondary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            8. Declarative Agent Workflow with YAML
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter9" className="btn btn-secondary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            9. Validated Agent Workflow DSL
          </Link>
        </li>
      </ul>
    );
  }

  if (currentPage === 'chapter1') {
    return (
      <ul className="nav nav-pills flex-column" style={{ fontWeight: 'bold' }}>
        <li className="nav-item">
          <Link to="/chapter1/desc" className="btn btn-warning btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            Chapter1. Screen Description
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter1/1_multi_llm" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            1. Multi LLM
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter1/2_multi_llm_stream" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            2. Multi LLM Stream
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter1/3_fallback" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            3. Fallback
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter1/4_router" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            4. Router
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter1/5_security" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            5. Security
          </Link>
        </li>
      </ul>
    );
  }

  if (currentPage === 'chapter2') {
    return (
      <ul className="nav nav-pills flex-column" style={{ fontWeight: 'bold' }}>
        <li className="nav-item">
          <Link to="/chapter2/desc" className="btn btn-warning btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            Chapter2. Screen Description
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter2/1_chain_workflow" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            1. Chain Workflow
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter2/2_parallelization_workflow" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            2. Parallelization Workflow
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter2/3_routing_workflow" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            3. Routing Workflow
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter2/4_orchestrator_workers" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            4. Orchestrator-Workers
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter2/5_evaluator_optimizer" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            5. Evaluator-Optimizer
          </Link>
        </li>
      </ul>
    );
  }

  if (currentPage === 'chapter3') {
    return (
      <ul className="nav nav-pills flex-column" style={{ fontWeight: 'bold' }}>
        <li className="nav-item">
          <Link to="/chapter3/desc" className="btn btn-warning btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            Chapter3. Screen Description
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter3/1_strategic_analysis" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            1. Strategic Analysis
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter3/2_precision_execution" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            2. Precision Execution
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter3/3_voting_analysis" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            3. Voting Analysis
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter3/4_auto_pattern_routing" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            4. Auto Pattern Routing
          </Link>
        </li>
      </ul>
    );
  }

  if (currentPage === 'chapter4') {
    return (
      <ul className="nav nav-pills flex-column" style={{ fontWeight: 'bold' }}>
        <li className="nav-item">
          <Link to="/chapter4/desc" className="btn btn-warning btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            Chapter4. Screen Description
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter4/1_strategic_analysis" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            1. Strategic Analysis (Multi-Agent)
          </Link>
        </li>
      </ul>
    );
  }

  if (currentPage === 'chapter5') {
    return (
      <ul className="nav nav-pills flex-column" style={{ fontWeight: 'bold' }}>
        <li className="nav-item">
          <Link to="/chapter5/desc" className="btn btn-warning btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            Chapter5. Screen Description
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter5/1_strategic_analysis" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            1. Strategic Analysis (Tool-Orchestrated)
          </Link>
        </li>
      </ul>
    );
  }

  if (currentPage === 'chapter6') {
    return (
      <ul className="nav nav-pills flex-column" style={{ fontWeight: 'bold' }}>
        <li className="nav-item">
          <Link to="/chapter6/desc" className="btn btn-warning btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            Chapter6. Screen Description
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter6/1_strategic_analysis" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            1. Strategic Analysis (Task-Orchestrated)
          </Link>
        </li>
      </ul>
    );
  }

  if (currentPage === 'chapter7') {
    return (
      <ul className="nav nav-pills flex-column" style={{ fontWeight: 'bold' }}>
        <li className="nav-item">
          <Link to="/chapter7/desc" className="btn btn-warning btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            Chapter7. Screen Description
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter7/1_strategic_analysis" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            1. Strategic Analysis (DAG)
          </Link>
        </li>
      </ul>
    );
  }

  if (currentPage === 'chapter8') {
    return (
      <ul className="nav nav-pills flex-column" style={{ fontWeight: 'bold' }}>
        <li className="nav-item">
          <Link to="/chapter8/desc" className="btn btn-warning btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            Chapter8. Screen Description
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter8/1_strategic_analysis" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            1. Strategic Analysis (YAML)
          </Link>
        </li>
      </ul>
    );
  }

  if (currentPage === 'chapter9') {
    return (
      <ul className="nav nav-pills flex-column" style={{ fontWeight: 'bold' }}>
        <li className="nav-item">
          <Link to="/chapter9/desc" className="btn btn-warning btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            Chapter9. Screen Description
          </Link>
        </li>
        <li className="nav-item">
          <Link to="/chapter9/1_strategic_analysis" className="btn btn-primary btn-block mb-2" role="button" style={{ fontWeight: 'bold', textAlign: 'left', fontSize: 'small' }}>
            1. Strategic Analysis (Validated DSL)
          </Link>
        </li>
      </ul>
    );
  }

  return null;
};

export default Sidebar;
