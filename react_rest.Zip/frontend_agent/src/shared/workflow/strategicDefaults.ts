/** Thymeleaf `1_strategic_analysis.html` 과 동일한 기본 질문 (ch3·ch4·ch5·ch6·ch7·ch9) */
export const UAM_STRATEGIC_QUESTION =
  '도심형 항공 모빌리티(UAM) 서비스의 국내 도입을 위한 기술적 과제와 예상 수익 모델을 분석해줘.';

/** Thymeleaf `2_precision_execution.html` 기본 질문 */
export const CH3_PRECISION_EXAMPLE_QUESTION = '우리 카페 전용 포인트 적립 시스템 앱을 만들고 싶어.';

/** Thymeleaf `3_voting_analysis.html` 기본 질문 */
export const CH3_VOTING_EXAMPLE_QUESTION =
  '향후 5년간 고체 배터리 시장의 연평균 성장률(CAGR) 예측치와 주요 리스크 3가지를 알려줘.';
