import { useState, useCallback, useEffect, useRef, type ReactNode } from 'react';
import { readStreamBodyText } from '../api/readStreamBody';
import { UserChatBlock, BotChatBlock } from '../chat/ChatBlocks';

type SseRow = {
  id: string;
  kind: 'sse';
  workflowId: string;
  statusText: string;
  logs: string[];
  alert: 'secondary' | 'success' | 'danger';
  /** pages/ch6/1_strategic_analysis.html 과 동일: routing 배지 */
  routingBadgeText: string;
  routingBadgeClass: string;
  routingResolved: boolean;
  sawAnalyzing: boolean;
  /** TodoWrite 스냅샷 원문 줄들 */
  agentTodoSnapshot: string[];
  /** Chapter 3 Auto Pattern Routing — PATTERN_SELECTED 메시지 표시 */
  patternChoiceText: string;
};

type ChatRow =
  | { id: string; kind: 'user'; text: string; time: string }
  | { id: string; kind: 'bot'; text: string; time: string }
  | SseRow;

function parseSsePayload(raw: string): { step?: string; message?: string } | null {
  try {
    return JSON.parse(raw) as { step?: string; message?: string };
  } catch {
    return null;
  }
}

function parseTodoLine(line: string): { idx: string; status: string; message: string } | null {
  if (!line) return null;
  const normalized = line.trim();
  const parts = normalized.split(/\s+[—-]\s+/);
  if (parts.length < 2) return null;
  const left = parts[0].trim();
  const message = parts.slice(1).join(' - ').trim();
  const m = left.match(/^(\d+)\.\s*(.*)$/);
  if (!m) return null;
  return { idx: m[1], status: (m[2] || '').trim(), message };
}

function lastTodoHeaderIndex(lines: string[]): number {
  return lines.reduce((acc, line, idx) => (/^할 일\s+\d+개/.test((line || '').trim()) ? idx : acc), -1);
}

function badgeClassForTodoStatus(status: string): string {
  const s = status.toLowerCase();
  if (status === '진행 중' || s === 'in_progress') return 'bg-warning text-dark';
  if (status === '완료' || s === 'completed') return 'bg-success';
  if (s === 'cancelled' || status === '취소') return 'bg-danger';
  return 'bg-secondary';
}

function AgentTodoBlock({ snapshotLines }: { snapshotLines: string[] }) {
  const lastHeader = lastTodoHeaderIndex(snapshotLines);
  const slice = lastHeader >= 0 ? snapshotLines.slice(lastHeader) : snapshotLines;
  const headerLine = slice.length > 0 ? slice[0].trim() : '';
  const todoLines = slice.slice(1);

  let itemsHtml = false;
  const items: ReactNode[] = [];
  for (const line of todoLines) {
    const parsed = parseTodoLine(line);
    if (!parsed) continue;
    itemsHtml = true;
    const bc = badgeClassForTodoStatus(parsed.status);
    items.push(
      <div key={`${parsed.idx}-${parsed.status}`} className="d-flex align-items-start justify-content-between mb-1">
        <div>
          <strong>{parsed.idx}</strong>.
          <span className={`badge ${bc} ms-2`}>{parsed.status || '알 수 없음'}</span>
        </div>
        <div className="text-muted ms-3" style={{ maxWidth: '65%' }}>
          {parsed.message}
        </div>
      </div>
    );
  }

  return (
    <div className="mt-2" style={{ fontSize: '0.8rem', maxHeight: 180, overflowY: 'auto' }}>
      <div className="d-flex align-items-center mb-1">
        <strong>TodoWrite 진행 상태</strong>
        <span className="text-muted ms-2">{headerLine}</span>
      </div>
      <div>{items}</div>
      {!itemsHtml && todoLines.length > 0 && (
        <div className="text-muted mt-1" style={{ whiteSpace: 'pre-wrap' }}>
          {todoLines.join('\n')}
        </div>
      )}
    </div>
  );
}

/**
 * pages/ch3~ch9 의 1_strategic_analysis — Thymeleaf ch6 스크립트와 동일한 SSE·라우팅·TodoWrite UI
 */
export default function StrategicAnalysisLab({
  title,
  defaultQuestion,
  postPath,
  extraFormFields,
  workflowDefinitionOptions,
  workflowDefinitionDefault,
  omitTitle = false,
  /** Chapter 3 정밀·투표·자동 패턴 라우팅 등 SIMPLE/STRATEGIC 라우팅 배지·해당 SSE 단계 UI 생략 */
  showRoutingBadge = true,
}: {
  title: string;
  defaultQuestion: string;
  postPath: string;
  extraFormFields?: Record<string, string>;
  workflowDefinitionOptions?: Array<{ value: string; label: string }>;
  workflowDefinitionDefault?: string;
  /** 페이지 상단에 제목을 따로 두는 경우(예: Auto Pattern Routing — 예시 블록 아래가 아닌 위에 h2) */
  omitTitle?: boolean;
  showRoutingBadge?: boolean;
}) {
  const [question, setQuestion] = useState(defaultQuestion);
  const [selectedWorkflowDefinition, setSelectedWorkflowDefinition] = useState(
    workflowDefinitionDefault ?? workflowDefinitionOptions?.[0]?.value ?? ''
  );
  const [loading, setLoading] = useState(false);
  const [rows, setRows] = useState<ChatRow[]>([]);
  const eventSourceRef = useRef<EventSource | null>(null);
  const agentTodoBufferRef = useRef<string[]>([]);
  const agentTodoTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      eventSourceRef.current?.close();
      if (agentTodoTimerRef.current) clearTimeout(agentTodoTimerRef.current);
    };
  }, []);

  const connectSSE = useCallback((workflowId: string): Promise<void> => {
    agentTodoBufferRef.current = [];
    if (agentTodoTimerRef.current) {
      clearTimeout(agentTodoTimerRef.current);
      agentTodoTimerRef.current = null;
    }

    return new Promise((resolve) => {
      const sseRowId = `sse-${workflowId}`;
      setRows((r) => [
        {
          id: sseRowId,
          kind: 'sse',
          workflowId,
          statusText: '워크플로우 분석을 준비 중입니다...',
          logs: [],
          alert: 'secondary',
          routingBadgeText: 'routing: (대기)',
          routingBadgeClass: 'badge bg-secondary ms-2',
          routingResolved: false,
          sawAnalyzing: false,
          agentTodoSnapshot: [],
          patternChoiceText: '',
        },
        ...r,
      ]);

      const url = `/api/workflow/stream/${workflowId}`;
      const es = new EventSource(url);
      eventSourceRef.current = es;

      const routingFromTodoLines = (lines: string[]) => {
        for (const line of lines) {
          const m = line.match(/routing\s*=\s*(SIMPLE|STRATEGIC)/i);
          if (m) {
            const routing = m[1].toUpperCase();
            if (routing === 'SIMPLE') {
              return {
                routingResolved: true,
                routingBadgeClass: 'badge bg-success ms-2',
                routingBadgeText: 'routing: SIMPLE',
                sawAnalyzing: false,
              } as const;
            }
            return {
              routingResolved: true,
              sawAnalyzing: true,
              routingBadgeClass: 'badge bg-primary ms-2',
              routingBadgeText: 'routing: STRATEGIC',
            } as const;
          }
        }
        return null;
      };

      const flushAgentTodo = () => {
        const buf = [...agentTodoBufferRef.current];
        agentTodoBufferRef.current = [];
        agentTodoTimerRef.current = null;
        if (buf.length === 0) return;
        setRows((prev) =>
          prev.map((row) => {
            if (row.kind !== 'sse' || row.workflowId !== workflowId) return row;
            const allLines = buf.filter(Boolean);
            const lh = lastTodoHeaderIndex(allLines);
            const snap = lh >= 0 ? allLines.slice(lh) : allLines;
            const routeUpd = routingFromTodoLines(snap);
            if (snap.length === 0) return row;
            return {
              ...row,
              agentTodoSnapshot: snap,
              ...(routeUpd ?? {}),
            };
          })
        );
      };

      const scheduleTodoRender = () => {
        if (agentTodoTimerRef.current) clearTimeout(agentTodoTimerRef.current);
        agentTodoTimerRef.current = setTimeout(() => {
          flushAgentTodo();
        }, 250);
      };

      let opened = false;
      es.onopen = () => {
        opened = true;
        resolve();
      };

      es.onmessage = (event) => {
        const data = parseSsePayload(event.data);
        if (!data) return;

        const step = (data.step ?? '').toString();
        const messageText = (data.message ?? '').toString();

        if (step === 'AGENT_TODO') {
          agentTodoBufferRef.current.push(messageText);
          scheduleTodoRender();
          return;
        }

        if (!showRoutingBadge && (step === 'ROUTING' || step === 'ROUTING_RESULT')) {
          return;
        }

        setRows((prev) =>
          prev.map((row) => {
            if (row.kind !== 'sse' || row.workflowId !== workflowId) return row;

            let routingBadgeText = row.routingBadgeText;
            let routingBadgeClass = row.routingBadgeClass;
            let routingResolved = row.routingResolved;
            let sawAnalyzing = row.sawAnalyzing;
            let patternChoiceText = row.patternChoiceText;

            if (step === 'PATTERN_ROUTING') {
              patternChoiceText = '적합한 Chapter 3 패턴을 분석 중… (LLaMA 분류)';
            }
            if (step === 'PATTERN_SELECTED') {
              patternChoiceText = messageText || '선택된 패턴';
            }

            if (!routingResolved && step === 'ROUTING') {
              routingBadgeClass = 'badge bg-warning text-dark ms-2';
              routingBadgeText = 'routing: 결정 중';
            }
            if (step === 'ROUTING_RESULT') {
              const match = messageText.match(/routing\s*=\s*(SIMPLE|STRATEGIC)/i);
              if (match) {
                const routing = match[1].toUpperCase();
                routingResolved = true;
                if (routing === 'SIMPLE') {
                  routingBadgeClass = 'badge bg-success ms-2';
                  routingBadgeText = 'routing: SIMPLE';
                } else {
                  sawAnalyzing = true;
                  routingBadgeClass = 'badge bg-primary ms-2';
                  routingBadgeText = 'routing: STRATEGIC';
                }
              }
            }
            if (
              step === 'ANALYZING' ||
              messageText.includes('기술 및 시장 데이터를 동시에 분석 중')
            ) {
              sawAnalyzing = true;
              routingResolved = true;
              routingBadgeClass = 'badge bg-primary ms-2';
              routingBadgeText = 'routing: STRATEGIC';
            }

            const logLine = `> ${new Date().toLocaleTimeString()} [${step}] ${messageText}`;
            const logs = [logLine, ...row.logs].slice(0, 120);

            let alert: SseRow['alert'] = row.alert;
            if (step === 'COMPLETED') {
              if (!routingResolved && !sawAnalyzing) {
                routingBadgeClass = 'badge bg-success ms-2';
                routingBadgeText = 'routing: SIMPLE';
                routingResolved = true;
              }
              alert = 'success';
              es.close();
              if (agentTodoTimerRef.current) clearTimeout(agentTodoTimerRef.current);
              agentTodoTimerRef.current = null;
              const tail = [...agentTodoBufferRef.current];
              agentTodoBufferRef.current = [];
              let agentTodoSnapshot = row.agentTodoSnapshot;
              if (tail.length > 0) {
                const allLines = tail.filter(Boolean);
                const lh = lastTodoHeaderIndex(allLines);
                const snap = lh >= 0 ? allLines.slice(lh) : allLines;
                if (snap.length > 0) agentTodoSnapshot = snap;
              }
              const routeUpd = routingFromTodoLines(agentTodoSnapshot);
              return {
                ...row,
                statusText: messageText,
                logs,
                alert,
                routingBadgeText: routeUpd?.routingBadgeText ?? routingBadgeText,
                routingBadgeClass: routeUpd?.routingBadgeClass ?? routingBadgeClass,
                routingResolved: routeUpd?.routingResolved ?? routingResolved,
                sawAnalyzing: routeUpd?.sawAnalyzing ?? sawAnalyzing,
                agentTodoSnapshot,
                patternChoiceText,
              };
            }
            if (step === 'ERROR') {
              alert = 'danger';
              es.close();
              if (agentTodoTimerRef.current) clearTimeout(agentTodoTimerRef.current);
              agentTodoTimerRef.current = null;
              const tail = [...agentTodoBufferRef.current];
              agentTodoBufferRef.current = [];
              let agentTodoSnapshot = row.agentTodoSnapshot;
              if (tail.length > 0) {
                const allLines = tail.filter(Boolean);
                const lh = lastTodoHeaderIndex(allLines);
                const snap = lh >= 0 ? allLines.slice(lh) : allLines;
                if (snap.length > 0) agentTodoSnapshot = snap;
              }
              return {
                ...row,
                statusText: messageText,
                logs,
                alert,
                routingBadgeText,
                routingBadgeClass,
                routingResolved,
                sawAnalyzing,
                agentTodoSnapshot,
                patternChoiceText,
              };
            }

            return {
              ...row,
              statusText: messageText,
              logs,
              alert,
              routingBadgeText,
              routingBadgeClass,
              routingResolved,
              sawAnalyzing,
              patternChoiceText,
            };
          })
        );
      };

      es.onerror = () => {
        es.close();
      };

      setTimeout(() => {
        if (!opened) resolve();
      }, 1000);
    });
  }, [showRoutingBadge]);

  const send = useCallback(async () => {
    const q = question.trim();
    if (!q || loading) return;

    eventSourceRef.current?.close();
    if (agentTodoTimerRef.current) clearTimeout(agentTodoTimerRef.current);

    const t = new Date().toLocaleTimeString('ko-KR');
    setRows((r) => [{ id: crypto.randomUUID(), kind: 'user', text: q, time: t }, ...r]);
    setLoading(true);

    const workflowId = crypto.randomUUID();
    await connectSSE(workflowId);

    const botId = crypto.randomUUID();
    const botTime = new Date().toLocaleTimeString('ko-KR');
    setRows((r) => [{ id: botId, kind: 'bot', text: '', time: botTime }, ...r]);

    try {
      const params = new URLSearchParams({ prompt: q, workflowId });
      Object.entries(extraFormFields ?? {}).forEach(([k, v]) => params.set(k, v));
      if (workflowDefinitionOptions && selectedWorkflowDefinition) {
        params.set('workflowDefinition', selectedWorkflowDefinition);
      }

      const response = await fetch(postPath, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Accept: 'application/x-ndjson',
        },
        body: params,
      });

      if (!response.ok) {
        const ct = response.headers.get('content-type') ?? '';
        let detail = `HTTP ${response.status}`;
        try {
          if (ct.includes('application/json')) {
            const j = (await response.json()) as { error?: string };
            if (j.error) detail = j.error;
          } else {
            detail = await response.text();
          }
        } catch {
          /* keep detail */
        }
        throw new Error(detail);
      }

      await readStreamBodyText(response, (full) => {
        setRows((prev) =>
          prev.map((row) => (row.kind === 'bot' && row.id === botId ? { ...row, text: full } : row))
        );
      });
    } catch (e) {
      console.error(e);
      setRows((prev) =>
        prev.map((row) =>
          row.kind === 'bot' && row.id === botId
            ? { ...row, text: `오류: ${e instanceof Error ? e.message : String(e)}` }
            : row
        )
      );
    } finally {
      setLoading(false);
    }
  }, [question, loading, postPath, extraFormFields, connectSSE]);

  return (
    <div className="col-sm-12">
      {!omitTitle ? <h2 className="text-center">{title}</h2> : null}
      <div className="container py-5">
        <div className="row d-flex justify-content-center">
          <div className="col-sm-10">
            <button className="btn btn-primary" disabled type="button" style={{ visibility: loading ? 'visible' : 'hidden' }}>
              <span className="spinner-border spinner-border-sm" role="status" />
              Loading..
            </button>
            <div className="card">
              <div className="card-header text-muted d-flex justify-content-start align-items-center p-3">
                <div className="input-group mb-0 w-100">
                  {workflowDefinitionOptions && workflowDefinitionOptions.length > 0 ? (
                    <div className="w-100 mb-2">
                      <select
                        className="form-select"
                        style={{ maxWidth: 320 }}
                        aria-label="Workflow definition"
                        value={selectedWorkflowDefinition}
                        onChange={(e) => setSelectedWorkflowDefinition(e.target.value)}
                      >
                        {workflowDefinitionOptions.map((opt) => (
                          <option key={opt.value} value={opt.value}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    </div>
                  ) : null}
                  <input
                    type="text"
                    className="form-control text-dark"
                    style={{ color: '#212529' }}
                    placeholder="Type message"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && send()}
                  />
                  <button type="button" className="btn btn-primary" onClick={send} disabled={loading}>
                    Send
                  </button>
                </div>
              </div>
              <div className="card-body">
                {rows.map((row) => (
                  <div key={row.id} className="mb-3">
                    {row.kind === 'user' && <UserChatBlock text={row.text} time={row.time} />}
                    {row.kind === 'bot' && <BotChatBlock text={row.text} time={row.time} />}
                    {row.kind === 'sse' && (
                      <div
                        className={`alert alert-${row.alert} mb-3 small shadow-sm border-start border-4 border-info`}
                      >
                        <div className="d-flex align-items-center flex-wrap">
                          {row.alert === 'secondary' && (
                            <div className="spinner-grow spinner-grow-sm text-info me-2" role="status" />
                          )}
                          <strong>{row.statusText}</strong>
                          {showRoutingBadge ? (
                            <span className={row.routingBadgeClass}>{row.routingBadgeText}</span>
                          ) : null}
                        </div>
                        {row.patternChoiceText ? (
                          <div className="mt-2">
                            <span
                              className={`badge ${row.patternChoiceText.includes('분석 중') ? 'bg-warning text-dark' : 'bg-success'} me-1`}
                              style={{ whiteSpace: 'normal', textAlign: 'left' }}
                            >
                              {row.patternChoiceText}
                            </span>
                          </div>
                        ) : null}
                        {row.agentTodoSnapshot.length > 0 && <AgentTodoBlock snapshotLines={row.agentTodoSnapshot} />}
                        <div className="mt-2 text-muted" style={{ fontSize: '0.8rem', maxHeight: 220, overflowY: 'auto' }}>
                          {row.logs.map((l, i) => (
                            <div key={i}>{l}</div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
