import StrategicAnalysisLab from '../workflow/StrategicAnalysisLab';
import { UAM_STRATEGIC_QUESTION } from '../workflow/strategicDefaults';

/**
 * ch4~ch9 공통: POST /{chN}/strategic-analysis + SSE /api/workflow/stream/{workflowId}
 */
export default function StrategicOnlyChapter({
  chapterPrefix,
  title,
  extraFormFields,
  workflowDefinitionOptions,
  workflowDefinitionDefault,
}: {
  chapterPrefix: 'ch4' | 'ch5' | 'ch6' | 'ch7' | 'ch8' | 'ch9';
  title: string;
  extraFormFields?: Record<string, string>;
  workflowDefinitionOptions?: Array<{ value: string; label: string }>;
  workflowDefinitionDefault?: string;
}) {
  return (
    <StrategicAnalysisLab
      title={title}
      defaultQuestion={UAM_STRATEGIC_QUESTION}
      postPath={`/${chapterPrefix}/strategic-analysis`}
      extraFormFields={extraFormFields}
      workflowDefinitionOptions={workflowDefinitionOptions}
      workflowDefinitionDefault={workflowDefinitionDefault}
    />
  );
}
