/**
 * Thymeleaf `pages/ch1/4_router.html`·`5_security.html` 및
 * `RouterService` / `SecurityService`·`SecurityScanner` 설명과 맞춘 예시 문장.
 */

export const CH1_ROUTER_EXAMPLES = [
  {
    badge: '예시 1 · CREATIVE · 기본값',
    hint: '창의·코딩·복잡 추론 → GPT 우선',
    text: '이차 방정식에 대한 기본 예제를 만들어줘',
  },
  {
    badge: '예시 2 · TECHNICAL',
    hint: '기술 명세·긴 문서·구글 서비스 → Gemini 우선',
    text: 'Google Cloud BigQuery 파티션 테이블 설계 시 비용과 쿼리 성능을 동시에 고려하는 기술 가이드를 문서 형태로 정리해줘',
  },
  {
    badge: '예시 3 · GENERAL',
    hint: '단순 질의·일반 사실·일상 대화 → Llama 기본',
    text: '수도권 지하철 2호선이 처음 개통한 연도를 한 문장으로 알려줘',
  },
] as const;

export const CH1_SECURITY_EXAMPLES = [
  {
    badge: '예시 1 · 전화번호 · 기본값',
    hint: 'SecurityScanner 전화 패턴 → 민감, Llama·보안 모드',
    text: '010-2121-2211 의 전화 번호는 누구의 번호야',
  },
  {
    badge: '예시 2 · 이메일',
    hint: '이메일 패턴 탐지 → 민감, 외부 GPT로 보내지 않음',
    text: 'team-lead@company.example 에 보낼 주간 업무 요약 메일 초안을 짧게 작성해줘',
  },
  {
    badge: '예시 3 · 기밀 키워드',
    hint: '대외비·기밀 등 키워드 → 민감 처리',
    text: '이 대외비 설계도에서 제목과 목차만 bullet로 뽑아줘',
  },
  {
    badge: '예시 4 · 일반',
    hint: '민감 정보 없음 → GPT 경로',
    text: '파이썬에서 리스트와 튜플의 차이를 한 문단으로 설명해줘',
  },
] as const;
