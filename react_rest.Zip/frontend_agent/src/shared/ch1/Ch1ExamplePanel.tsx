export { default } from '../ch2/Ch2ExamplePanel';
