/**
 * fetch Response.body 를 문자열로 누적 (Thymeleaf 스트리밍 예제와 동일)
 */
export async function readStreamBodyText(
  response: Response,
  onChunk: (cumulative: string) => void
): Promise<string> {
  const reader = response.body?.getReader();
  if (!reader) throw new Error('응답 본문을 읽을 수 없습니다.');
  const decoder = new TextDecoder('utf-8');
  let full = '';
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    full += decoder.decode(value, { stream: true });
    onChunk(full);
  }
  return full;
}
