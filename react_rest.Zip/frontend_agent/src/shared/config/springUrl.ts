/**
 * springai2_agent 베이스 URL — 정적 자산·(필요 시) 절대 링크용
 */
export function springAbsoluteUrl(path: string): string {
  const origin = (import.meta.env.VITE_SPRING_ORIGIN || 'http://127.0.0.1:80').replace(/\/$/, '');
  const p = path.startsWith('/') ? path : `/${path}`;
  return `${origin}${p}`;
}
