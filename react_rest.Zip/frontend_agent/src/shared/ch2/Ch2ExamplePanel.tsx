import type { ReactNode } from 'react';

/** Chapter 2·3 Auto Pattern·ch1 Router/Security 등 상단 예시 안내 블록과 동일 톤 (Strategic Analysis 라벨 없음) */
export default function Ch2ExamplePanel({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="container py-2">
      <div className="alert alert-light border small shadow-sm mb-3" role="note">
        <p className="mb-2 fw-bold">{title}</p>
        {children}
      </div>
    </div>
  );
}
