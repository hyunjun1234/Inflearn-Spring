import { useState, useCallback } from 'react';
import { UserChatBlock, BotChatBlock } from '../chat/ChatBlocks';
import Ch2ExamplePanel from './Ch2ExamplePanel';
import { CH2_PARALLEL_DEFAULT } from './ch2ExamplePrompts';

/**
 * POST /ch2/parallel-workflow — JSON(AnalysisResult) 응답
 */
export default function ParallelWorkflowLab() {
  const defaultQ = CH2_PARALLEL_DEFAULT;
  const [question, setQuestion] = useState(defaultQ);
  const [loading, setLoading] = useState(false);
  const [rows, setRows] = useState<{ id: string; kind: 'user' | 'bot'; text: string; time: string }[]>([]);

  const send = useCallback(async () => {
    const q = question.trim();
    if (!q || loading) return;

    const tu = new Date().toLocaleTimeString('ko-KR');
    setRows((r) => [{ id: crypto.randomUUID(), kind: 'user', text: q, time: tu }, ...r]);
    setLoading(true);

    const botId = crypto.randomUUID();
    const bt = new Date().toLocaleTimeString('ko-KR');
    setRows((r) => [{ id: botId, kind: 'bot', text: '', time: bt }, ...r]);

    try {
      const response = await fetch('/ch2/parallel-workflow', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ prompt: q }),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      const text = JSON.stringify(data, null, 2);
      setRows((prev) =>
        prev.map((row) => (row.kind === 'bot' && row.id === botId ? { ...row, text } : row))
      );
    } catch (e) {
      console.error(e);
      setRows((prev) =>
        prev.map((row) =>
          row.kind === 'bot' && row.id === botId
            ? { ...row, text: `오류: ${e instanceof Error ? e.message : String(e)}` }
            : row
        )
      );
    } finally {
      setLoading(false);
    }
  }, [question, loading]);

  return (
    <div className="col-sm-12">
      <h2 className="text-center">2. Parallelization Workflow</h2>
      <Ch2ExamplePanel title="기본 입력 예시 (입력창 기본값과 동일 · 기술·시장·글로벌 병렬 분석)">
        <ul className="mb-0 ps-3">
          <li className="mb-0">
            <span className="badge bg-secondary me-1">예시</span>
            <strong>지역 화폐·탄소 보상 시스템</strong> —{' '}
            <code className="small text-dark" style={{ color: '#212529' }}>
              {CH2_PARALLEL_DEFAULT}
            </code>
          </li>
        </ul>
      </Ch2ExamplePanel>
      <div className="container py-5">
        <div className="row d-flex justify-content-center">
          <div className="col-sm-10">
            <button className="btn btn-primary" disabled type="button" style={{ visibility: loading ? 'visible' : 'hidden' }}>
              <span className="spinner-border spinner-border-sm" role="status" />
              Loading..
            </button>
            <div className="card">
              <div className="card-header text-muted d-flex justify-content-start align-items-center p-3">
                <div className="input-group mb-0 w-100">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Type message"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && send()}
                  />
                  <button type="button" className="btn btn-primary" onClick={send} disabled={loading}>
                    Send
                  </button>
                </div>
              </div>
              <div className="card-body">
                {rows.map((row) => (
                  <div key={row.id} className="mb-3">
                    {row.kind === 'user' ? <UserChatBlock text={row.text} time={row.time} /> : <BotChatBlock text={row.text} time={row.time} />}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
