/** Thymeleaf ch2 실습 화면과 동일한 예시 문장 (복붙 검증용) */

export const CH2_CHAIN_EXAMPLE_JEJU =
  '2월 말, 혼자 떠나는 제주도 2박 3일 힐링 여행. 조용한 카페와 책방 위주로 가고 싶어';

export const CH2_CHAIN_EXAMPLE_QUANTUM =
  '양자 컴퓨터의 원리인 중첩과 얽힘이 현대 암호화 기술에 미치는 영향에 대한 기술 리포트';

export const CH2_CHAIN_EXAMPLE_COFFEE =
  '버려지는 커피 찌꺼기를 활용해 3D 프린터용 친환경 필라멘트를 만드는 스타트업 아이디어';

export const CH2_PARALLEL_DEFAULT =
  '개인이 텀블러 사용이나 대중교통 이용 등 탄소 절감 활동을 인증하면, 이를 블록체인 기반 토큰으로 보상해주고 지역 상점에서 결제할 수 있게 하는 지역 화폐 시스템';

export const CH2_ROUTING_SIMPLE = '안녕? 오늘 기분이 어때? 간단하게 인사해줘.';

export const CH2_ROUTING_COMPLEX =
  'Spring Boot에서 Redis Pub/Sub을 이용한 비동기 알림 시스템을 구축하는 복잡한 아키텍처를 설계해줘.';

export const CH2_ROUTING_SEARCH = '현재 구글 검색 트렌드에서 가장 핫한 AI 관련 뉴스가 뭐야?';

/** Orchestrator 기본 입력창 값 */
export const CH2_ORCHESTRATOR_DEFAULT =
  '한국의 K-푸드 스타트업이 유럽 시장에 진출하기 위한 종합 전략을 짜줘.';

export const CH2_ORCHESTRATOR_ALT =
  '차세대 전고체 배터리 기술의 현재 단계와 향후 5년 내 상용화 가능성을 분석해줘.';

export const CH2_EVALUATOR_DEFAULT = '스타트업 투자 유치를 위한 1분 엘리베이터 피치 문구를 작성해줘.';

export const CH2_EVALUATOR_ALT = '복잡한 SQL 쿼리 성능을 최적화하는 튜닝 가이드를 작성해줘.';
