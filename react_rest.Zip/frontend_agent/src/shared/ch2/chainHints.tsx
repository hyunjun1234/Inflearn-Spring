/** ch2/1_chain_workflow.html 샘플 프롬프트 */
export function ChainWorkflowHints() {
  return (
    <div>
      <p className="mb-1">2월 말, 혼자 떠나는 제주도 2박 3일 힐링 여행. 조용한 카페와 책방 위주로 가고 싶어</p>
      <p className="mb-1">양자 컴퓨터의 원리인 중첩과 얽힘이 현대 암호화 기술에 미치는 영향에 대한 기술 리포트</p>
      <p className="mb-0">버려지는 커피 찌꺼기를 활용해 3D 프린터용 친환경 필라멘트를 만드는 스타트업 아이디어</p>
    </div>
  );
}
