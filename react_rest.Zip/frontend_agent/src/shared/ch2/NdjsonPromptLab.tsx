import { useState, useCallback, type ReactNode } from 'react';
import { readStreamBodyText } from '../api/readStreamBody';
import { UserChatBlock, BotChatBlock } from '../chat/ChatBlocks';

type Row = { id: string; kind: 'user' | 'bot'; text: string; time: string };

/**
 * Chain / Routing / Orchestrator / Evaluator — Accept: application/x-ndjson 스트림
 */
export default function NdjsonPromptLab({
  title,
  endpoint,
  defaultQuestion,
  hints,
  exampleBanner,
}: {
  title: string;
  endpoint: string;
  defaultQuestion: string;
  hints?: ReactNode;
  /** 입력창 위 예시 안내 (Chapter 3 Auto Pattern Routing과 동일 스타일) */
  exampleBanner?: ReactNode;
}) {
  const [question, setQuestion] = useState(defaultQuestion);
  const [loading, setLoading] = useState(false);
  const [rows, setRows] = useState<Row[]>([]);

  const send = useCallback(async () => {
    const q = question.trim();
    if (!q || loading) return;

    const tu = new Date().toLocaleTimeString('ko-KR');
    setRows((r) => [{ id: crypto.randomUUID(), kind: 'user', text: q, time: tu }, ...r]);
    setLoading(true);

    const botId = crypto.randomUUID();
    const bt = new Date().toLocaleTimeString('ko-KR');
    setRows((r) => [{ id: botId, kind: 'bot', text: '', time: bt }, ...r]);

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Accept: 'application/x-ndjson',
        },
        body: new URLSearchParams({ prompt: q }),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      await readStreamBodyText(response, (full) => {
        setRows((prev) =>
          prev.map((row) => (row.kind === 'bot' && row.id === botId ? { ...row, text: full } : row))
        );
      });
    } catch (e) {
      console.error(e);
      setRows((prev) =>
        prev.map((row) =>
          row.kind === 'bot' && row.id === botId
            ? { ...row, text: `오류: ${e instanceof Error ? e.message : String(e)}` }
            : row
        )
      );
    } finally {
      setLoading(false);
    }
  }, [question, loading, endpoint]);

  return (
    <div className="col-sm-12">
      <h2 className="text-center">{title}</h2>
      {exampleBanner}
      <div className="container py-5">
        <div className="row d-flex justify-content-center">
          <div className="col-sm-10">
            <button className="btn btn-primary" disabled type="button" style={{ visibility: loading ? 'visible' : 'hidden' }}>
              <span className="spinner-border spinner-border-sm" role="status" />
              Loading..
            </button>
            {hints && <div className="card-body py-2 small text-muted">{hints}</div>}
            <div className="card">
              <div className="card-header text-muted d-flex justify-content-start align-items-center p-3">
                <div className="input-group mb-0 w-100">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Type message"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && send()}
                  />
                  <button type="button" className="btn btn-primary" onClick={send} disabled={loading}>
                    Send
                  </button>
                </div>
              </div>
              <div className="card-body">
                {rows.map((row) => (
                  <div key={row.id} className="mb-3">
                    {row.kind === 'user' ? <UserChatBlock text={row.text} time={row.time} /> : <BotChatBlock text={row.text} time={row.time} />}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
