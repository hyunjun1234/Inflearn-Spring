import { springImg } from './springImg';

export function UserChatBlock({ text, time }: { text: string; time: string }) {
  return (
    <>
      <div className="d-flex justify-content-between">
        <p className="small mb-1">User</p>
        <p className="small mb-1 text-muted">{time}</p>
      </div>
      <div className="d-flex flex-row justify-content-start align-items-start">
        <img
          src={springImg('/imgs/user.jpg')}
          alt="User"
          width={45}
          height={45}
          style={{ width: 45, height: 45, objectFit: 'cover', flexShrink: 0 }}
        />
        <div>
          <p className="small p-2 ms-3 mb-3 rounded-3 bg-warning">{text}</p>
        </div>
      </div>
    </>
  );
}

export function BotChatBlock({ text, time }: { text: string; time: string }) {
  return (
    <>
      <div className="d-flex justify-content-between">
        <p className="small mb-1 text-muted">{time}</p>
        <p className="small mb-1">Chatbot</p>
      </div>
      <div className="d-flex flex-row justify-content-end align-items-start mb-4 pt-1">
        <div className="small p-2 me-3 mb-3 rounded-3 bg-info" style={{ overflow: 'auto' }}>
          <pre className="text-white mb-0" style={{ fontWeight: 'bold', whiteSpace: 'pre-wrap' }}>
            {text}
          </pre>
        </div>
        <img
          src={springImg('/imgs/chatbot.png')}
          alt="Chat Bot"
          width={45}
          height={45}
          style={{ width: 45, height: 45, objectFit: 'cover', flexShrink: 0 }}
        />
      </div>
    </>
  );
}
