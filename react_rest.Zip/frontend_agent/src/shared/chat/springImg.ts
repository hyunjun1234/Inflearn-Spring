import { springAbsoluteUrl } from '../config/springUrl';

/** 백엔드에서 제공하는 /imgs/* 경로 */
export function springImg(path: string): string {
  return springAbsoluteUrl(path.startsWith('/') ? path : `/${path}`);
}
