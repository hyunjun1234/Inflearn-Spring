package com.ai.chapter3.service;

import com.ai.shared.publisher.WorkflowStatusPublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * 사용자 입력을 Strategic / Precision / Voting 세 가지 Chapter 3 패턴 중 하나로 분류한 뒤
 * 해당 서비스로 위임하는 오케스트레이션 진입점입니다.
 */
@Service
@Slf4j
public class AutoPatternRoutingService {

    private enum Ch3Pattern {
        STRATEGIC("Strategic Analysis"),
        PRECISION("Precision Execution"),
        VOTING("Voting Analysis");

        private final String label;

        Ch3Pattern(String label) {
            this.label = label;
        }

        String getLabel() {
            return label;
        }
    }

    private static final String ROUTER_SYSTEM = """
            당신은 요청 분류기입니다. 사용자 입력을 아래 세 가지 중 정확히 하나로만 분류하세요.
            응답은 영어 단어 하나만 출력합니다: STRATEGIC, PRECISION, VOTING

            STRATEGIC — 사업·시장·기술·수익·리스크를 아우르는 종합 전략 분석·기획·보고서형 요청.
            강의 실습 1번(Strategic Analysis) 기본 질문과 같은 성격이면 반드시 STRATEGIC:
            「도심형 항공 모빌리티(UAM) 서비스의 국내 도입을 위한 기술적 과제와 예상 수익 모델을 분석해줘.」

            PRECISION — 앱·시스템·서비스 아이디어를 SRS·코드·문서 등 실행 산출물로 구체화하거나 구축 단계까지 요구하는 요청.
            강의 실습 2번(Precision Execution) 기본 질문과 같은 성격이면 반드시 PRECISION:
            「우리 카페 전용 포인트 적립 시스템 앱을 만들고 싶어.」

            VOTING — 시장 수치 예측(CAGR 등)·리스크·투자·정책처럼 불확실성이 크고 여러 모델 관점의 교차 검증·합의가 유리한 질문.
            강의 실습 3번(Voting Analysis) 기본 질문과 같은 성격이면 반드시 VOTING:
            「향후 5년간 고체 배터리 시장의 연평균 성장률(CAGR) 예측치와 주요 리스크 3가지를 알려줘.」

            위 세 문장과 거의 같은 주제·목적이면 해당 패턴을 고르고, 변형된 표현도 동일하게 매핑한다.
            애매하면: 실행 산출물 중심이면 PRECISION, 예측+리스크·다각 검증이면 VOTING, 그 외 광범위 전략 분석이면 STRATEGIC.

            설명이나 따옴표 없이 STRATEGIC, PRECISION, VOTING 중 하나만 출력하세요.
            """;

    private final ChatClient llamaClient;
    private final StrategicAnalysisService strategicAnalysisService;
    private final PrecisionExecutionService precisionExecutionService;
    private final VotingAnalysisService votingAnalysisService;
    private final WorkflowStatusPublisher statusPublisher;

    public AutoPatternRoutingService(
            @Qualifier("llama") ChatClient llamaClient,
            StrategicAnalysisService strategicAnalysisService,
            PrecisionExecutionService precisionExecutionService,
            VotingAnalysisService votingAnalysisService,
            WorkflowStatusPublisher statusPublisher) {
        this.llamaClient = llamaClient;
        this.strategicAnalysisService = strategicAnalysisService;
        this.precisionExecutionService = precisionExecutionService;
        this.votingAnalysisService = votingAnalysisService;
        this.statusPublisher = statusPublisher;
    }

    /**
     * 패턴 라우팅 후 선택된 Chapter 3 파이프라인을 실행합니다.
     */
    public String executeWithMonitoring(UUID workflowId, String input) {
        log.info("[{}] Auto Pattern Routing 시작", workflowId);
        publishStatus(workflowId, "STARTED", "Auto Pattern Routing 워크플로가 시작되었습니다.");
        publishStatus(workflowId, "PATTERN_ROUTING", "적합한 Chapter 3 패턴을 분석 중...");

        String raw;
        try {
            raw = llamaClient.prompt()
                    .system(ROUTER_SYSTEM)
                    .user(input)
                    .call()
                    .content()
                    .trim();
            log.info("[{}] 패턴 라우팅 원문: {}", workflowId, raw);
        } catch (Exception e) {
            log.error("[{}] 패턴 라우팅 실패: {}", workflowId, e.getMessage(), e);
            publishStatus(workflowId, "ERROR", "패턴 라우팅 실패");
            return "패턴 라우팅 실패";
        }

        Ch3Pattern pattern = resolvePattern(raw);
        publishStatus(workflowId, "PATTERN_SELECTED", "선택된 패턴: " + pattern.getLabel());
        log.info(
                "[{}] [Auto Pattern Routing] 라우팅 완료 — 선택 패턴: {} (코드: {}), LLM 응답 원문: [{}]",
                workflowId,
                pattern.getLabel(),
                pattern.name(),
                raw);

        return switch (pattern) {
            case STRATEGIC -> strategicAnalysisService.executeWithMonitoring(workflowId, input);
            case PRECISION -> precisionExecutionService.executeWithMonitoring(workflowId, input);
            case VOTING -> votingAnalysisService.executeWithMonitoring(workflowId, input);
        };
    }

    private void publishStatus(UUID workflowId, String step, String message) {
        statusPublisher.publishStatus(workflowId, step, message);
    }

    private static Ch3Pattern resolvePattern(String raw) {
        if (raw == null || raw.isBlank()) {
            return Ch3Pattern.STRATEGIC;
        }
        String u = raw.toUpperCase();
        if (u.contains("VOTING")) {
            return Ch3Pattern.VOTING;
        }
        if (u.contains("PRECISION")) {
            return Ch3Pattern.PRECISION;
        }
        if (u.contains("STRATEGIC")) {
            return Ch3Pattern.STRATEGIC;
        }
        return Ch3Pattern.STRATEGIC;
    }
}
