package com.ai.shared.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * Redis 관련 Bean 설정을 담당하는 Configuration 클래스
 *
 * - RedisConnectionFactory를 기반으로
 *   1) RedisMessageListenerContainer
 *   2) RedisTemplate
 *   를 Bean으로 등록한다.
 */
@Configuration
public class RedisConfig {

    /**
     * Redis Pub/Sub 메시지를 수신하기 위한 컨테이너 Bean
     *
     * @param connectionFactory Redis 서버와의 연결을 담당하는 Factory
     * @return RedisMessageListenerContainer 인스턴스
     *
     * 역할:
     * - Redis 채널을 구독(Subscribe)하여 메시지를 수신
     * - MessageListener를 등록하여 이벤트 기반 처리 가능
     */
    @Bean
    public RedisMessageListenerContainer redisContainer(RedisConnectionFactory connectionFactory) {

        // Redis 메시지 리스너 컨테이너 생성
        RedisMessageListenerContainer container = new RedisMessageListenerContainer();

        // Redis 연결 팩토리 설정 (Lettuce 또는 Jedis 기반)
        container.setConnectionFactory(connectionFactory);

        // 설정 완료된 컨테이너 반환
        return container;
    }


    /**
     * Redis 데이터를 저장/조회하기 위한 RedisTemplate Bean
     *
     * @param connectionFactory Redis 서버 연결을 담당하는 Factory
     * @return RedisTemplate<String, Object>
     *
     * 역할:
     * - Redis에 데이터를 저장/조회할 때 사용하는 핵심 클래스
     * - Key / Value 직렬화 방식을 설정 가능
     */
    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory connectionFactory) {

        // RedisTemplate 생성
        RedisTemplate<String, Object> template = new RedisTemplate<>();

        // Redis 연결 팩토리 설정
        template.setConnectionFactory(connectionFactory);

        /**
         * Serializer 설정
         *
         * Redis는 기본적으로 byte[] 형태로 데이터를 저장한다.
         * 따라서 Key / Value에 대해 직렬화 전략을 반드시 지정해야 한다.
         */

        // Key는 사람이 읽을 수 있도록 String 형태로 직렬화
        template.setKeySerializer(new StringRedisSerializer());

        // Value는 JSON 형태로 직렬화
        // Object 타입을 JSON으로 변환하여 저장
        template.setValueSerializer(new Jackson2JsonRedisSerializer<>(Object.class));

        // 설정 완료된 RedisTemplate 반환
        return template;
    }
}
