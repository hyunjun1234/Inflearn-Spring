package com.ai.chapter2.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * RoutingWorkflowService
 *
 * 사용자의 입력을 분석하여 적절한 AI 모델로 라우팅하는 서비스 클래스.
 *
 * 동작 흐름:
 * 1. 입력 캐시 확인
 * 2. Llama 모델을 이용한 카테고리 분류 (Router 역할)
 * 3. 분류 결과에 따라 모델 선택
 * 4. 선택된 모델 호출
 * 5. 결과 캐싱 후 반환
 *
 * 확장 포인트:
 * - routingMap에 새로운 카테고리 추가 가능
 * - 캐시를 Caffeine, Redis 등으로 교체 가능
 * - 라우터 모델 변경 가능
 */
@Slf4j
@Service
public class RoutingWorkflowService {

    /**
     * GPT 기반 Cloud 모델 (복잡한 논리, 코딩, 창의적 작업 처리)
     */
    private final ChatClient gptClient;

    /**
     * Gemini 기반 검색 특화 모델 (최신 정보, 검색 기반 응답)
     */
    private final ChatClient geminiClient;

    /**
     * 로컬 Llama 모델
     * - Router 역할 수행
     * - SIMPLE 카테고리 응답 처리
     */
    private final ChatClient llamaClient;

    /**
     * 간단한 인메모리 캐시
     * Key   : 사용자 입력
     * Value : 모델 응답 결과
     *
     * Thread-safe 처리를 위해 ConcurrentHashMap 사용
     */
    private final Map<String, String> cache = new ConcurrentHashMap<>();

    /**
     * 라우팅 테이블
     *
     * Key   : 카테고리명 (SIMPLE, COMPLEX, SEARCH)
     * Value : 해당 카테고리를 처리할 ChatClient
     *
     * 새로운 모델이 추가되면 이 Map에 확장 가능
     */
    private final Map<String, ChatClient> routingMap;

    /**
     * 생성자
     *
     * @param llamaClient  Llama 모델 Bean
     * @param gptClient    GPT 모델 Bean
     * @param geminiClient Gemini 모델 Bean
     */
    public RoutingWorkflowService(
            @Qualifier("llama") ChatClient llamaClient,
            @Qualifier("gpt") ChatClient gptClient,
            @Qualifier("gemini") ChatClient geminiClient) {

        this.gptClient = gptClient;
        this.geminiClient = geminiClient;
        this.llamaClient = llamaClient;

        // 카테고리별 모델 매핑 정의
        this.routingMap = Map.of(
                "SIMPLE", llamaClient,
                "COMPLEX", gptClient,
                "SEARCH", geminiClient
        );
    }

    /**
     * 사용자 입력을 받아 적절한 모델로 라우팅 후 응답을 반환하는 메서드
     *
     * @param userInput 사용자가 입력한 질문/문장
     * @return AI 모델의 응답 결과
     */
    public String executeRouting(String userInput) {

        log.info("=== Routing Workflow 시작 ===");
        log.debug("입력 값: {}", userInput);

        /* ============================================================
         * 1단계: 캐시 확인
         * 동일한 입력에 대해 이미 응답이 존재하면 모델 호출 없이 반환
         * ============================================================ */
        if (cache.containsKey(userInput)) {
            log.info("캐시 히트 발생 - 기존 응답 반환");
            log.debug("캐시된 응답: {}", cache.get(userInput));
            return cache.get(userInput);
        }

        String route;

        /* ============================================================
         * 2단계: Router 모델 호출 (Llama)
         * 사용자 입력을 SIMPLE / COMPLEX / SEARCH 중 하나로 분류
         * ============================================================ */
        try {
            log.info("라우터 호출 시작 - Llama 모델 사용");

            route = llamaClient.prompt()
                    .system("""
                        사용자의 질문을 분석하여 다음 중 하나의 카테고리로 분류하세요:
                        - SIMPLE: 단순 인사, 일상 대화, 요약
                        - COMPLEX: 복잡한 논리, 코딩, 창의적 글쓰기
                        - SEARCH: 최신 뉴스, 구글 관련 정보, 실시간 정보
                        답변은 카테고리 이름만 출력하세요.
                        """)
                    .user(userInput)
                    .call()
                    .content()
                    .trim()
                    .toUpperCase();

            log.info("라우터 분류 결과: {}", route);

        } catch (Exception e) {
            /* ============================================================
             * Router 실패 시 fallback 전략
             * 기본적으로 COMPLEX로 간주하여 GPT 사용
             * ============================================================ */
            log.error("라우터 호출 실패", e);
            route = "COMPLEX";
            log.info("Fallback 카테고리 적용: {}", route);
        }

        /* ============================================================
         * 3단계: 라우팅 테이블을 이용해 모델 선택
         * 정의되지 않은 카테고리는 기본 GPT 사용
         * ============================================================ */
        ChatClient selectedClient = routingMap.getOrDefault(route, gptClient);
        log.info("선택된 모델 완료: {}",
                "SIMPLE".equals(route) ? "LLAMA" :
                        "COMPLEX".equals(route) ? "GPT" :
                                "SEARCH".equals(route) ? "GEMINI" :
                                        "UNKNOWN"
        );
        String response;

        /* ============================================================
         * 4단계: 선택된 모델 호출
         * ============================================================ */
        try {
            log.info("모델 호출 시작");
            response = selectedClient.prompt()
                    .user(userInput)
                    .call()
                    .content();

            log.info("모델 호출 성공");
            log.debug("모델 응답 내용: {}", response);

        } catch (Exception e) {
            /* ============================================================
             * 모델 호출 실패 처리
             * ============================================================ */
            log.error("모델 호출 실패", e);
            response = "모델 호출 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.";
        }

        /* ============================================================
         * 5단계: 응답 결과 캐싱
         * ============================================================ */
        cache.put(userInput, response);
        log.info("응답 캐싱 완료");

        log.info("=== Routing Workflow 종료 ===");

        return response;
    }
}
