package com.ai.chapter9.validation;

import com.ai.chapter8.ymldagengine.definition.WorkflowDefinition;
import org.springframework.stereotype.Component;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

/**
 * Chapter 9. Validated Agent Workflow DSL — 로딩 파이프라인의 검증층.
 * <p>
 * 전제: 실행 엔진·DSL 어휘는 Chapter 8과 동일하고, 워크플로 확장은 YAML(DSL 문서)만.
 * 이 컴포넌트는 YAML로 로딩한 {@link WorkflowDefinition}에 대해 구조적 검증을 수행해,
 * 오타·잘못된 dependsOn·사이클·필수 필드 누락 등을 엔진 스케줄링 전에 드러냅니다.
 * (노드 id·dependsOn 일관성, DAG 사이클, 필수 handler, eval-opt-loop config 등)
 */
@Component
public class WorkflowDefinitionValidator {

    /**
     * @return 오류 메시지 목록. 비어 있으면 검증 통과.
     */
    public List<String> validate(WorkflowDefinition def) {
        // 최종적으로 호출자(로더)에게 반환할 검증 오류 모음입니다.
        List<String> errors = new ArrayList<>();
        // 정의 자체가 null이면 이후 검증이 불가능하므로 즉시 종료합니다.
        if (def == null) {
            errors.add("워크플로 정의가 null 입니다.");
            return errors;
        }
        // 워크플로 식별자(id)는 필수입니다.
        if (def.id() == null || def.id().isBlank()) {
            errors.add("워크플로 id 가 비어 있습니다.");
        }
        // 노드가 없으면 DAG를 구성할 수 없으므로 조기 종료합니다.
        if (def.nodes() == null || def.nodes().isEmpty()) {
            errors.add("nodes 가 비어 있거나 없습니다.");
            return errors;
        }

        // 노드 id 중복/공백을 검사하기 위한 집합입니다.
        Set<String> ids = new HashSet<>();
        // 1차 패스: id 존재 여부 + 중복 여부를 먼저 수집합니다.
        for (WorkflowDefinition.NodeDefinition n : def.nodes()) {
            // 개별 노드 id는 비어 있으면 안 됩니다.
            if (n.id() == null || n.id().isBlank()) {
                errors.add("노드 id 가 비어 있는 항목이 있습니다.");
            // HashSet.add가 false면 이미 같은 id가 등록된 상태이므로 중복입니다.
            } else if (!ids.add(n.id())) {
                errors.add("중복된 노드 id: " + n.id());
            }
        }

        // 2차 패스: handler/dependsOn/config 같은 노드 상세 규칙을 검사합니다.
        for (WorkflowDefinition.NodeDefinition n : def.nodes()) {
            // 모든 노드는 실행 핸들러(handler)를 가져야 엔진이 매핑할 수 있습니다.
            if (n.handler() == null || n.handler().isBlank()) {
                errors.add("노드 '" + n.id() + "' 의 handler 가 비어 있습니다.");
            }
            // dependsOn이 있으면 참조 무결성(빈 값/존재 여부)을 점검합니다.
            if (n.dependsOn() != null) {
                for (String dep : n.dependsOn()) {
                    // 빈 dependsOn 토큰은 유효한 참조가 아닙니다.
                    if (dep == null || dep.isBlank()) {
                        errors.add("노드 '" + n.id() + "' 의 dependsOn 에 빈 값이 있습니다.");
                    // 사전에 수집한 ids에 없는 참조는 정의되지 않은 노드 참조입니다.
                    } else if (!ids.contains(dep)) {
                        errors.add("노드 '" + n.id() + "' 가 존재하지 않는 dependsOn 을 참조합니다: " + dep);
                    }
                }
            }
            // 특수 핸들러 eval-opt-loop는 필수 config 키를 추가로 요구합니다.
            if ("eval-opt-loop".equals(n.handler())) {
                // 편의상 config 맵을 로컬 변수에 받아 검사합니다.
                Map<String, Object> cfg = n.config();
                // 루프 노드는 config 자체가 필수입니다.
                if (cfg == null) {
                    errors.add("노드 '" + n.id() + "' (eval-opt-loop) 에 config 가 필요합니다.");
                } else {
                    // evaluator/optimizer 키는 루프 내부 노드 매핑에 필수입니다.
                    Object ev = cfg.get("evaluator");
                    Object op = cfg.get("optimizer");
                    // evaluator가 없거나 공백이면 실행 시 필요한 평가 노드를 찾을 수 없습니다.
                    if (ev == null || String.valueOf(ev).isBlank()) {
                        errors.add("노드 '" + n.id() + "' 의 config.evaluator 가 필요합니다.");
                    }
                    // optimizer가 없거나 공백이면 실행 시 개선 노드를 찾을 수 없습니다.
                    if (op == null || String.valueOf(op).isBlank()) {
                        errors.add("노드 '" + n.id() + "' 의 config.optimizer 가 필요합니다.");
                    }
                }
            }
        }

        // 3차 패스: 구조적으로 DAG가 순환 없는지(위상 정렬 가능성) 검사합니다.
        List<String> cycleOrOrderErrors = validateAcyclic(def, ids);
        // 사이클/정렬 관련 오류를 기존 오류 목록에 합칩니다.
        errors.addAll(cycleOrOrderErrors);

        // 모든 검증 결과를 호출자에게 반환합니다(비어 있으면 통과).
        return errors;
    }

    /**
     * Kahn 알고리즘으로 위상 정렬 가능 여부(사이클 없음 + 모든 간선 유효)를 검사합니다.
     */
    private List<String> validateAcyclic(WorkflowDefinition def, Set<String> ids) {
        // 이 함수 내에서 발견한 구조 오류 메시지 목록입니다.
        List<String> errors = new ArrayList<>();
        // 각 노드 진입 차수(indegree) = 아직 해소되지 않은 선행 의존성 개수
        Map<String, Integer> indegree = new HashMap<>();
        // 인접 리스트(outgoing): 현재 노드 -> 이 노드를 선행으로 가지는 후속 노드들
        Map<String, List<String>> outgoing = new HashMap<>();
        // 초기화: 모든 노드를 indegree 0, 빈 outgoing 리스트로 시작합니다.
        for (String id : ids) {
            indegree.put(id, 0);
            outgoing.putIfAbsent(id, new ArrayList<>());
        }
        // dependsOn 정보를 순회해 indegree/outgoing 그래프를 구성합니다.
        for (WorkflowDefinition.NodeDefinition n : def.nodes()) {
            // 의존성이 없는 노드는 간선이 없으므로 스킵합니다.
            if (n.dependsOn() == null) {
                continue;
            }
            for (String dep : n.dependsOn()) {
                // 유효하지 않은 참조(dep 미존재)는 앞단 validate에서 이미 에러 처리했으므로 건너뜁니다.
                if (!ids.contains(dep)) {
                    continue;
                }
                // dep -> n.id 간선을 추가합니다.
                outgoing.get(dep).add(n.id());
                // n 입장에서는 선행 의존성이 하나 늘어났으므로 indegree를 1 증가시킵니다.
                indegree.put(n.id(), indegree.getOrDefault(n.id(), 0) + 1);
            }
        }
        // indegree 0인 시작 노드들을 담을 큐입니다(Kahn 알고리즘의 시작점).
        Queue<String> queue = new ArrayDeque<>();
        // 현재 시점에 바로 실행 가능한(선행 의존성 없는) 노드들을 큐에 넣습니다.
        for (Map.Entry<String, Integer> e : indegree.entrySet()) {
            if (e.getValue() == 0) {
                queue.add(e.getKey());
            }
        }
        // 위상 정렬 과정에서 실제로 처리(방문)한 노드 수를 셉니다.
        int visited = 0;
        // 큐가 빌 때까지 처리: 하나씩 꺼내고, 그 노드의 후속 노드 indegree를 감소시킵니다.
        while (!queue.isEmpty()) {
            String id = queue.poll();
            // 큐에서 꺼낸 노드는 정렬 순서에 포함된 것으로 간주합니다.
            visited++;
            for (String next : outgoing.getOrDefault(id, List.of())) {
                // 현재 노드(id)를 처리했으므로 next의 미해결 선행 의존성을 1 줄입니다.
                int d = indegree.merge(next, -1, Integer::sum);
                // indegree가 0이 되면 이제 next도 처리 가능하므로 큐에 넣습니다.
                if (d == 0) {
                    queue.add(next);
                }
            }
        }
        // 방문 수가 전체 노드 수와 다르면 사이클이 있어 일부 노드가 영원히 indegree 0이 되지 않은 상태입니다.
        if (visited != ids.size()) {
            errors.add("DAG 에 사이클이 있거나 dependsOn 관계가 올바르게 정렬되지 않습니다. (노드 수=" + ids.size() + ", 정렬됨=" + visited + ")");
        }
        // 구조 검증 결과를 반환합니다.
        return errors;
    }
}
