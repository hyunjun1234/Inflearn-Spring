package com.ai.chapter9.service;

import com.ai.shared.publisher.WorkflowStatusPublisher;
import com.ai.chapter8.ymldagengine.runtime.WorkflowContext;
import com.ai.chapter8.ymldagengine.runtime.YamlDagWorkflowEngine;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * Chapter 9. Validated Agent Workflow DSL — 서비스 계층.
 * <p>
 * 검증 YAML 로더({@code chapter9Loader})와 동일 {@link YamlDagWorkflowEngine}으로 워크플로를 실행합니다.
 * <p>
 * routing 단계는 {@link com.ai.chapter8.ymldagengine.nodes.RoutingCh8Node}({@code routing-ch8})를 경유하며,
 * 동일 사용자 입력(trim)에 대한 분류는 해당 빈의 인메모리 캐시로 재사용됩니다.
 */
@Service
@Slf4j
public class ValidatedYamlStrategicAnalysisWorkflowService {

    private final YamlDagWorkflowEngine yamlDagWorkflowEngine;
    private final WorkflowStatusPublisher statusPublisher;

    public ValidatedYamlStrategicAnalysisWorkflowService(
            @Qualifier("ch9Engine") YamlDagWorkflowEngine yamlDagWorkflowEngine,
            WorkflowStatusPublisher statusPublisher
    ) {
        this.yamlDagWorkflowEngine = yamlDagWorkflowEngine;
        this.statusPublisher = statusPublisher;
    }

    public String executeWithMonitoring(UUID workflowId, String workflowDefinitionId, String input) {
        WorkflowContext ctx = new WorkflowContext(workflowId, input, statusPublisher);
        try {
            return yamlDagWorkflowEngine.run(workflowDefinitionId, ctx).join();
        } catch (Exception e) {
            log.error("[{}] [Ch9] 검증 YAML DAG 워크플로우 실패 (definitionId={})", workflowId, workflowDefinitionId, e);
            ctx.publish("ERROR", "검증 YAML DAG 워크플로우 실행 실패");
            return "검증 YAML DAG 워크플로우 실행 실패: " + e.getMessage();
        }
    }
}
