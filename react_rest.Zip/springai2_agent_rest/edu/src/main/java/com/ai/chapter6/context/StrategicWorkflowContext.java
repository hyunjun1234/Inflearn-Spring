package com.ai.chapter6.context;

import com.ai.chapter6.config.StrategicAnalysisAgentConfig;
import com.ai.chapter6.service.StrategicAnalysisAgentToolTaskService;

import java.util.UUID;

/**
 * StrategicWorkflowContext
 *
 * 📌 Chapter 6 — TaskTool / TodoWrite 경로 전용. 요청 스레드(ThreadLocal)에 {@code workflowId} 보관.
 *
 * 역할:
 * - 동일 HTTP 요청 처리 스레드에서 현재 워크플로 식별자 조회
 * - 파라미터로 넘기기 어려운 횡단 관심사(예: TodoWrite 핸들러가 {@link #getWorkflowId()}로 Redis {@code AGENT_TODO} 발행)
 * - {@link StrategicAnalysisAgentConfig} 의 {@code strategicAnalysisAgent} {@code workflowIdSupplier} 연동
 *
 * 사용 규칙:
 * - {@link StrategicAnalysisAgentToolTaskService} 진입 경계에서만 set/clear
 * - {@link #clear()}는 반드시 {@code finally}
 * - 오케스트레이터는 가능하면 {@code workflowId}를 파라미터로 명시 전달
 * - Chapter 4·5는 본 클래스를 사용하지 않음
 * - 상세: {@code src/main/resources/docs/workflow-context-guidelines.md}
 */
public final class StrategicWorkflowContext {

    private static final ThreadLocal<UUID> WORKFLOW_ID = new ThreadLocal<>();

    private StrategicWorkflowContext() {
    }

    /**
     * 현재 스레드의 워크플로우 ID를 설정합니다.
     *
     * <p>규칙:
     * <ul>
     *   <li>{@code null} 이 전달되면 ThreadLocal 값을 제거합니다.</li>
     *   <li>그 외에는 현재 요청 스레드에만 UUID를 저장해, 이후 {@link #getWorkflowId()}·TodoWrite 콜백에서 조회할 수 있게 합니다.</li>
     * </ul>
     *
     * @param workflowId SSE·Redis와 매칭되는 추적용 UUID, 또는 제거 시 {@code null}
     */
    public static void setWorkflowId(UUID workflowId) {
        if (workflowId == null) {
            WORKFLOW_ID.remove();
        } else {
            WORKFLOW_ID.set(workflowId);
        }
    }

    /**
     * 현재 스레드에 저장된 워크플로우 ID를 반환합니다.
     *
     * <p>반환 값은 {@link StrategicAnalysisAgentToolTaskService} 진입 시점에
     * {@link #setWorkflowId(UUID)}로 설정된 값이며, 없으면 {@code null} 입니다.</p>
     *
     * @return 현재 스레드 컨텍스트에 저장된 UUID 또는 {@code null}
     */
    public static UUID getWorkflowId() {
        return WORKFLOW_ID.get();
    }

    /**
     * ThreadLocal에 저장된 워크플로우 ID를 제거합니다.
     *
     * <p>항상 진입 경계의 {@code finally} 블록에서 호출해, 요청 처리 후
     * 다른 요청에 값이 섞이지 않도록 해야 합니다.</p>
     */
    public static void clear() {
        WORKFLOW_ID.remove();
    }
}
