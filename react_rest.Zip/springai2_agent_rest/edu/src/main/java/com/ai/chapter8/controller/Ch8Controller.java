package com.ai.chapter8.controller;

import com.ai.chapter8.service.YamlStrategicAnalysisWorkflowService;
import com.ai.shared.openapi.OpenApiExamples;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

/**
 * Ch8Controller
 *
 * 📌 Chapter 8 — YAML 기반 DAG Workflow ({@link YamlDagWorkflowEngine}) 전략 분석 REST API
 *
 * 역할:
 * - Chapter 7과 동일한 비즈니스를 YAML 정의 기반 워크플로로 실행
 * - 화면/SSE는 ch7와 동일 패턴 ({@code pages/ch8/1_strategic_analysis})
 *
 * 엔드포인트:
 * - {@code POST /ch8/strategic-analysis}
 *
 * 요청:
 * - {@code prompt}            — 사용자 프롬프트
 * - {@code workflowId}        — SSE·상태 추적용 UUID
 * - {@code workflowDefinition} — YAML 워크플로 정의 id (예: strategic-analysis)
 *
 * 응답:
 * - 최종 보고서 문자열 (서비스 내부에서 {@code CompletableFuture#join()}으로 동기 반환)
 */
@RestController
@RequestMapping("/ch8")
@Slf4j
@RequiredArgsConstructor
public class Ch8Controller {

    /**
     * YAML DAG 실행 진입점 — {@link WorkflowContext} 생성 후 엔진에 위임
     */
    private final YamlStrategicAnalysisWorkflowService yamlStrategicAnalysisWorkflowService;

    @PostMapping("/strategic-analysis")
    public String strategicAnalysis(
            @Parameter(example = OpenApiExamples.PROMPT_STRATEGIC_UAM) @RequestParam("prompt") String userPrompt,
            @Parameter(example = OpenApiExamples.WORKFLOW_ID_UUID) @RequestParam String workflowId,
            @RequestParam(name = "workflowDefinition", defaultValue = "strategic-analysis") String workflowDefinitionId
    ) {
        UUID id = UUID.fromString(workflowId);
        log.info("Ch8 StrategicAnalysis(YAML DAG) 요청: prompt={}, definition={}", userPrompt, workflowDefinitionId);
        return yamlStrategicAnalysisWorkflowService.executeWithMonitoring(id, workflowDefinitionId, userPrompt);
    }
}

