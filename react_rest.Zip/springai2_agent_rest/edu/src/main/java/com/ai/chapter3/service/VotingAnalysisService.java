package com.ai.chapter3.service;

import com.ai.shared.publisher.WorkflowStatusPublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * ============================================================
 * 📌 VotingAnalysisService
 * ------------------------------------------------------------
 * 3개의 LLM 모델(GPT, Gemini, LLaMA)을 병렬 호출하여
 * 각 모델의 분석 결과를 수집한 뒤,
 * GPT를 판정관(Judge)으로 사용하여
 * 최종 결과를 도출하는 다수결 기반 분석 서비스
 *
 * 주요 기능:
 *  - 모델 병렬 호출 (CompletableFuture)
 *  - Redis Pub/Sub 기반 상태 발행
 *  - 예외 안전 처리
 *  - Executor 리소스 안전 종료
 * ============================================================
 */
@Slf4j
@Service
public class VotingAnalysisService {

    // ============================================================
    // 🔹 의존성 주입 필드
    // ============================================================

    /**
     * GPT 모델 호출을 위한 ChatClient
     * - 객관적 분석 및 최종 판정관 역할 수행
     */
    private final ChatClient gptClient;

    /**
     * Google Gemini 모델 호출용 ChatClient
     * - 통계 기반 분석 역할
     */
    private final ChatClient geminiClient;

    /**
     * Meta LLaMA 모델 호출용 ChatClient
     * - 실행 가능성 중심 분석 역할
     */
    private final ChatClient llamaClient;

    /**
     * Workflow 상태를 Redis Pub/Sub 등 외부 시스템으로 발행하는 컴포넌트
     * - 프론트엔드 실시간 상태 표시
     * - 모니터링 시스템 연동 가능
     */
    private final WorkflowStatusPublisher statusPublisher;

    /**
     * 🧵 모델 병렬 호출용 스레드 풀 ({@link Executors#newFixedThreadPool(int)} — 크기 4).
     *
     * <p><b>사용 이유</b>
     * <ul>
     *   <li>여러 모델 동시 호출 시 공용 {@link java.util.concurrent.ForkJoinPool#commonPool()}에 부담을 주지 않고,
     *       I/O 블로킹이 있는 작업의 <strong>동시 실행 개수를 고정</strong>한다.
     *       {@code newCachedThreadPool} 대신 쓰면 <strong>과도한 스레드 생성</strong>을 막을 수 있다.</li>
     *   <li>싱글톤 서비스에서 공유되면 <strong>모든 HTTP 요청이 동일 풀을 사용</strong>한다.</li>
     * </ul>
     *
     * <p><b>부하·확장</b>: 동시에 처리할 수 있는 양은 코드와 인프라에서 함께 정하고, 넘치면
     * 거절·대기·수평 확장(인스턴스 증설) 등으로 다루는 것이 일반적이다.
     * 이 고정 풀은 <strong>애플리케이션 내부 병렬 단계의 동시 실행 상한</strong>만 나타내며,
     * 큐 적체 방지·전역 동시 요청 제한·타임아웃 등은 별도 설계가 필요할 수 있다.
     */
    private final ExecutorService executor = Executors.newFixedThreadPool(4);


    // ============================================================
    // 🔹 생성자 (Constructor Injection)
    // ============================================================

    /**
     * 생성자 기반 의존성 주입
     *
     * @Qualifier를 사용하여
     * 서로 다른 모델용 ChatClient Bean을 구분
     *
     * @param llamaClient   LLaMA 모델 클라이언트
     * @param gptClient     GPT 모델 클라이언트
     * @param geminiClient  Gemini 모델 클라이언트
     * @param statusPublisher 상태 발행 컴포넌트
     */
    public VotingAnalysisService(
            @Qualifier("llama") ChatClient llamaClient,
            @Qualifier("gpt") ChatClient gptClient,
            @Qualifier("gemini") ChatClient geminiClient,
            WorkflowStatusPublisher statusPublisher
    ) {
        this.gptClient = gptClient;
        this.geminiClient = geminiClient;
        this.llamaClient = llamaClient;
        this.statusPublisher = statusPublisher;
    }


    // ============================================================
    // 🔹 메인 실행 메서드
    // ============================================================

    /**
     * 다수결 기반 분석 실행 메서드
     *
     * 전체 흐름:
     *  1️⃣ 상태 시작 알림
     *  2️⃣ 3개 모델 병렬 호출
     *  3️⃣ 결과 수집
     *  4️⃣ GPT 판정관 최종 결정
     *  5️⃣ 완료 상태 발행
     *
     * @param workflowId  워크플로우 식별자 (로그 추적용)
     * @param input       사용자 질문
     * @return            최종 분석 결과
     */
    public String executeWithMonitoring(UUID workflowId, String input) {



        log.info("[{}] VotingAnalysisService 시작", workflowId);

        // 🔹 상태 시작 알림
        publishStatus(workflowId,
                "VOTING_START",
                "다수결 투표 분석을 시작합니다 (3개 모델 참여)");

        // ============================================================
        // 🔹 모델별 시스템 프롬프트 정의
        // ============================================================

        /**
         * GPT용 시스템 프롬프트
         * - 객관적 지표 중심 답변 유도
         */
        final String GPT_PROMPT = "객관적 지표 위주로 답변하세요.";

        /**
         * Gemini용 시스템 프롬프트
         * - 데이터 및 통계 기반 분석 유도
         */
        final String GEMINI_PROMPT = "데이터 통계 위주로 답변하세요.";

        /**
         * LLaMA용 시스템 프롬프트
         * - 실행 가능성 중심 답변 유도
         */
        final String LLAMA_PROMPT = "실행 가능성 위주로 답변하세요.";


        // ============================================================
        // 🔹 1단계: 3개 모델 병렬 호출
        // ============================================================

        /**
         * voteA
         * - GPT 모델 비동기 호출 결과를 담는 Future
         */
        CompletableFuture<String> voteA =
                CompletableFuture.supplyAsync(() -> {

                            log.info("[{}] GPT 모델 호출 시작", workflowId);

                            String result = gptClient.prompt()
                                    .system(GPT_PROMPT) // 시스템 역할 지정
                                    .user(input)        // 사용자 질문 전달
                                    .call()             // 모델 호출 실행
                                    .content();         // 응답 본문 추출

                            log.info("[{}] GPT 모델 응답 완료", workflowId);
                            return result;

                        }, executor)
                        .exceptionally(ex -> {
                            log.error("[{}] GPT 모델 호출 실패: {}", workflowId, ex.getMessage(), ex);
                            return "GPT 모델 호출 실패: " + ex.getMessage();
                        });


        /**
         * voteB
         * - Gemini 모델 비동기 호출 Future
         */
        CompletableFuture<String> voteB =
                CompletableFuture.supplyAsync(() -> {

                            log.info("[{}] GEMINI 모델 호출 시작", workflowId);

                            String result = geminiClient.prompt()
                                    .system(GEMINI_PROMPT)
                                    .user(input)
                                    .call()
                                    .content();

                            log.info("[{}] GEMINI 모델 응답 완료", workflowId);
                            return result;

                        }, executor)
                        .exceptionally(ex -> {
                            log.error("[{}] GEMINI 모델 호출 실패: {}", workflowId, ex.getMessage(), ex);
                            return "GEMINI 모델 호출 실패: " + ex.getMessage();
                        });


        /**
         * voteC
         * - LLaMA 모델 비동기 호출 Future
         */
        CompletableFuture<String> voteC =
                CompletableFuture.supplyAsync(() -> {

                            log.info("[{}] LLAMA 모델 호출 시작", workflowId);

                            String result = llamaClient.prompt()
                                    .system(LLAMA_PROMPT)
                                    .user(input)
                                    .call()
                                    .content();

                            log.info("[{}] LLAMA 모델 응답 완료", workflowId);
                            return result;

                        }, executor)
                        .exceptionally(ex -> {
                            log.error("[{}] LLAMA 모델 호출 실패: {}", workflowId, ex.getMessage(), ex);
                            return "LLAMA 모델 호출 실패: " + ex.getMessage();
                        });


        // ============================================================
        // 🔹 2단계: 모든 모델 응답 수집
        // ============================================================

        /**
         * join()
         * - 3개 모델 응답이 모두 완료될 때까지 대기
         * - 예외 발생 시 exceptionally에서 처리된 값 반환
         */
        List<String> results = Stream.of(voteA, voteB, voteC)
                .map(CompletableFuture::join)
                .collect(Collectors.toList());

        log.info("[{}] 모든 모델 응답 수집 완료", workflowId);

        publishStatus(workflowId,
                "AGGREGATING",
                "답변 수집 완료. 최종 결과 취합 중...");


        // ============================================================
        // 🔹 3단계: GPT 판정관 최종 결정
        // ============================================================

        log.info("[{}] 최종 결정용 GPT 판정관 호출 시작", workflowId);

        String finalDecision;

        try {

            /**
             * GPT를 판정관(Judge)으로 사용
             * - 3개 모델의 응답을 비교
             * - 가장 논리적인 답변 선택
             */
            finalDecision = gptClient.prompt()
                    .system("""
                            당신은 전문 판정관입니다.
                            아래 3개의 분석 결과 중
                            가장 논리적이고 데이터가 풍부한 답변을 선택하세요.
                            선택된 답변에 대한 결과 내용도 알려줘.
                            선택 사유도 포함하세요.
                            """)
                    .user("답변 1(GPT): " + results.get(0) +
                            "\n답변 2(GEMINI): " + results.get(1) +
                            "\n답변 3(LLAMA): " + results.get(2))
                    .call()
                    .content();

            log.info("[{}] 최종 결정 완료", workflowId);

        } catch (Exception e) {

            /**
             * 판정 단계 실패 시 fallback 처리
             */
            log.error("[{}] 최종 결정 GPT 호출 실패: {}", workflowId, e.getMessage(), e);
            finalDecision = "최종 결정 GPT 호출 실패: " + e.getMessage();
        }


        // 🔹 완료 상태 발행
        publishStatus(workflowId, "COMPLETED", "완료");

        log.info("[{}] VotingAnalysisService 완료", workflowId);


        return """
        ===== GPT 결과 =====
        %s

        ===== GEMINI 결과 =====
        %s

        ===== LLAMA 결과 =====
        %s

        ===== 최종 판정 =====
        %s
        """.formatted(
                results.get(0),
                results.get(1),
                results.get(2),
                finalDecision
        );

    }


    // ============================================================
    // 🔹 상태 발행 보조 메서드
    // ============================================================

    /**
     * 상태 발행 Wrapper 메서드
     *
     * 목적:
     *  - 로그 기록
     *  - 예외 발생 시 메인 로직 중단 방지
     */
    private void publishStatus(UUID workflowId, String step, String message) {

        log.info("[{}] 상태 업데이트: {} - {}", workflowId, step, message);

        try {
            statusPublisher.publishStatus(workflowId, step, message);
        } catch (Exception ex) {
            log.warn("[{}] 상태 발행 실패: {}", workflowId, ex.getMessage(), ex);
        }
    }


    // ============================================================
    // 🔹 Executor 종료 처리
    // ============================================================

    /**
     * Spring 애플리케이션 종료 시 호출
     *
     * 목적:
     *  - ExecutorService 안전 종료
     *  - 리소스 누수 방지
     */
    @PreDestroy
    public void shutdownExecutor() {

        log.info("분석 Executor 종료 중...");

        executor.shutdown();
    }
}
