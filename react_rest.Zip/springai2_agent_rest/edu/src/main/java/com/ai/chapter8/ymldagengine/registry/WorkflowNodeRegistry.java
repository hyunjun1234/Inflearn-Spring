package com.ai.chapter8.ymldagengine.registry;

import com.ai.chapter8.ymldagengine.runtime.WorkflowNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Chapter 8 YAML DAG — {@link WorkflowNode} 빈들을 {@code id()} 기준으로 조회합니다.
 * <p>구현체는 {@code com.ai.chapter8.ymldagengine.nodes} 패키지에 두며, YAML {@code handler}는 보통 {@code …-ch8} 접미 형태입니다.</p>
 */
@Slf4j
@Component
public class WorkflowNodeRegistry {

    private final Map<String, WorkflowNode> nodeById = new ConcurrentHashMap<>();

    public WorkflowNodeRegistry(List<WorkflowNode> yamlDagWorkflowNodes) {
        for (WorkflowNode node : yamlDagWorkflowNodes) {
            String id = node.id();
            if (nodeById.putIfAbsent(id, node) != null) {
                log.warn("중복된 WorkflowNode id 감지: {}", id);
            }
        }
        log.info("WorkflowNodeRegistry 초기화 완료: {} nodes", nodeById.size());
    }

    public WorkflowNode get(String handlerId) {
        return nodeById.get(handlerId);
    }
}
