package com.ai.chapter7.dagengine.core;

import com.ai.chapter7.service.StrategicAnalysisDagWorkflowService;
import com.ai.shared.config.StrategicEvaluatorProperties;
import com.ai.chapter7.dagengine.nodes.EvaluationNode;
import com.ai.chapter7.dagengine.nodes.MarketAnalysisNode;
import com.ai.chapter7.dagengine.nodes.MergeReportNode;
import com.ai.chapter7.dagengine.nodes.OptimizationNode;
import com.ai.chapter7.dagengine.nodes.RouterNode;
import com.ai.chapter7.dagengine.nodes.SimpleQueryNode;
import com.ai.chapter7.dagengine.nodes.TechnicalAnalysisNode;
import com.ai.shared.util.EvaluationApprovalDecider;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PreDestroy;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * DagWorkflowEngine
 *
 * 📌 Chapter 7 — DAG(방향 비순환 그래프)로 전략 분석 워크플로 실행
 *
 * 아키텍처 개요:
 * 1️⃣ Router — SIMPLE / STRATEGIC 분기
 * 2️⃣ SIMPLE — 단일 {@link SimpleQueryNode}로 종료
 * 3️⃣ STRATEGIC — {@link TechnicalAnalysisNode} ∥ {@link MarketAnalysisNode} → {@link MergeReportNode}
 *    → {@link EvaluationNode} ↔ {@link OptimizationNode} 루프(최대 {@link #MAX_EVAL_ROUNDS}회)
 *
 * 특징:
 * - {@link CompletableFuture}로 선행/병렬 의존성 표현
 * - {@link ExecutorService}로 Tomcat 스레드 블로킹 완화
 * - 각 단계는 {@link WorkflowNode} 구현체
 * - 승인 판정은 {@link EvaluationApprovalDecider} + {@link StrategicEvaluatorProperties}
 *
 * HTTP 진입·{@link WorkflowContext} 생성은 {@link StrategicAnalysisDagWorkflowService}.
 */
@Component
@Slf4j
public class DagWorkflowEngine {

    /** Eval ↔ Optimize 반복 상한 (Chapter 4·5·6 오케스트레이터와 동일) */
    private static final int MAX_EVAL_ROUNDS = 4;

    /** 라우팅 — SubAgent 키 {@code routing} */
    private final RouterNode routerNode;

    /** SIMPLE 분기 — 단순 응답 */
    private final SimpleQueryNode simpleQueryNode;

    /** STRATEGIC — 기술 분석 (레지스트리 {@code technical-analysis}) */
    private final TechnicalAnalysisNode technicalAnalysisNode;

    /** STRATEGIC — 시장 분석 (레지스트리 {@code market-analysis}) */
    private final MarketAnalysisNode marketAnalysisNode;

    /** 병렬 산출물을 하나의 초안 문자열로 병합 */
    private final MergeReportNode mergeReportNode;

    /** 초안 품질 평가 (레지스트리 {@code report-evaluator}) */
    private final EvaluationNode evaluationNode;

    /** 평가 피드백 반영 개선 (레지스트리 {@code report-optimizer}) */
    private final OptimizationNode optimizationNode;

    /** {@code strategic.evaluator.approval-threshold} — 승인 메시지·판정에 사용 */
    private final StrategicEvaluatorProperties evaluatorProperties;

    /**
     * 🧵 DAG 실행·병렬 노드용 스레드 풀 ({@link Executors#newFixedThreadPool(int)} — 크기 4).
     *
     * <p><b>사용 이유</b>
     * <ul>
     *   <li>Router 이후 노드가 비동기로 이어지고 기술/시장 병렬 제출 시, 공용
     *       {@link java.util.concurrent.ForkJoinPool#commonPool()} 부담을 줄이며 I/O 블로킹 작업의
     *       <strong>동시 실행 개수를 고정</strong>한다.</li>
     *   <li>싱글톤에서 공유되면 <strong>모든 요청이 동일 풀을 사용</strong>한다.</li>
     * </ul>
     *
     * <p><b>부하·확장</b>: 동시에 처리할 수 있는 양은 코드와 인프라에서 함께 정하고, 넘치면
     * 거절·대기·수평 확장(인스턴스 증설) 등으로 다루는 것이 일반적이다.
     * 이 고정 풀은 <strong>애플리케이션 내부 병렬 단계의 동시 실행 상한</strong>만 나타내며,
     * 큐 적체 방지·전역 동시 요청 제한·타임아웃 등은 별도 설계가 필요할 수 있다.
     */
    private final ExecutorService executor = Executors.newFixedThreadPool(4);

    /**
     * 생성자 — Chapter 7 DAG에 참여하는 노드 빈을 주입합니다.
     */
    public DagWorkflowEngine(
            RouterNode routerNode,
            SimpleQueryNode simpleQueryNode,
            TechnicalAnalysisNode technicalAnalysisNode,
            MarketAnalysisNode marketAnalysisNode,
            MergeReportNode mergeReportNode,
            EvaluationNode evaluationNode,
            OptimizationNode optimizationNode,
            StrategicEvaluatorProperties evaluatorProperties) {
        this.routerNode = routerNode;
        this.simpleQueryNode = simpleQueryNode;
        this.technicalAnalysisNode = technicalAnalysisNode;
        this.marketAnalysisNode = marketAnalysisNode;
        this.mergeReportNode = mergeReportNode;
        this.evaluationNode = evaluationNode;
        this.optimizationNode = optimizationNode;
        this.evaluatorProperties = evaluatorProperties;
    }

    /**
     * run
     *
     * 📌 전체 DAG 실행 진입점
     *
     * 처리 흐름:
     *   1. STARTED 발행
     *   2. Router 실행 → 실패 시 문자열 반환
     *   3. SIMPLE → SimpleQuery → COMPLETED
     *   4. STRATEGIC → {@link #runStrategicBranch(WorkflowContext)}
     *
     * @param ctx  워크플로 ID·사용자 입력·Redis 발행기가 담긴 컨텍스트
     * @return     최종 사용자에게 보여줄 문자열 (동기 join 시 사용)
     */
    public CompletableFuture<String> run(WorkflowContext ctx) {
        // -------------------------------------------------
        // 🟢 0️⃣ 워크플로우 시작
        // -------------------------------------------------
        ctx.publish("STARTED", "DAG 워크플로우가 시작되었습니다.");
        return routerNode.execute(ctx, executor)
                .thenCompose(routeNr -> {
                    if (!routeNr.success()) {
                        ctx.publish("ERROR", routeNr.errorMessage());
                        return CompletableFuture.completedFuture("Routing 단계 실패");
                    }
                    // =================================================
                    // 🟡 SIMPLE 분기
                    // =================================================
                    if ("SIMPLE".equalsIgnoreCase(ctx.getRouteCategory())) {
                        return simpleQueryNode.execute(ctx, executor).thenApply(simpleNr -> {
                            if (!simpleNr.success()) {
                                ctx.publish("ERROR", simpleNr.errorMessage());
                                return "단순 요청 처리 실패";
                            }
                            ctx.publish("COMPLETED", "DAG 워크플로우가 완료되었습니다.");
                            return ctx.getSimpleResponse();
                        });
                    }
                    // =================================================
                    // 🔵 STRATEGIC 분기
                    // =================================================
                    return runStrategicBranch(ctx).thenApply(result -> {
                        ctx.publish("COMPLETED", "DAG 워크플로우가 완료되었습니다.");
                        return result;
                    });
                });
    }

    /**
     * STRATEGIC 하위 그래프: 병렬 분석 → 통합 → 평가/개선 루프
     */
    private CompletableFuture<String> runStrategicBranch(WorkflowContext ctx) {
        CompletableFuture<NodeResult> tech = technicalAnalysisNode.execute(ctx, executor);
        CompletableFuture<NodeResult> market = marketAnalysisNode.execute(ctx, executor);
        return CompletableFuture.allOf(tech, market)
                .thenCompose(v -> mergeReportNode.execute(ctx, executor))
                .thenCompose(mergeNr -> {
                    if (!mergeNr.success()) {
                        ctx.publish("ERROR", mergeNr.errorMessage());
                        return CompletableFuture.completedFuture("병렬 분석 실패");
                    }
                    return runEvaluatorOptimizerLoop(ctx);
                });
    }

    /**
     * Evaluator-Optimizer 루프 (최대 {@link #MAX_EVAL_ROUNDS}회).
     * <p>
     * 한 회차: Evaluation → (통과 조건이 아니면) Optimization → 다음 회차.
     * 통과 조건: 평가문에 {@code PASS} 포함, 또는 추출 점수 ≥ evaluator 임계값.
     * <p>
     * 이전 구현은 {@code for (1..4)} 로 CompletableFuture 체인을 미리 4번 붙여,
     * PASS/점수로 조기 종료해도 다음 회차 평가가 계속 실행되는 문제가 있었다.
     */
    private CompletableFuture<String> runEvaluatorOptimizerLoop(WorkflowContext ctx) {
        return runEvalOptRound(ctx, 1);
    }

    /**
     * runEvalOptRound
     *
     * 📌 Evaluation/Optimization 한 회차를 실행하고, 필요 시 재귀적으로 다음 회차를 이어갑니다.
     *
     * 동작:
     * - {@code round}가 {@link #MAX_EVAL_ROUNDS}를 초과하면 현재 보고서를 그대로 반환하고 종료합니다.
     * - 평가 노드를 실행해 {@link WorkflowContext#setLastEvaluation(String)}를 채운 뒤,
     *   {@link #shouldApproveEvaluation(String)}으로 승인 여부를 판단합니다.
     * - 승인 시 현재 보고서를 반환하고 루프를 종료하고, 미승인 시 Optimization 노드를 실행해
     *   {@link WorkflowContext#setCurrentReport(String)}를 갱신한 뒤 다음 회차를 재귀 호출합니다.
     *
     * @param ctx    현재 워크플로 컨텍스트
     * @param round  1부터 시작하는 평가/개선 회차 번호
     * @return       최종 승인된(또는 최대 회차 이후의) 보고서 문자열을 담은 Future
     */
    private CompletableFuture<String> runEvalOptRound(WorkflowContext ctx, int round) {
        if (round > MAX_EVAL_ROUNDS) {
            return CompletableFuture.completedFuture(ctx.getCurrentReport());
        }
        ctx.setEvaluationRound(round);
        return evaluationNode.execute(ctx, executor).thenCompose(evalNr -> {
            if (!evalNr.success()) {
                return runEvalOptRound(ctx, round + 1);
            }
            String ev = ctx.getLastEvaluation();
            if (shouldApproveEvaluation(ev)) {
                ctx.publish("APPROVED", "최종 승인 완료 (PASS 또는 "
                        + evaluatorProperties.getApprovalThreshold() + "점 이상)");
                return CompletableFuture.completedFuture(ctx.getCurrentReport());
            }
            return optimizationNode.execute(ctx, executor).thenCompose(optNr -> {
                if (!optNr.success()) {
                    ctx.publish("ERROR", optNr.errorMessage());
                }
                return runEvalOptRound(ctx, round + 1);
            });
        });
    }

    /**
     * shouldApproveEvaluation
     *
     * 📌 평가 텍스트와 설정 임계 점수를 기반으로 승인 여부를 판정합니다.
     *
     * @param evaluationText 평가 도구가 반환한 텍스트(점수·pass 여부 포함)
     * @return               승인 조건을 만족하면 {@code true}, 아니면 {@code false}
     */
    private boolean shouldApproveEvaluation(String evaluationText) {
        return EvaluationApprovalDecider.shouldApprove(
                evaluationText,
                evaluatorProperties.getApprovalThreshold());
    }

    /**
     * shutdownExecutor
     *
     * 📌 애플리케이션 종료 시 DAG 실행용 스레드 풀을 정리(shutdown)합니다.
     */
    @PreDestroy
    public void shutdownExecutor() {
        executor.shutdown();
    }
}
