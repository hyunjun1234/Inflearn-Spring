package com.ai.chapter2.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * EvaluationWorkflowService
 *
 * GPT 기반 Optimizer와 Gemini 기반 Evaluator를 활용하여
 * 글을 반복적으로 개선하는 평가 루프 서비스 클래스.
 *
 * 동작 흐름:
 * 1. Optimizer가 초안 작성 또는 수정
 * 2. Evaluator가 점수 및 개선사항 평가
 * 3. 기준 점수 이상이면 종료
 * 4. 아니면 피드백을 반영하여 재작성
 */
@Service
@Slf4j   // Lombok 로그 객체 자동 생성
public class EvaluationWorkflowService {

    /**
     * Optimizer 역할의 ChatClient
     * - 초안 작성 및 개선을 담당
     * - GPT 모델에 연결되어 있다고 가정
     */
    private final ChatClient gptClient;

    /**
     * Evaluator 역할의 ChatClient
     * - 결과물 평가 및 점수 산정 담당
     * - Gemini 모델에 연결되어 있다고 가정
     */
    private final ChatClient geminiClient;

    /**
     * 최대 반복 횟수
     * 무한 루프 방지를 위한 안전 장치
     */
    private static final int MAX_ITERATIONS = 3;

    /**
     * PASS 기준 점수
     * 이 점수 이상이면 반복 종료
     */
    private static final int PASS_SCORE = 80;

    /**
     * 평가 결과에서 점수를 추출하기 위한 정규식 패턴
     * 예: "점수: 85"
     */
    private static final Pattern SCORE_PATTERN = Pattern.compile("점수:\\s*(\\d+)");

    /**
     * 생성자 기반 의존성 주입
     *
     * @param gptClient     Optimizer 역할 ChatClient
     * @param geminiClient  Evaluator 역할 ChatClient
     */
    public EvaluationWorkflowService(
            @Qualifier("gpt") ChatClient gptClient,
            @Qualifier("gemini") ChatClient geminiClient) {
        this.gptClient = gptClient;
        this.geminiClient = geminiClient;
    }

    /**
     * Optimizer + Evaluator 루프 실행 메서드
     *
     * @param userInput 사용자의 최초 입력
     * @return 최종 점수 + 최종 결과물
     */
    public String executeOptimizerLoop(String userInput) {

        // 현재까지 생성된 결과물 저장 변수
        String currentOutput = "";

        // Evaluator 피드백을 저장하는 변수
        String feedback = "첫 번째 초안을 작성해 주세요.";

        // 최종 점수 저장 변수
        Integer score = 0;

        // 최대 반복 횟수만큼 루프 실행
        for (int i = 1; i <= MAX_ITERATIONS; i++) {

            log.info("===== Optimizer Loop Iteration {} =====", i);

            try {

                /**
                 * ===============================
                 * 1단계: Optimizer 호출
                 * ===============================
                 *
                 * 이전 피드백을 system 메시지에 반영하여
                 * 더 나은 결과를 생성하도록 유도
                 */
                currentOutput = gptClient.prompt()
                        .system("당신은 전문 작가입니다. 다음 피드백을 반영하여 최고의 결과물을 만드세요: " + feedback)
                        .user(userInput + (currentOutput.isEmpty() ? "" : "\n현재버전: " + currentOutput))
                        .call()
                        .content();

                log.info("Optimizer Output:\n{}", currentOutput);

                /**
                 * ===============================
                 * 2단계: Evaluator 호출
                 * ===============================
                 *
                 * 생성된 결과물을 평가하여
                 * 점수 및 개선사항을 반환받음
                 */
                String evaluation = geminiClient.prompt()
                        .system("""
                                당신은 비평가입니다.
                                제출된 글을 '점수: 0~100'와 '개선사항' 형식으로 평가하세요.
                                만약 80점 이상이라면 'PASS'라고 첫 줄에 적으세요.
                                """)
                        .user(currentOutput)
                        .call()
                        .content();

                log.info("Evaluator Feedback:\n{}", evaluation);

                /**
                 * ===============================
                 * 3단계: 점수 추출
                 * ===============================
                 */
                score = extractScore(evaluation);

                if (score != null) {
                    log.info("Evaluator Score: {}", score);

                    /**
                     * ===============================
                     * 4단계: PASS 여부 판단
                     * ===============================
                     */
                    if (score >= PASS_SCORE) {
                        log.info("PASS 기준 충족, 루프 종료");
                        break;
                    }
                } else {
                    log.warn("점수 추출 실패, 루프 계속 진행");
                }

                /**
                 * ===============================
                 * 5단계: 피드백 갱신
                 * ===============================
                 *
                 * 다음 반복에서 반영하기 위해
                 * 평가 내용을 feedback 변수에 저장
                 */
                feedback = evaluation;

            } catch (Exception e) {

                /**
                 * 예외 발생 시:
                 * - 로그 기록
                 * - 루프 강제 종료
                 */
                log.error("Optimizer/Evaluator 호출 중 예외 발생", e);
                break;
            }
        }

        /**
         * 최종 결과 반환
         * 형식: "점수 : 결과물"
         */
        return "Score: "+score + " >>" + currentOutput;
    }

    /**
     * Evaluator의 텍스트 결과에서 점수를 추출하는 메서드
     *
     * @param evaluation 평가 모델이 반환한 텍스트
     * @return 추출된 점수(Integer), 없으면 null
     */
    private Integer extractScore(String evaluation) {

        // 정규식 매칭 수행
        Matcher matcher = SCORE_PATTERN.matcher(evaluation);

        if (matcher.find()) {
            try {
                // 매칭된 숫자 문자열을 정수로 변환
                return Integer.parseInt(matcher.group(1));
            } catch (NumberFormatException e) {
                log.warn("점수 파싱 실패: {}", matcher.group(1));
            }
        }

        // 점수 패턴을 찾지 못한 경우
        return null;
    }
}
