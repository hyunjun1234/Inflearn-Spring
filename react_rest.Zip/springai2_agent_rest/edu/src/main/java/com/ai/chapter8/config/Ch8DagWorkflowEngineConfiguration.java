package com.ai.chapter8.config;

import com.ai.chapter8.ymldagengine.definition.WorkflowDefinitionLoader;
import com.ai.chapter8.ymldagengine.registry.WorkflowNodeRegistry;
import com.ai.chapter8.ymldagengine.runtime.YamlDagWorkflowEngine;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Chapter 8 — {@link YamlDagWorkflowEngine}에 {@code chapter8Loader}와 {@link WorkflowNodeRegistry}를 주입합니다.
 */
@Configuration
public class Ch8DagWorkflowEngineConfiguration {

    @Bean
    @Qualifier("ch8Engine")
    public YamlDagWorkflowEngine yamlDagWorkflowEngineCh8(
            @Qualifier("chapter8Loader") WorkflowDefinitionLoader chapter8Loader,
            WorkflowNodeRegistry workflowNodeRegistry
    ) {
        return new YamlDagWorkflowEngine(chapter8Loader, workflowNodeRegistry);
    }
}
