package com.ai.chapter6.service;

import com.ai.shared.publisher.WorkflowStatusPublisher;
import com.ai.chapter6.config.StrategicAnalysisAgentConfig;
import com.ai.shared.util.EvaluationApprovalDecider;
import com.ai.shared.config.StrategicEvaluatorProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
/**
 * StrategicAnalysisTaskToolOrchestrator
 *
 * 📌 Chapter 6 — Task-Orchestrated Multi-Agent 메인 오케스트레이터 (agent-utils + TaskTool)
 *
 * 아키텍처 개요:
 * 1️⃣ Router — TaskTool로 {@code routing} 서브에이전트 호출 → SIMPLE / STRATEGIC
 * 2️⃣ SIMPLE — {@code simple-query} 한 번 호출 후 종료
 * 3️⃣ STRATEGIC — {@code technical-analysis} ∥ {@code market-analysis} 병렬 → Eval/Optimize 루프
 *
 * 특징:
 * - 단계 순서는 Java가 고정, 문장 생성은 Markdown 서브에이전트({@code classpath:/agents/strategic/*.md})
 * - {@link StrategicAnalysisAgentConfig}의 {@code strategicAnalysisAgent} {@link ChatClient} 사용
 * - AGENT_TODO 스냅샷으로 UI에 진행 단계 표시
 * - 승인 임계점수는 {@link StrategicEvaluatorProperties}
 *
 * 실행 단계(라우팅/병렬/평가-개선)는 본 클래스가 결정하고, 각 단계 본문은 TaskTool 서브에이전트에 위임합니다.
 */
@Service
@Slf4j
public class StrategicAnalysisTaskToolOrchestrator {
    /**
     * UI·Redis용 할 일 요약 문구 (AGENT_TODO와 대응)
     */
    private static final String[] TODO_CONTENTS = new String[]{
            "요청 라우팅(SIMPLE/STRATEGIC 분류)",
            "기술 분석(STRATEGIC일 때)",
            "시장 분석(STRATEGIC일 때)",
            "보고서 평가/개선 및 최종 응답"
    };

    /** Redis/SSE 단계 및 AGENT_TODO 발행 */
    private final WorkflowStatusPublisher statusPublisher;

    /**
     * 🤖 strategicAnalysisAgent 빈
     *
     * 역할:
     * - TaskTool + TodoWrite가 기본 탑재된 {@link ChatClient}
     * - 사용자 메시지에서 “어떤 서브에이전트를 호출할지”를 유도
     */
    private final ChatClient strategicAgent;

    /** {@code strategic.evaluator.approval-threshold} */
    private final StrategicEvaluatorProperties evaluatorProperties;

    /**
     * 🧵 병렬 분석 전용 스레드 풀 ({@link Executors#newFixedThreadPool(int)} — 크기 4).
     *
     * <p><b>사용 이유</b>
     * <ul>
     *   <li>기술/시장 등 병렬 LLM 호출 시 공용 {@link java.util.concurrent.ForkJoinPool#commonPool()}에 부담을 주지 않고,
     *       I/O 블로킹이 있는 작업의 <strong>동시 실행 개수를 고정</strong>한다.</li>
     *   <li>싱글톤 서비스에서 공유되면 <strong>모든 HTTP 요청이 동일 풀을 사용</strong>한다.</li>
     * </ul>
     *
     * <p><b>부하·확장</b>: 동시에 처리할 수 있는 양은 코드와 인프라에서 함께 정하고, 넘치면
     * 거절·대기·수평 확장(인스턴스 증설) 등으로 다루는 것이 일반적이다.
     * 이 고정 풀은 <strong>애플리케이션 내부 병렬 단계의 동시 실행 상한</strong>만 나타내며,
     * 큐 적체 방지·전역 동시 요청 제한·타임아웃 등은 별도 설계가 필요할 수 있다.
     */
    private final ExecutorService analysisExecutor = Executors.newFixedThreadPool(4);

    /** 사용자 입력(trim) → SIMPLE / STRATEGIC — routing 서브에이전트 재호출 생략 */
    private final Map<String, String> routingCategoryCache = new ConcurrentHashMap<>();

    /**
     * 생성자
     *
     * @param strategicAgent 빈 이름 {@code strategicAnalysisAgent}
     */
    public StrategicAnalysisTaskToolOrchestrator(
            WorkflowStatusPublisher statusPublisher,
            @Qualifier("strategicAnalysisAgent") ChatClient strategicAgent,
            StrategicEvaluatorProperties evaluatorProperties) {
        this.statusPublisher = statusPublisher;
        this.strategicAgent = strategicAgent;
        this.evaluatorProperties = evaluatorProperties;
    }

    /**
     * executeWithMonitoring
     *
     * 📌 TaskTool 경로 전략 분석 전체 실행 (ch6)
     *
     * 처리 흐름:
     *   0. AGENT_TODO 스냅샷 (진행 UI)
     *   1. Routing
     *   2. Parallel Analysis
     *   3. Evaluator-Optimizer Loop
     *
     * @param workflowId SSE·Redis 추적 ID
     * @param input      사용자 프롬프트
     * @return           최종 보고서 또는 오류 메시지
     */
    public String executeWithMonitoring(UUID workflowId, String input) {

        // -------------------------------------------------
        // 🟢 0️⃣ AGENT_TODO 스냅샷 (Chapter 3에는 없음 — Redis/SSE로 할 일 진행 표시)
        // -------------------------------------------------

        String[] todoStates = new String[]{"pending", "pending", "pending", "pending"};
        publishAgentTodoSnapshot(workflowId, todoStates);

        // =================================================
        // 🟡 1️⃣ Routing 단계
        // =================================================
        //
        // Chapter 3와 동일하게 SIMPLE / STRATEGIC 분기.
        // 여기서는 runSubAgent("routing", …) → strategicAnalysisAgent(ChatClient)가 TaskTool로 Markdown 서브에이전트 호출.

        publishStatus(workflowId, "ROUTING", "질문 카테고리를 분석 중...");
        todoStates[0] = "in_progress";
        publishAgentTodoSnapshot(workflowId, todoStates);

        String category; // SIMPLE or STRATEGIC 저장 변수
        String cacheKey = input == null ? "" : input.trim();

        try {
            String cached = routingCategoryCache.get(cacheKey);
            if (cached != null) {
                category = cached;
                log.info("[{}] Routing 캐시 히트: {}", workflowId, category);
            } else {
                String routingRaw = runSubAgent("routing", input).trim();
                category = resolveRoutingCategory(routingRaw);
                routingCategoryCache.put(cacheKey, category);
                log.info("[{}] Routing 결과: {}", workflowId, category);
            }
            String normalizedCategory = "SIMPLE".equalsIgnoreCase(category) ? "SIMPLE" : "STRATEGIC";
            publishStatus(workflowId, "ROUTING_RESULT", "routing=" + normalizedCategory);
            todoStates[0] = "completed";
            publishAgentTodoSnapshot(workflowId, todoStates);

        } catch (Exception e) {
            // Routing 실패 시 즉시 종료
            log.error("[{}] Routing 실패: {}", workflowId, e.getMessage(), e);
            publishStatus(workflowId, "ERROR", "Routing 단계 실패");
            return "Routing 단계 실패";
        }

        /**
         * SIMPLE 요청 처리 분기
         * - 추가 병렬 분석 없이 바로 응답 반환
         * - runSubAgent("simple-query", …) 한 번
         */
        if ("SIMPLE".equalsIgnoreCase(category)) {
            try {
                todoStates[1] = "completed";
                todoStates[2] = "completed";
                todoStates[3] = "in_progress";
                publishAgentTodoSnapshot(workflowId, todoStates);

                String result = runSubAgent("simple-query", input);

                todoStates[3] = "completed";
                publishAgentTodoSnapshot(workflowId, todoStates);
                publishStatus(workflowId, "COMPLETED", "단순 요청 처리 완료");
                return result;

            } catch (Exception e) {
                log.error("[{}] SIMPLE 처리 실패", workflowId, e);
                publishStatus(workflowId, "ERROR", "단순 요청 처리 실패");
                return "단순 요청 처리 실패";
            }
        }

        // =================================================
        // 🔵 2️⃣ Parallel Analysis 단계
        // =================================================

        publishStatus(workflowId, "ANALYZING", "기술 및 시장 데이터를 동시에 분석 중...");
        log.info("[{}] Parallel 분석 시작", workflowId);
        todoStates[1] = "in_progress";
        todoStates[2] = "in_progress";
        publishAgentTodoSnapshot(workflowId, todoStates);

        /**
         * 🔹 기술 분석 Future
         * - runSubAgent("technical-analysis", …)
         * - analysisExecutor 사용
         */
        CompletableFuture<String> techFuture =
                CompletableFuture.supplyAsync(() -> {
                    try {
                        return runSubAgent("technical-analysis", input);
                    } catch (Exception e) {
                        log.error("[{}] 기술 분석 실패", workflowId, e);
                        return "기술 분석 실패";
                    }
                }, analysisExecutor);

        /**
         * 🔹 시장 분석 Future
         * - runSubAgent("market-analysis", …)
         */
        CompletableFuture<String> marketFuture =
                CompletableFuture.supplyAsync(() -> {
                    try {
                        return runSubAgent("market-analysis", input);
                    } catch (Exception e) {
                        log.error("[{}] 시장 분석 실패", workflowId, e);
                        return "시장 분석 실패";
                    }
                }, analysisExecutor);

        String draftReport; // 병렬 분석 결과 저장 변수

        try {
            /**
             * thenCombine()
             * - 두 Future 완료 후 실행
             * - 기술 + 시장 분석 결합 (Chapter 3와 유사하나 줄바꿈 형식만 다름)
             */
            draftReport = techFuture
                    .thenCombine(marketFuture, (tech, market) -> "기술분석:\n" + tech + "\n\n시장분석:\n" + market)
                    .join(); // blocking

            todoStates[1] = "completed";
            todoStates[2] = "completed";
            todoStates[3] = "in_progress";
            publishAgentTodoSnapshot(workflowId, todoStates);
            log.info("[{}] Parallel 분석 완료", workflowId);

        } catch (Exception e) {
            log.error("[{}] Parallel 처리 실패", workflowId, e);
            publishStatus(workflowId, "ERROR", "Parallel 분석 실패");
            return "병렬 분석 실패";
        }

        // =================================================
        // 🟣 3️⃣ Evaluator-Optimizer Loop
        // =================================================

        String finalReport = draftReport; // 반복 수정용 보고서 변수

        /**
         * 최대 4회 반복
         * - runSubAgent("report-evaluator", …) → 평가
         * - EvaluationApprovalDecider + 임계점수 (Chapter 3의 "PASS" 검사와 대응)
         * - 미승인 시 runSubAgent("report-optimizer", 합쳐진 프롬프트)
         */
        for (int i = 1; i <= 4; i++) {

            publishStatus(workflowId, "EVALUATING", i + "차 검토 중...");
            log.info("[{}] Draft #{} 평가 시작", workflowId, i);

            String evaluation; // 평가 결과 저장

            try {
                evaluation = runSubAgent("report-evaluator", finalReport);

            } catch (Exception e) {
                log.error("[{}] 평가 실패", workflowId, e);
                publishStatus(workflowId, "ERROR", "평가 실패");
                break;
            }

            Integer score = EvaluationApprovalDecider.extractScore(evaluation);
            if (score != null) {
                publishStatus(workflowId, "EVALUATION_SCORE", i + "차 평가 점수: " + score + "점");
            } else {
                publishStatus(workflowId, "EVALUATION_SCORE", i + "차 평가 점수: 추출 실패");
            }

            if (shouldApproveEvaluation(evaluation)) {
                todoStates[3] = "completed";
                publishAgentTodoSnapshot(workflowId, todoStates);
                publishStatus(workflowId, "COMPLETED", "최종 승인 완료");
                log.info("[{}] Draft #{} 승인 완료", workflowId, i);
                break;
            }

            /**
             * Optimizer 단계
             * - 초안 + 피드백을 한 문자열로 묶어 report-optimizer 서브에이전트 호출
             */
            publishStatus(workflowId, "OPTIMIZING", "보고서 수정 중...");

            try {
                finalReport = runSubAgent(
                        "report-optimizer",
                        "현재 초안 보고서:\n" + finalReport + "\n\n평가 피드백:\n" + evaluation);

            } catch (Exception e) {
                log.error("[{}] 수정 실패", workflowId, e);
                publishStatus(workflowId, "ERROR", "보고서 수정 실패");
                break;
            }
        }

        return finalReport;
    }

    /**
     * runSubAgent
     *
     * 📌 strategicAnalysisAgent(ChatClient)에 TaskTool 프롬프트를 구성해 특정 서브에이전트를 실행합니다.
     *
     * 동작:
     * - 사용자 입력과 함께 “반드시 task 도구로 해당 서브에이전트를 호출하라”는 지시를 포함한 user 프롬프트를 만듭니다.
     * - {@link ChatClient#prompt()}를 통해 TaskTool/TodoWrite가 연결된 에이전트를 호출하고, 최종 content를 반환합니다.
     *
     * @param subAgentName 실행할 서브에이전트 이름 (예: {@code routing}, {@code technical-analysis})
     * @param payload      사용자 프롬프트 또는 상위 단계 결과
     * @return             서브에이전트 실행 결과 텍스트
     */
    private String runSubAgent(String subAgentName, String payload) {
        String userMessage = """
                반드시 task 도구를 사용하여 '%s' 서브에이전트를 호출하세요.

                사용자 요청/입력은 아래와 같습니다.

                %s
                """.formatted(subAgentName, payload);

        return strategicAgent.prompt()
                .user(userMessage)
                .call()
                .content();
    }

    /**
     * resolveRoutingCategory
     *
     * 📌 라우팅 서브에이전트 결과를 SIMPLE/STRATEGIC 두 값 중 하나로 정규화합니다.
     *
     * 규칙:
     * - 대소문자·주변 텍스트를 무시하고, "SIMPLE" 만 포함되면 SIMPLE
     * - "STRATEGIC" 이 포함되면 STRATEGIC
     * - 그 외(빈 문자열, 예측 불가 값)는 STRATEGIC 으로 간주합니다.
     *
     * @param raw 라우팅 결과 원문 문자열
     * @return    "SIMPLE" 또는 "STRATEGIC"
     */
    private String resolveRoutingCategory(String raw) {
        String upper = raw == null ? "" : raw.toUpperCase();
        if (upper.contains("SIMPLE") && !upper.contains("STRATEGIC")) {
            return "SIMPLE";
        }
        if (upper.contains("STRATEGIC")) {
            return "STRATEGIC";
        }
        return "STRATEGIC";
    }

    /**
     * shouldApproveEvaluation
     *
     * 📌 평가 서브에이전트가 반환한 평가 텍스트와 설정 임계점수로 승인 여부를 판단합니다.
     *
     * 동작:
     * - {@link EvaluationApprovalDecider#shouldApprove(String, Integer)}에 평가 결과와
     *   {@link StrategicEvaluatorProperties#getApprovalThreshold()} 값을 넘겨 위임합니다.
     *
     * @param evaluationText 보고서 평가 결과 텍스트
     * @return               승인해야 하면 {@code true}, 재수정이 필요하면 {@code false}
     */
    private boolean shouldApproveEvaluation(String evaluationText) {
        return EvaluationApprovalDecider.shouldApprove(
                evaluationText,
                evaluatorProperties.getApprovalThreshold());
    }

    /**
     * publishAgentTodoSnapshot
     *
     * 📌 AGENT_TODO 단계에 맞춰 현재 워크플로우의 할 일 진행 상태를 Redis/SSE 로 발행합니다.
     *
     * 동작:
     * - {@link #TODO_CONTENTS}와 전달받은 상태 배열(states)을 순회하며,
     *   각 단계별 한글 상태 문구를 생성해 {@link WorkflowStatusPublisher}로 보냅니다.
     * - 발행 실패 시 워크플로우는 계속 진행되고, 경고 로그만 남깁니다.
     *
     * @param workflowId 워크플로우 추적용 UUID
     * @param states     각 단계의 상태 문자열 배열 (예: {@code pending}, {@code in_progress}, {@code completed})
     */
    private void publishAgentTodoSnapshot(UUID workflowId, String[] states) {
        try {
            statusPublisher.publishStatus(workflowId, "AGENT_TODO", "할 일 " + TODO_CONTENTS.length + "개");
            for (int i = 0; i < TODO_CONTENTS.length; i++) {
                statusPublisher.publishStatus(
                        workflowId,
                        "AGENT_TODO",
                        (i + 1) + ". " + statusKo(states[i]) + " — " + TODO_CONTENTS[i]);
            }
        } catch (Exception ex) {
            log.warn("[{}] AGENT_TODO 발행 실패", workflowId, ex);
        }
    }

    /**
     * statusKo
     *
     * 📌 내부 상태 문자열을 한글 상태 문구로 변환합니다.
     *
     * 매핑:
     * - {@code in_progress} → "진행 중"
     * - {@code completed}   → "완료"
     * - 기타/알 수 없는 값  → "대기"
     *
     * @param state 상태 코드 문자열
     * @return      한글 상태 설명
     */
    private String statusKo(String state) {
        if ("in_progress".equalsIgnoreCase(state)) {
            return "진행 중";
        }
        if ("completed".equalsIgnoreCase(state)) {
            return "완료";
        }
        return "대기";
    }

    /**
     * publishStatus
     *
     * 📌 상태 단계(step)와 메시지를 Redis/SSE 로 발행하는 공통 헬퍼입니다.
     *
     * 특징:
     * - 네트워크/Redis 예외가 발생해도 서비스 전체 실패로 간주하지 않고, 경고 로그만 남깁니다.
     *
     * @param workflowId 워크플로우 추적용 UUID
     * @param step       단계 코드 (예: {@code ROUTING}, {@code ANALYZING}, {@code EVALUATING}, {@code OPTIMIZING}, {@code COMPLETED}, {@code ERROR})
     * @param message    UI·운영자용 설명 메시지
     */
    private void publishStatus(UUID workflowId, String step, String message) {
        try {
            statusPublisher.publishStatus(workflowId, step, message);
        } catch (Exception ex) {
            log.warn("[{}] 상태 발행 실패", workflowId, ex);
        }
    }

    /**
     * shutdownExecutor
     *
     * 📌 애플리케이션 종료 시 병렬 분석용 스레드 풀을 정리(shutdown)합니다.
     *
     * 동작:
     * - {@link PreDestroy} 훅에서 호출되어 더 이상 새로운 작업을 받지 않고,
     *   진행 중인 작업을 마무리한 뒤 풀을 종료합니다.
     */
    @PreDestroy
    public void shutdownExecutor() {
        analysisExecutor.shutdown();
    }

}
