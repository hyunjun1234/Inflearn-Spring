package com.ai.shared.publisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;

/**
 * Workflow 상태 이벤트를 Redis로 발행합니다.
 *
 * 동작:
 * - 실시간 전달: Pub/Sub 채널(`workflow:status:{workflowId}`)로 즉시 전송
 * - 유실 완화: 최근 이벤트를 List(`workflow:status:history:{workflowId}`)에 버퍼링
 *
 * 버퍼링은 SSE 연결 직후 replay 용도이며, TTL과 최대 길이로 자동 정리됩니다.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class WorkflowStatusPublisher {
    /** SSE replay 용 최근 상태 보관 시간 */
    private static final Duration STATUS_BUFFER_TTL = Duration.ofMinutes(15);
    /** workflow 당 보관할 최대 이벤트 수 */
    private static final int STATUS_BUFFER_MAX_SIZE = 200;

    /**
     * Redis I/O 엔트리 포인트.
     * - `convertAndSend`: 실시간 Pub/Sub 발행
     * - `opsForList`: 상태 이력 버퍼 저장
     */
    private final RedisTemplate<String, Object> redisTemplate;

    /**
     * workflow 상태를 실시간 채널과 이력 버퍼에 동시에 기록합니다.
     *
     * @param workflowId 워크플로우 고유 ID (UUID)
     * @param step       현재 단계 이름 (예: STARTED, ROUTING, COMPLETED)
     * @param message    단계에 대한 설명 메시지
     */
    public void publishStatus(UUID workflowId, String step, String message) {

        // ============================================================
        // 1️⃣ 전송할 상태 데이터 구성
        // ============================================================
        // Redis로 전송할 상태 payload
        Map<String, Object> statusUpdate = Map.of(
                "workflowId", workflowId.toString(),     // 워크플로우 ID
                "step", step,                            // 현재 단계
                "message", message,                      // 상태 메시지
                "timestamp", LocalDateTime.now().toString() // 현재 시간
        );

        // ============================================================
        // 2️⃣ Redis Pub/Sub 채널명 생성
        // ============================================================
        // 채널 구조 예:
        // workflow:status:550e8400-e29b-41d4-a716-446655440000
        //
        // workflowId 단위로 채널을 분리하면
        // 특정 Workflow에 대한 상태만 구독 가능
        String channel = "workflow:status:" + workflowId;

        // replay 용 이력 버퍼 key
        String historyKey = "workflow:status:history:" + workflowId;

        // ============================================================
        // 3️⃣ Redis Pub/Sub 메시지 발행
        // ============================================================
        // convertAndSend(channel, message)
        // - 해당 채널을 구독하고 있는 모든 Subscriber에게 메시지 전송
        // - Pub/Sub은 비동기 이벤트 전달 방식
        redisTemplate.convertAndSend(channel, statusUpdate);

        // Pub/Sub은 비영속이므로, 느린 환경에서 초기 이벤트(STARTED)가 유실되지 않도록
        // 최근 상태 이력을 Redis List에 잠시 보관한다.
        redisTemplate.opsForList().rightPush(historyKey, statusUpdate);
        redisTemplate.opsForList().trim(historyKey, -STATUS_BUFFER_MAX_SIZE, -1);
        redisTemplate.expire(historyKey, STATUS_BUFFER_TTL);

        // ============================================================
        // 4️⃣ 로깅 (디버깅용)
        // ============================================================
        log.info("[Redis Publish] step={}, message={}", step, message);
    }
}
