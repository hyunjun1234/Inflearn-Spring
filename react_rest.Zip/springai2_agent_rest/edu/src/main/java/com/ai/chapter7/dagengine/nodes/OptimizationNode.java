package com.ai.chapter7.dagengine.nodes;

import com.ai.shared.agent.subagent.ReportOptimizerSubagent;
import com.ai.chapter7.dagengine.core.NodeResult;
import com.ai.chapter7.dagengine.core.WorkflowContext;
import com.ai.chapter7.dagengine.core.WorkflowNode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * OptimizationNode
 *
 * 📌 Evaluator 피드백을 반영해 초안 보고서를 개선하는 노드
 *
 * 아키텍처 개요:
 * 1️⃣ {@link EvaluationNode} 직후, 승인 실패 시 Eval↔Optimize 루프에서 반복 호출
 * 2️⃣ {@link ReportOptimizerSubagent}에 초안+평가문을 전달 (Chapter 4 서브에이전트와 동일 역할)
 *
 * 특징:
 * - {@link #id()} = {@code report-optimizer} (Evaluator와 짝을 이루는 식별자)
 *
 * 입력:
 * - 현재 보고서: {@link WorkflowContext#getCurrentReport()}
 * - 직전 평가: {@link WorkflowContext#getLastEvaluation()}
 *
 * 출력은 {@link WorkflowContext#setCurrentReport(String)}에 반영됩니다.
 */
@Component
@RequiredArgsConstructor
public class OptimizationNode implements WorkflowNode {

    /** Chapter 4 {@link ReportOptimizerSubagent}에 대응하는 노드 id */
    private static final String NODE_ID_REPORT_OPTIMIZER = "report-optimizer";

    /** 보고서 개선 전용 서브에이전트 래퍼 */
    private final ReportOptimizerSubagent reportOptimizerSubagent;

    @Override
    public String id() {
        return NODE_ID_REPORT_OPTIMIZER;
    }

    /**
     * execute
     *
     * 📌 직전 평가 피드백을 반영해 현재 보고서를 개선합니다.
     *
     * 동작:
     * - {@link WorkflowContext#getCurrentReport()}와 {@link WorkflowContext#getLastEvaluation()}를
     *   {@link ReportOptimizerSubagent#optimize(String, String)}에 전달해 개선된 보고서를 생성합니다.
     * - 결과를 {@link WorkflowContext#setCurrentReport(String)}에 저장하고, 성공 시 {@link NodeResult#ok(String)}로 반환합니다.
     *
     * @param ctx      현재 워크플로 컨텍스트
     * @param executor 실행에 사용할 스레드 풀
     * @return         개선된 보고서 내용을 담은 {@link NodeResult}
     */
    @Override
    public CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            int round = ctx.getEvaluationRound();
            ctx.publish("OPTIMIZING", round + "차 피드백 반영 중...");
            try {
                String updated = reportOptimizerSubagent.optimize(ctx.getCurrentReport(), ctx.getLastEvaluation());
                ctx.setCurrentReport(updated);
                return NodeResult.ok(updated);
            } catch (Exception e) {
                return NodeResult.fail("보고서 개선 실패: " + e.getMessage());
            }
        }, executor);
    }
}
