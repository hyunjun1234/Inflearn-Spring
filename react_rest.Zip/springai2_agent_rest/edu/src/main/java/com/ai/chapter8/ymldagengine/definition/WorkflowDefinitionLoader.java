package com.ai.chapter8.ymldagengine.definition;

/**
 * YAML 등에서 로딩한 {@link WorkflowDefinition}을 제공하는 로더 인터페이스.
 * Chapter 8/9에서 서로 다른 classpath 경로·검증 정책을 적용할 때 구현체를 바꿔 끼웁니다.
 */
public interface WorkflowDefinitionLoader {

    /**
     * @param workflowDefinitionId 확장자 없는 YAML 파일 식별자 (예: {@code strategic-analysis})
     * @return 파싱된 정의, 실패 시 {@code null}
     */
    WorkflowDefinition load(String workflowDefinitionId);
}
