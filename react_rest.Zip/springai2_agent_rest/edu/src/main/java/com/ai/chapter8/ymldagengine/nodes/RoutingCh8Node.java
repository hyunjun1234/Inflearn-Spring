package com.ai.chapter8.ymldagengine.nodes;

import com.ai.chapter8.ymldagengine.runtime.NodeResult;
import com.ai.chapter8.ymldagengine.runtime.WorkflowContext;
import com.ai.chapter8.ymldagengine.runtime.WorkflowNode;
import com.ai.shared.agent.api.SubAgentRegistry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;

/**
 * Chapter 8 YAML DAG — 라우팅 노드 (ch7 {@code RouterNode}와 동일 역할, id 만 {@code routing-ch8}).
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class RoutingCh8Node implements WorkflowNode {

    private static final String NODE_ID = "routing-ch8";
    private static final String AGENT_ROUTING = "routing";

    private final Map<String, String> routingCategoryCache = new ConcurrentHashMap<>();
    private final SubAgentRegistry subAgentRegistry;

    @Override
    public String id() {
        return NODE_ID;
    }

    @Override
    public CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            ctx.publish("ROUTING", "요청 라우팅 분석 중...");
            try {
                String userInput = ctx.getUserInput();
                String cacheKey = userInput == null ? "" : userInput.trim();
                String category;
                String cached = routingCategoryCache.get(cacheKey);
                if (cached != null) {
                    category = cached;
                    log.info("[{}] Routing 캐시 히트: {}", ctx.getWorkflowId(), category);
                } else {
                    String routingRaw = subAgentRegistry.require(AGENT_ROUTING).execute(userInput);
                    category = resolveRoutingCategory(routingRaw);
                    routingCategoryCache.put(cacheKey, category);
                }
                ctx.setRouteCategory(category);
                return NodeResult.ok(category);
            } catch (Exception e) {
                return NodeResult.fail("Routing 실패: " + e.getMessage());
            }
        }, executor);
    }

    private String resolveRoutingCategory(String raw) {
        String upper = raw == null ? "" : raw.toUpperCase();
        if (upper.contains("SIMPLE") && !upper.contains("STRATEGIC")) {
            return "SIMPLE";
        }
        if (upper.contains("STRATEGIC")) {
            return "STRATEGIC";
        }
        return "STRATEGIC";
    }
}
