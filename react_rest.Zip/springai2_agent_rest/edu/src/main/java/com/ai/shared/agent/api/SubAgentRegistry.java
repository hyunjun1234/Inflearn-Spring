package com.ai.shared.agent.api;

import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * SubAgentRegistry
 *
 * 📌 애플리케이션에 등록된 모든 {@link SubAgent} 빈을 이름 → 인스턴스 맵으로 보관
 *
 */
@Component
public class SubAgentRegistry {

    private final Map<String, SubAgent> byName;

    /**
     * Spring이 주입한 모든 {@link SubAgent} 목록으로 맵을 구성한다.
     */
    public SubAgentRegistry(List<SubAgent> agents) {
        this.byName = agents.stream()
                .collect(Collectors.toUnmodifiableMap(
                        SubAgent::name,
                        Function.identity(),
                        (a, b) -> {
                            throw new IllegalStateException(
                                    "중복된 Sub-Agent 이름: " + a.name());
                        }));
    }

    /**
     * 이름에 해당하는 서브에이전트를 반환한다. 없으면 예외.
     *
     * @param name {@link SubAgent#name()} 과 동일한 키 (예: {@code "routing"}, {@code "technical-analysis"})
     */
    public SubAgent require(String name) {
        SubAgent agent = byName.get(name);
        if (agent == null) {
            throw new IllegalArgumentException(
                    "등록되지 않은 Sub-Agent: " + name + ", 등록된 이름=" + byName.keySet());
        }
        return agent;
    }
}

