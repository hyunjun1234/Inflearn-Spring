package com.ai.chapter8.ymldagengine.runtime;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * WorkflowNode (ch8)
 *
 * 📌 Chapter 8 — YAML 엔진에서 사용하는 노드 인터페이스
 */
public interface WorkflowNode {

    /**
     * id
     *
     * 📌 YAML {@code handler} 필드와 매핑되는 노드 식별자입니다.
     *
     * <p>Chapter 8 예제 노드는 {@code routing-ch8}, {@code simple-query-ch8} 처럼
     * {@code -ch8} 접미를 두어 Chapter 7 코드 DAG 노드와 구분합니다.</p>
     *
     * @return 노드 식별자 문자열
     */
    String id();

    /**
     * execute
     *
     * 📌 주어진 {@link WorkflowContext}와 {@link Executor}를 사용해 노드를 비동기로 실행합니다.
     *
     * @param ctx      YAML DAG 실행 컨텍스트
     * @param executor 노드 실행에 사용할 스레드 풀
     * @return         실행 성공/실패/스킵 여부를 담은 {@link NodeResult}
     */
    CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor);
}

