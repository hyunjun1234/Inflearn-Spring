package com.ai.chapter8.ymldagengine.definition;

import java.util.List;
import java.util.Map;

/**
 * WorkflowDefinition
 *
 * 📌 Chapter 8 — YAML로 정의된 워크플로를 담는 단순 DTO
 */
public record WorkflowDefinition(
        String id,
        String description,
        List<NodeDefinition> nodes
) {

    public record NodeDefinition(
            String id,
            String type,
            String handler,
            List<String> dependsOn,
            String when,
            Map<String, String> outputs,
            Map<String, Object> config
    ) {}
}

