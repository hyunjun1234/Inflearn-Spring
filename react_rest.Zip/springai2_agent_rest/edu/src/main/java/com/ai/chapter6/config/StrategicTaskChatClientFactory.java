package com.ai.chapter6.config;

import com.ai.shared.publisher.WorkflowStatusPublisher;
import lombok.extern.slf4j.Slf4j;
import org.springaicommunity.agent.tools.TodoWriteTool;
import org.springaicommunity.agent.tools.task.TaskTool;
import org.springaicommunity.agent.tools.task.repository.DefaultTaskRepository;
import org.springaicommunity.agent.tools.task.subagent.SubagentReference;
import org.springaicommunity.agent.tools.task.subagent.claude.ClaudeSubagentDefinition;
import org.springaicommunity.agent.tools.task.subagent.claude.ClaudeSubagentExecutor;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.ToolCallAdvisor;
import org.springframework.ai.google.genai.GoogleGenAiChatModel;
import org.springframework.ai.ollama.OllamaChatModel;
import org.springframework.ai.openai.OpenAiChatModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * TaskTool·TodoWrite·멀티 모델 매핑을 묶어 전략 분석용 {@link ChatClient}를 만드는 팩토리.
 *
 * <p>{@link StrategicAnalysisAgentConfig}와 {@link StrategicAnalysisAgentMDConfig}가
 * 서브에이전트 목록·TaskTool 조립·Todo Redis 발행 로직을 중복하지 않도록 한곳에 둡니다.
 */
@Slf4j
public final class StrategicTaskChatClientFactory {

    /**
     * TaskTool에 등록할 서브에이전트 Markdown (파일명 strategic-*.md, frontmatter {@code name}은 SubAgent registry 키).
     *
     * <p>외부화 시 이 상수 대신 YML의 리스트(경로·kind)를 읽어 동일한 {@link SubagentReference} 목록을 구성하면 됨.
     */
    public static final List<SubagentReference> STRATEGIC_SUBAGENTS = List.of(
            new SubagentReference("classpath:chapter6/agents/strategic/strategic-router.md", ClaudeSubagentDefinition.KIND, null),
            new SubagentReference("classpath:chapter6/agents/strategic/strategic-simple.md", ClaudeSubagentDefinition.KIND, null),
            new SubagentReference("classpath:chapter6/agents/strategic/strategic-tech.md", ClaudeSubagentDefinition.KIND, null),
            new SubagentReference("classpath:chapter6/agents/strategic/strategic-market.md", ClaudeSubagentDefinition.KIND, null),
            new SubagentReference("classpath:chapter6/agents/strategic/strategic-evaluator.md", ClaudeSubagentDefinition.KIND, null),
            new SubagentReference("classpath:chapter6/agents/strategic/strategic-optimizer.md", ClaudeSubagentDefinition.KIND, null));

    private StrategicTaskChatClientFactory() {
    }

    /**
     * 서브에이전트 .md에서 쓸 수 있는 모델 별칭 → {@link ChatClient.Builder} (gpt/llama/gemini 및 default/cheap/heavy).
     *
     * <p>별칭 문자열은 YML로 옮기기 쉬우나, {@link ChatClient.Builder} 조립은 주입된 모델 빈이 필요하므로 이 메서드 본문은 코드에 유지하는 것이 일반적임.
     */
    public static Map<String, ChatClient.Builder> strategicModelBuilders(
            OpenAiChatModel openAiChatModel,
            OllamaChatModel ollamaChatModel,
            GoogleGenAiChatModel googleGenAiChatModel) {
        return Map.of(
                "gpt", ChatClient.builder(openAiChatModel),
                "llama", ChatClient.builder(ollamaChatModel),
                "gemini", ChatClient.builder(googleGenAiChatModel),
                "default", ChatClient.builder(openAiChatModel),
                "cheap", ChatClient.builder(ollamaChatModel),
                "heavy", ChatClient.builder(googleGenAiChatModel));
    }

    /**
     * TaskTool·TodoWrite·Advisor가 붙은 전략 분석용 {@link ChatClient}를 생성합니다.
     *
     * @param todoPublishStage Redis/SSE 단계 태그 (예: {@code AGENT_TODO}, {@code AGENT_TODO_MD}). 프로필별 YML로 주입 가능.
     */
    public static ChatClient buildStrategicTaskChatClient(
            OpenAiChatModel openAiChatModel,
            OllamaChatModel ollamaChatModel,
            GoogleGenAiChatModel googleGenAiChatModel,
            WorkflowStatusPublisher statusPublisher,
            Supplier<UUID> workflowIdSupplier,
            String systemPrompt,
            String todoPublishStage) {

        Map<String, ChatClient.Builder> modelBuilders =
                strategicModelBuilders(openAiChatModel, ollamaChatModel, googleGenAiChatModel);

        var taskTool = TaskTool.builder()
                .subagentReferences(STRATEGIC_SUBAGENTS)
                .subagentExecutors(new ClaudeSubagentExecutor(modelBuilders, List.of()))
                .taskRepository(new DefaultTaskRepository())
                .build();

        var todoTool = TodoWriteTool.builder()
                .todoEventHandler(todos -> {
                    // Chapter 6 HTTP 진입(StrategicAnalysisAgentToolTaskService)이 실행 전에
                    // StrategicWorkflowContext.setWorkflowId(workflowId)로 넣어 둔 값을 읽는다.
                    // TodoWriteTool 콜백은 workflowId를 파라미터로 받을 수 없으므로, 주 경로 strategicAnalysisAgent 빈은
                    // workflowIdSupplier 로 StrategicWorkflowContext::getWorkflowId 를 넘긴다.
                    // (MD 예제 빈은 별도 Supplier를 쓸 수 있음.)
                    UUID workflowId = workflowIdSupplier.get();
                    if (workflowId == null) {
                        return;
                    }
                    try {
                        for (String message : simpleTodoStatusLines(todos)) {
                            statusPublisher.publishStatus(workflowId, todoPublishStage, message);
                        }
                    } catch (Exception ex) {
                        log.warn("[{}] Todo 상태 발행 실패 ({})", workflowId, todoPublishStage, ex);
                    }
                })
                .build();

        return ChatClient.builder(openAiChatModel)
                .defaultSystem(systemPrompt)
                .defaultTools(todoTool)
                .defaultToolCallbacks(taskTool)
                .defaultAdvisors(ToolCallAdvisor.builder().build())
                .build();
    }

    /** Todo 스냅샷 UI/Redis용 한글 줄 생성 — 도메인 규칙이므로 YML 분리는 비권장. */
    private static List<String> simpleTodoStatusLines(TodoWriteTool.Todos todos) {
        List<TodoWriteTool.Todos.TodoItem> items = todos.todos();
        if (items == null || items.isEmpty()) {
            return List.of("할 일 없음");
        }
        List<String> lines = new ArrayList<>(items.size() + 1);
        lines.add("할 일 " + items.size() + "개");
        for (int i = 0; i < items.size(); i++) {
            TodoWriteTool.Todos.TodoItem item = items.get(i);
            String content = item.content() == null ? "" : item.content().trim();
            lines.add((i + 1) + ". " + statusKo(item.status()) + " — " + contentKo(content));
        }
        return lines;
    }

    /**
     * Todo 상태 코드 값을 한글 상태 문자열로 변환합니다.
     *
     * 매핑:
     * - {@code pending}     → "대기"
     * - {@code in_progress} → "진행 중"
     * - {@code completed}   → "완료"
     * - 그 외/알 수 없는 값 → {@link Enum#name()} 그대로 사용
     */
    private static String statusKo(TodoWriteTool.Todos.Status status) {
        if (status == null) {
            return "알 수 없음";
        }
        if (status == TodoWriteTool.Todos.Status.pending) {
            return "대기";
        }
        if (status == TodoWriteTool.Todos.Status.in_progress) {
            return "진행 중";
        }
        if (status == TodoWriteTool.Todos.Status.completed) {
            return "완료";
        }
        return status.name();
    }

    /**
     * TodoWriteTool 의 원문 content 를 간단한 한글 설명으로 매핑합니다.
     *
     * <p>전략 분석 도메인에 맞는 몇 가지 패턴을 하드코딩해 두었으며,
     *   매칭되지 않는 경우 원문을 그대로 반환합니다.</p>
     *
     * @param content Todo 항목 원문 content
     * @return        UI/Redis에 표시할 한글 설명 문자열
     */
    private static String contentKo(String content) {
        String c = content.toLowerCase();

        if (c.contains("classify")
                && ((c.contains("simple") || c.contains("strategic")))) {
            return "routing으로 사용자 요청을 SIMPLE/STRATEGIC으로 분류";
        }
        if ((c.contains("perform") || c.contains("do"))
                && c.contains("technical")
                && c.contains("analysis")) {
            return "STRATEGIC이면 technical-analysis 수행";
        }
        if ((c.contains("perform") || c.contains("do"))
                && c.contains("market")
                && c.contains("analysis")) {
            return "STRATEGIC이면 market-analysis 수행";
        }
        if (c.contains("integrate") && (c.contains("draft") || c.contains("report"))) {
            return "기술/시장 분석 결과를 하나의 초안 보고서로 통합";
        }
        if (c.contains("evaluate") && (c.contains("draft") || c.contains("report"))) {
            return "report-evaluator로 초안 보고서 평가";
        }
        if (c.contains("optimize") && c.contains("draft")) {
            return "report-optimizer로 보고서 개선";
        }
        if (c.contains("does not pass") || c.contains("fails")) {
            return "평가 미통과 시 report-optimizer로 보고서 개선";
        }

        if ((c.contains("routing") || c.contains("strategic-router")) && c.contains("classify")) {
            return "routing으로 사용자 요청을 SIMPLE/STRATEGIC으로 분류";
        }
        if (c.contains("if simple")
                && (c.contains("simple-query") || c.contains("strategic-simple"))) {
            return "SIMPLE이면 같은 요청으로 simple-query 응답";
        }
        if (c.contains("if strategic")
                && ((c.contains("technical-analysis") && c.contains("market-analysis"))
                || (c.contains("strategic-tech") && c.contains("strategic-market")))) {
            return "STRATEGIC이면 technical-analysis와 market-analysis로 분석";
        }
        if ((c.contains("combine") || c.contains("merge")) && c.contains("draft")) {
            return "기술/시장 분석 결과를 하나의 초안 보고서로 통합";
        }
        if (c.contains("evaluate")
                && (c.contains("report-evaluator") || c.contains("strategic-evaluator"))) {
            return "report-evaluator로 초안 보고서 평가";
        }
        if (c.contains("evaluation passes") || (c.contains("passes") && c.contains("final report"))) {
            return "평가 통과 시 최종 보고서를 사용자에게 전달";
        }
        if ((c.contains("does not pass") || c.contains("fails"))
                && (c.contains("report-optimizer") || c.contains("strategic-optimizer"))) {
            return "평가 미통과 시 report-optimizer로 보고서 개선";
        }
        if (c.contains("repeat") && c.contains("up to 4")) {
            return "평가와 개선을 최대 4회 반복";
        }
        return content;
    }
}
