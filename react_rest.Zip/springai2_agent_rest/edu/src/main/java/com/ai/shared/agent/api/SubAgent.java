package com.ai.shared.agent.api;

import com.ai.shared.agent.keys.StrategicAgentKeys;

/**
 * SubAgent
 *
 * 📌 Chapter 4 전략 분석 파이프라인의 “역할 단위” 추상화
 *
 * 계약:
 * - 각 구현체는 Spring 빈으로 등록되고 {@link SubAgentRegistry}에 이름으로 모입니다.
 * - {@link #name()} 은 레지스트리 키이며, {@link StrategicAgentKeys} 값과 반드시 일치해야 합니다.
 *
 * 실행:
 * - 단일 사용자 메시지를 받아 한 번의 LLM 호출로 응답 문자열을 반환합니다.
 * - 예외는 호출 측(오케스트레이션 서비스)에서 처리합니다.
 */
public interface SubAgent {

    /**
     * Sub-Agent 이름
     *
     * 역할:
     * - {@link SubAgentRegistry#require(String)} 조회 키
     * - 로그 / 모니터링 식별자
     */
    String name();

    /**
     * Sub-Agent 역할 설명
     *
     * 역할:
     * - 문서화·프롬프트 설계 참고용 (선택)
     */
    String description();

    /**
     * 단일 user 메시지로 LLM을 한 번 호출한다.
     *
     * @param userMessage 사용자 원문 또는 이전 단계에서 넘긴 본문(예: 초안 보고서)
     * @return 모델 응답 본문
     */
    String execute(String userMessage);

    /**
     * 단일 user 메시지 + system 메시지를 받아 LLM을 한 번 호출한다.
     *
     * 기본 구현은 {@link #execute(String)}을 그대로 호출하므로, 기존 구현체는 그대로 호환됩니다.
     *
     * @param userMessage 사용자 원문 또는 이전 단계에서 넘긴 본문(예: 초안 보고서)
     * @param systemMessage 실행 컨텍스트를 제어하는 system 프롬프트 (선택)
     * @return 모델 응답 본문
     */
    default String execute(String userMessage, String systemMessage) {
        return execute(userMessage);
    }
}

