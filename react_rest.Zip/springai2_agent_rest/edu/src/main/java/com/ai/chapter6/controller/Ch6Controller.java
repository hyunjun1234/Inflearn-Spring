package com.ai.chapter6.controller;

import com.ai.chapter6.service.StrategicAnalysisAgentToolTaskService;
import com.ai.shared.openapi.OpenApiExamples;
import com.ai.shared.web.ApiResponses;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

/**
 * Ch6Controller
 *
 * 📌 Chapter 6 — {@link StrategicAnalysisAgentToolTaskService} 노출용 REST API
 *
 * 역할:
 * - React 등 클라이언트에서 호출
 * - 브라우저는 동일 {@code workflowId}로 SSE({@code /api/workflow/stream/{workflowId}})를 연 뒤 본 API를 호출해
 *   TaskTool + TodoWrite 기반 Task-Orchestrated Multi-Agent 실행 상태를 실시간으로 확인합니다.
 *
 * 엔드포인트:
 * - {@code POST /ch6/strategic-analysis}
 *
 * 요청 (폼/urlencoded):
 * - {@code prompt}    — 사용자 질문
 * - {@code workflowId} — UUID 문자열 (SSE 구독과 반드시 동일)
 *
 * 응답:
 * - {@code text/plain} 문자열 — Task 기반 전략 분석의 최종 결과 또는 오류 메시지 (동기)
 */
@RestController
@RequestMapping("/ch6")
@Slf4j
@RequiredArgsConstructor
public class Ch6Controller {

    private final StrategicAnalysisAgentToolTaskService strategicAnalysisAgentToolTaskService;

    /**
     * strategic-analysis
     *
     * 📌 Chapter 6 Task-Orchestrated Multi-Agent 전략 분석 실행
     *
     * 처리 흐름(서비스 위임):
     *   - Java 오케스트레이터가 routing → 병렬 분석 → 평가/개선 루프를 제어하고,
     *     각 단계의 실제 생성 작업은 TaskTool 서브에이전트에 위임됩니다.
     *
     * @param userPrompt  사용자 입력
     * @param workflowId  SSE와 매칭되는 워크플로 UUID
     * @return 최종 문자열 응답
     */
    @PostMapping("/strategic-analysis")
    public ResponseEntity<String> strategicAnalysis(
            @Parameter(example = OpenApiExamples.PROMPT_STRATEGIC_UAM) @RequestParam("prompt") String userPrompt,
            @Parameter(example = OpenApiExamples.WORKFLOW_ID_UUID) @RequestParam String workflowId
    ) {
        UUID id = UUID.fromString(workflowId);
        log.info("Ch6 StrategicAnalysis(Task tool) request: {}", userPrompt);
        return ApiResponses.textPlainOk(strategicAnalysisAgentToolTaskService.executeWithMonitoring(id, userPrompt));
    }
}
