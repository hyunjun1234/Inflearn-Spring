package com.ai.chapter4.service;

import com.ai.shared.publisher.WorkflowStatusPublisher;
import com.ai.shared.util.EvaluationApprovalDecider;
import com.ai.shared.config.StrategicEvaluatorProperties;
import com.ai.shared.agent.api.SubAgentRegistry;
import com.ai.shared.agent.keys.StrategicAgentKeys;
import com.ai.shared.agent.subagent.ReportOptimizerSubagent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * StrategicAnalysisAgentOrchestrator
 *
 * 📌 Chapter 4 — 메인 오케스트레이터 ({@link SubAgentRegistry} + {@link StrategicAgentKeys} · Tool 층 없음)
 *
 * 아키텍처 개요:
 * 1️⃣ Router — {@link StrategicAgentKeys#ROUTING} → SIMPLE / STRATEGIC
 * 2️⃣ SIMPLE — {@link StrategicAgentKeys#SIMPLE_QUERY} 단일 응답 후 종료
 * 3️⃣ STRATEGIC — 기술·시장 병렬 분석 → Evaluator-Optimizer 루프(최대 4회)
 *
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class StrategicAnalysisAgentOrchestrator {

    private final SubAgentRegistry subAgentRegistry;

    /**
     * 📡 WorkflowStatusPublisher
     *
     * 역할:
     * - Redis로 SSE 단계 메시지 발행
     */
    private final WorkflowStatusPublisher statusPublisher;

    /**
     * ⚙️ StrategicEvaluatorProperties
     *
     * 역할:
     * - 보고서 승인 임계점수({@code strategic.evaluator.approval-threshold}) 읽기
     */
    private final StrategicEvaluatorProperties evaluatorProperties;

    /**
     * 🧵 병렬 분석 전용 스레드 풀 ({@link Executors#newFixedThreadPool(int)} — 크기 4).
     *
     * <p><b>사용 이유</b>
     * <ul>
     *   <li>기술/시장 등 병렬 LLM 호출 시 공용 {@link java.util.concurrent.ForkJoinPool#commonPool()}에 부담을 주지 않고,
     *       I/O 블로킹이 있는 작업의 <strong>동시 실행 개수를 고정</strong>한다.</li>
     *   <li>싱글톤 서비스에서 공유되면 <strong>모든 HTTP 요청이 동일 풀을 사용</strong>한다.</li>
     * </ul>
     *
     * <p><b>부하·확장</b>: 동시에 처리할 수 있는 양은 코드와 인프라에서 함께 정하고, 넘치면
     * 거절·대기·수평 확장(인스턴스 증설) 등으로 다루는 것이 일반적이다.
     * 이 고정 풀은 <strong>애플리케이션 내부 병렬 단계의 동시 실행 상한</strong>만 나타내며,
     * 큐 적체 방지·전역 동시 요청 제한·타임아웃 등은 별도 설계가 필요할 수 있다.
     */
    private final ExecutorService analysisExecutor = Executors.newFixedThreadPool(4);

    /** 사용자 입력(trim) → SIMPLE / STRATEGIC — ROUTING SubAgent 재호출 생략 */
    private final Map<String, String> routingCategoryCache = new ConcurrentHashMap<>();

    /**
     * executeWithMonitoring
     *
     * 📌 전략 분석 전체 파이프라인 실행 (workflowId 단위 추적)
     *
     * @param workflowId SSE·Redis와 매칭되는 UUID
     * @param input      사용자 입력
     * @return           최종 보고서 문자열 또는 단계별 오류 메시지
     */
    public String executeWithMonitoring(UUID workflowId, String input) {

        // =================================================
        // 🟡 1️⃣ Routing 단계
        // =================================================

        publishStatus(workflowId, "ROUTING", "질문 카테고리를 분석 중...");

        String category;
        String cacheKey = input == null ? "" : input.trim();

        try {
            String cached = routingCategoryCache.get(cacheKey);
            if (cached != null) {
                category = cached;
                log.info("[{}] Routing 캐시 히트: {}", workflowId, category);
            } else {
                String routingRaw = subAgentRegistry.require(StrategicAgentKeys.ROUTING).execute(input);
                category = resolveRoutingCategory(routingRaw);
                routingCategoryCache.put(cacheKey, category);
                log.info("[{}] Routing 결과: {}", workflowId, category);
            }

        } catch (Exception e) {
            log.error("[{}] Routing 실패: {}", workflowId, e.getMessage(), e);
            publishStatus(workflowId, "ERROR", "Routing 단계 실패");

            return "Routing 단계 실패";
        }

        if ("SIMPLE".equalsIgnoreCase(category)) {
            try {
                String result = subAgentRegistry.require(StrategicAgentKeys.SIMPLE_QUERY).execute(input);

                publishStatus(workflowId, "COMPLETED", "단순 요청 처리 완료");
                return result;

            } catch (Exception e) {
                log.error("[{}] SIMPLE 처리 실패", workflowId, e);
                publishStatus(workflowId, "ERROR", "단순 요청 처리 실패");
                return "단순 요청 처리 실패";
            }
        }

        // =================================================
        // 🔵 2️⃣ Parallel Analysis 단계
        // =================================================

        publishStatus(workflowId, "ANALYZING", "기술 및 시장 데이터를 동시에 분석 중...");
        log.info("[{}] Parallel 분석 시작", workflowId);

        CompletableFuture<String> techFuture =
                CompletableFuture.supplyAsync(() -> {
                    try {
                        return subAgentRegistry.require(StrategicAgentKeys.TECHNICAL_ANALYSIS).execute(input);
                    } catch (Exception e) {
                        log.error("[{}] 기술 분석 실패", workflowId, e);
                        return "기술 분석 실패";
                    }
                }, analysisExecutor);

        CompletableFuture<String> marketFuture =
                CompletableFuture.supplyAsync(() -> {
                    try {
                        return subAgentRegistry.require(StrategicAgentKeys.MARKET_ANALYSIS).execute(input);
                    } catch (Exception e) {
                        log.error("[{}] 시장 분석 실패", workflowId, e);
                        return "시장 분석 실패";
                    }
                }, analysisExecutor);

        String rawReport;

        try {
            rawReport = techFuture
                    .thenCombine(marketFuture,
                            (tech, market) -> "기술분석: " + tech + "\n시장분석: " + market)
                    .join();

            log.info("[{}] Parallel 분석 완료", workflowId);

        } catch (Exception e) {
            log.error("[{}] Parallel 처리 실패", workflowId, e);
            publishStatus(workflowId, "ERROR", "Parallel 분석 실패");
            return "병렬 분석 실패";
        }

        // =================================================
        // 🟣 3️⃣ Evaluator-Optimizer Loop
        // =================================================

        String finalReport = rawReport;

        for (int i = 1; i <= 4; i++) {

            publishStatus(workflowId, "EVALUATING", i + "차 검토 중...");
            log.info("[{}] Draft #{} 평가 시작", workflowId, i);

            String evaluation;

            try {
                evaluation = subAgentRegistry.require(StrategicAgentKeys.REPORT_EVALUATOR).execute(finalReport);

            } catch (Exception e) {
                log.error("[{}] 평가 실패", workflowId, e);
                publishStatus(workflowId, "ERROR", "평가 실패");
                break;
            }

            Integer score = EvaluationApprovalDecider.extractScore(evaluation);
            if (score != null) {
                publishStatus(workflowId, "EVALUATION_SCORE", i + "차 평가 점수: " + score + "점");
            } else {
                publishStatus(workflowId, "EVALUATION_SCORE", i + "차 평가 점수: 추출 실패");
            }

            if (shouldApproveEvaluation(evaluation)) {
                publishStatus(workflowId, "COMPLETED", "최종 승인 완료");
                log.info("[{}] Draft #{} 승인 완료", workflowId, i);
                break;
            }

            publishStatus(workflowId, "OPTIMIZING", "보고서 수정 중...");

            try {
                finalReport = subAgentRegistry.require(StrategicAgentKeys.REPORT_OPTIMIZER).execute(
                        ReportOptimizerSubagent.combinedUserMessageForRegistry(finalReport, evaluation));

            } catch (Exception e) {
                log.error("[{}] 수정 실패", workflowId, e);
                publishStatus(workflowId, "ERROR", "보고서 수정 실패");
                break;
            }
        }

        return finalReport;
    }

    /**
     * publishStatus
     *
     * 📌 ch4 오케스트레이터 내부에서 공통으로 사용하는 상태 발행 메서드입니다.
     *
     * 기능:
     * - 현재 단계(step)와 메시지를 {@link WorkflowStatusPublisher}를 통해 Redis Pub/Sub으로 내보냅니다.
     * - 상태 발행 실패가 <b>파이프라인 자체 실패로 간주되지 않도록</b> 예외를 catch 하고 경고 로그만 남깁니다.
     *
     * @param workflowId 워크플로우 추적용 UUID
     * @param step       예: {@code ROUTING}, {@code ANALYZING}, {@code EVALUATING}, {@code OPTIMIZING}, {@code COMPLETED}, {@code ERROR}
     * @param message    UI·운영자용 설명 메시지
     */
    private void publishStatus(UUID workflowId, String step, String message) {
        try {
            statusPublisher.publishStatus(workflowId, step, message);
        } catch (Exception ex) {
            log.warn("[{}] 상태 발행 실패", workflowId, ex);
        }
    }

    /**
     * 라우팅 SubAgent 원문을 SIMPLE / STRATEGIC으로 정규화 (ch5 {@code RoutingTool} 이후와 동일 규칙).
     */
    private String resolveRoutingCategory(String raw) {
        if (raw == null || raw.isBlank()) {
            return "SIMPLE";
        }
        String upper = raw.toUpperCase();
        if (upper.contains("SIMPLE") && !upper.contains("STRATEGIC")) {
            return "SIMPLE";
        }
        if (upper.contains("STRATEGIC")) {
            return "STRATEGIC";
        }
        return "STRATEGIC";
    }

    /**
     * shouldApproveEvaluation
     *
     * 📌 Evaluator SubAgent가 생성한 평가 텍스트와 설정값을 기반으로 “승인/재시도” 여부를 판단합니다.
     *
     * 규칙:
     * - {@link EvaluationApprovalDecider#shouldApprove(String, Integer)}에 현재 평가 텍스트와
     *   {@link StrategicEvaluatorProperties#getApprovalThreshold()}에서 읽은 임계 점수를 넘겨 위임합니다.
     * - 점수 파싱 실패·임계값 미설정 등의 디테일은 {@link EvaluationApprovalDecider} 쪽 구현 규칙을 따릅니다.
     *
     * @param evaluationText 보고서 평가 결과 원문 (점수·코멘트 포함 문자열)
     * @return               승인해야 하면 {@code true}, 재평가/수정이 필요하면 {@code false}
     */
    private boolean shouldApproveEvaluation(String evaluationText) {
        return EvaluationApprovalDecider.shouldApprove(
                evaluationText,
                evaluatorProperties.getApprovalThreshold());
    }

    /**
     * shutdownExecutor
     *
     * 📌 애플리케이션 종료 시 병렬 분석용 {@link ExecutorService}를 정리(shutdown)합니다.
     *
     * 특징:
     * - {@link PreDestroy} 훅에서 호출되어 더 이상 새로운 작업을 받지 않도록 하고,
     *   백그라운드 스레드 누수 없이 안전하게 종료되도록 합니다.
     */
    @PreDestroy
    public void shutdownExecutor() {
        analysisExecutor.shutdown();
    }
}
