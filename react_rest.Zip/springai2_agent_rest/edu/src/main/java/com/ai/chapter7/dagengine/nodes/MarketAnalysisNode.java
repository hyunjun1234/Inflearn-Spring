package com.ai.chapter7.dagengine.nodes;

import com.ai.shared.agent.api.SubAgentRegistry;
import com.ai.chapter7.dagengine.core.NodeResult;
import com.ai.chapter7.dagengine.core.WorkflowContext;
import com.ai.chapter7.dagengine.core.WorkflowNode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * MarketAnalysisNode
 *
 * 📌 STRATEGIC 경로 — 시장 관점 분석 (레지스트리 키 {@code market-analysis})
 *
 * 아키텍처 개요:
 * 1️⃣ {@link TechnicalAnalysisNode}와 선행 의존 없음 → DAG에서 병렬 실행
 * 2️⃣ 결과는 {@link WorkflowContext#setMarketAnalysis(String)}
 *
 * 특징:
 * - 예외 시 플레이스홀더로 병렬 병합 단계가 실패하지 않도록 처리
 */
@Component
@RequiredArgsConstructor
public class MarketAnalysisNode implements WorkflowNode {

    private static final String AGENT_MARKET_ANALYSIS = "market-analysis";

    /** SubAgent 기반 시장 분석 */
    private final SubAgentRegistry subAgentRegistry;

    @Override
    public String id() {
        return AGENT_MARKET_ANALYSIS;
    }

    /**
     * execute
     *
     * 📌 STRATEGIC 경로에서 시장·트렌드 관점 분석을 수행하는 노드입니다.
     *
     * 동작:
     * - {@code market-analysis} 서브에이전트를 호출해 시장 분석 결과를 생성하고,
     *   {@link WorkflowContext#setMarketAnalysis(String)}에 저장합니다.
     * - 예외가 발생하면 "시장 분석 실패"라는 플레이스홀더를 저장하여
     *   병합 단계가 실패하지 않도록 합니다.
     *
     * @param ctx      현재 워크플로 컨텍스트
     * @param executor 실행에 사용할 스레드 풀
     * @return         시장 분석 결과 또는 실패 플레이스홀더를 담은 {@link NodeResult}
     */
    @Override
    public CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            ctx.publish("MARKET", "시장 관점 분석 중...");
            try {
                String market = subAgentRegistry.require(AGENT_MARKET_ANALYSIS).execute(ctx.getUserInput());
                ctx.setMarketAnalysis(market);
                return NodeResult.ok(market);
            } catch (Exception e) {
                ctx.setMarketAnalysis("시장 분석 실패");
                return NodeResult.ok("시장 분석 실패");
            }
        }, executor);
    }
}
