package com.ai.chapter5.tool;

import com.ai.chapter5.tool.api.StrategicTool;
import com.ai.shared.agent.api.SubAgentRegistry;
import com.ai.shared.agent.subagent.ReportOptimizerSubagent;
import com.ai.chapter5.tool.registry.ToolRegistry;
import org.springframework.stereotype.Component;

/**
 * ReportOptimizerTool
 *
 * 📌 Chapter 5 — 평가 피드백을 반영하여 전략 보고서 초안을 개선하는 StrategicTool.
 *
 * 역할:
 * - {@link ToolRegistry} 에 {@code "report-optimizer"} 이름으로 등록됩니다.
 * - {@link SubAgentRegistry} 를 통해
 *   같은 이름의 서브에이전트({@code strategic-optimizer.md})에 개선 작업을 위임합니다.
 * - 현재 초안과 평가 피드백을 하나의 프롬프트로 합쳐 전달하고,
 *   구조(예: 기술/시장 섹션)를 유지한 상태로 개정된 보고서를 생성하도록 유도합니다.
 */
@Component
public class ReportOptimizerTool implements StrategicTool {

    private final SubAgentRegistry subAgentRegistry;

        /**
         * ReportOptimizerTool
         *
         * 📌 평가 피드백을 반영해 보고서를 개선하는 Tool 인스턴스를 생성합니다.
         *
         * @param subAgentRegistry 보고서 개선 서브에이전트를 이름으로 조회하는 레지스트리
         */
    public ReportOptimizerTool(SubAgentRegistry subAgentRegistry) {
        this.subAgentRegistry = subAgentRegistry;
    }

    @Override
    public String name() {
        return "report-optimizer";
    }

    @Override
    public String description() {
        return "평가 피드백을 반영해 보고서 개선";
    }

    /**
     * 개선 지시를 도구에 두면 평가 피드백과 짝을 이루는 "개선 행동"이 한 클래스에 모이고,
     * {@link #execute(String, String)}에서 합쳐진 사용자 메시지와 항상 같은 시스템 맥락으로
     * SubAgent를 호출할 수 있습니다. 오케스트레이터는 초안·피드백 전달만 담당해 단순해집니다.
     */
    @Override
    public String systemMessage() {
        return """
                당신은 전략 보고서를 개선합니다. 현재 초안과 평가자 피드백을 받습니다. 원래 사용자 질문이 다른 언어가 아니라면 전체 개정안을 한국어로 작성하고, 기술분석·시장분석 구역이 있으면 구조를 유지합니다.
                """;
    }

        /**
         * execute (단일 인자)
         *
         * 📌 기본 구현에서는 사용되지 않으며, 호출 시 입력 보고서를 그대로 반환합니다.
         *
         * 이유:
         * - 본 Tool은 평가 피드백까지 함께 받아야 의미가 있으므로,
         *   실제 오케스트레이션에서는 항상 2인자 {@link #execute(String, String)}가 사용됩니다.
         *
         * @param report 현재 보고서 초안
         * @return       변경 없이 전달된 초안
         */
    @Override
    public String execute(String report) {
        return report;
    }

        /**
         * execute (report, feedback)
         *
         * 📌 보고서 초안과 평가 피드백을 하나의 사용자 메시지로 합쳐, 개선 전용 서브에이전트에 위임합니다.
         *
         * 동작:
         * - {@link ReportOptimizerSubagent#combinedUserMessageForRegistry(String, String)}로
         *   초안과 피드백을 합친 뒤,
         * - {@link SubAgentRegistry}에서 {@code "report-optimizer"} 서브에이전트를 조회해
         *   {@link #systemMessage()}와 함께 호출합니다.
         *
         * @param report   현재 전략 보고서 초안
         * @param feedback 평가 도구가 반환한 피드백/지적사항 텍스트
         * @return         개선이 반영된 새로운 보고서 텍스트
         */
    @Override
    public String execute(String report, String feedback) {
        return subAgentRegistry.require(name()).execute(
                ReportOptimizerSubagent.combinedUserMessageForRegistry(report, feedback),
                systemMessage());
    }

}
