package com.ai.chapter3.controller;

import com.ai.chapter3.service.AutoPatternRoutingService;
import com.ai.chapter3.service.PrecisionExecutionService;
import com.ai.chapter3.service.StrategicAnalysisService;
import com.ai.chapter3.service.VotingAnalysisService;
import com.ai.shared.openapi.OpenApiExamples;
import com.ai.shared.web.ApiResponses;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

/**
 * Chapter 3 Controller
 *
 * AI 분석 관련 API를 제공하는 REST Controller
 *
 * 주요 기능:
 * 1. Precision Execution (정밀 실행 분석)
 * 2. Strategic Analysis (전략 분석)
 * 3. Voting Analysis (투표 기반 분석)
 * 4. Auto Pattern Routing (질문에 맞는 패턴 자동 선택 후 위임)
 *
 * 공통 특징:
 * - workflowId(UUID)를 기준으로 대화/작업 흐름을 관리
 * - Zero-Shot Prompting 기반 요청 처리
 */
@RestController                     // REST API Controller 선언
@RequestMapping("/ch3")             // 기본 URL 경로 설정
@Slf4j                              // Lombok 로깅 객체 자동 생성
@RequiredArgsConstructor            // final 필드에 대한 생성자 자동 주입
public class Ch3Controller {

    /**
     * 정밀 실행 분석 서비스
     * - 프롬프트 기반 실행 결과 생성
     * - 모니터링 기능 포함
     */
    private final PrecisionExecutionService precisionExecutionService;

    /**
     * 전략 분석 서비스
     * - 입력 프롬프트 기반 전략적 사고 분석 수행
     */
    private final StrategicAnalysisService strategicAnalysisService;

    /**
     * 투표 기반 분석 서비스
     * - 여러 의견/결과를 비교 후 최적 결과 도출
     */
    private final VotingAnalysisService votingAnalysisService;

    /**
     * Auto Pattern Routing — Strategic / Precision / Voting 중 자동 분류 후 실행
     */
    private final AutoPatternRoutingService autoPatternRoutingService;


    /**
     * 1️⃣ Precision Execution API
     *
     * Zero-Shot Prompting 기반 분석 수행
     *
     * @param userPrompt  사용자가 입력한 프롬프트
     * @param workflowId  작업 흐름 식별자 (UUID 문자열)
     * @return            AI 분석 결과 문자열
     */
    @PostMapping("/precision-execution")
    public ResponseEntity<String> precisionExecution(
            @RequestParam("prompt") String userPrompt,   // 사용자 입력 프롬프트
            @Parameter(example = OpenApiExamples.WORKFLOW_ID_UUID) @RequestParam String workflowId
    ) {

        // 1단계: workflowId 문자열을 UUID 객체로 변환
        UUID id = UUID.fromString(workflowId);

        // 2단계: 사용자 입력 로그 기록
        log.info("PrecisionExecution 요청: {}", userPrompt);

        // 3단계: 서비스 계층 호출 (모니터링 포함 실행)
        return ApiResponses.textPlainOk(precisionExecutionService.executeWithMonitoring(id, userPrompt));
    }


    /**
     * 2️⃣ Strategic Analysis API
     *
     * 전략적 사고 기반 분석 수행
     *
     * @param userPrompt  사용자 입력 프롬프트
     * @param workflowId  작업 흐름 식별자
     * @return            분석 결과 문자열
     */
    @PostMapping("/strategic-analysis")
    public ResponseEntity<String> strategicAnalysis(
            @RequestParam("prompt") String userPrompt,
            @Parameter(example = OpenApiExamples.WORKFLOW_ID_UUID) @RequestParam String workflowId
    ) {

        // 1단계: UUID 변환
        UUID id = UUID.fromString(workflowId);

        // 2단계: 로그 기록
        log.info("StrategicAnalysis 요청: {}", userPrompt);

        // 3단계: 전략 분석 서비스 호출
        return ApiResponses.textPlainOk(strategicAnalysisService.executeWithMonitoring(id, userPrompt));
    }


    /**
     * 3️⃣ Voting Analysis API
     *
     * 다중 응답 생성 후 투표 기반 최적 응답 도출
     *
     * @param userPrompt  사용자 입력 프롬프트
     * @param workflowId  작업 흐름 식별자
     * @return            최종 선택된 응답
     */
    @PostMapping("/voting-analysis")
    public ResponseEntity<String> votingAnalysis(
            @RequestParam("prompt") String userPrompt,
            @Parameter(example = OpenApiExamples.WORKFLOW_ID_UUID) @RequestParam String workflowId
    ) {

        // 1단계: UUID 변환
        UUID id = UUID.fromString(workflowId);

        // 2단계: 요청 로그 기록
        log.info("VotingAnalysis 요청: {}", userPrompt);

        // 3단계: 투표 기반 분석 서비스 호출
        return ApiResponses.textPlainOk(votingAnalysisService.executeWithMonitoring(id, userPrompt));
    }


    /**
     * 4️⃣ Auto Pattern Routing API
     *
     * LLaMA로 입력을 STRATEGIC / PRECISION / VOTING 으로 분류한 뒤 해당 서비스로 위임합니다.
     */
    @PostMapping("/auto-pattern-routing")
    public ResponseEntity<String> autoPatternRouting(
            @RequestParam("prompt") String userPrompt,
            @Parameter(example = OpenApiExamples.WORKFLOW_ID_UUID) @RequestParam String workflowId
    ) {
        UUID id = UUID.fromString(workflowId);
        log.info("AutoPatternRouting 요청: {}", userPrompt);
        return ApiResponses.textPlainOk(autoPatternRoutingService.executeWithMonitoring(id, userPrompt));
    }

}
