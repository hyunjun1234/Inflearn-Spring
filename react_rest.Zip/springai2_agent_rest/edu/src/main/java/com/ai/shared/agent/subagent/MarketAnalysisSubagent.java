package com.ai.shared.agent.subagent;

import com.ai.shared.agent.api.SubAgent;
import com.ai.shared.agent.keys.StrategicAgentKeys;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * MarketAnalysisSubagent
 *
 * 📌 STRATEGIC 경로에서 “시장/트렌드/Go-to-market 분석”을 담당하는 서브에이전트입니다.
 *
 * 개념:
 * - 기술 분석과 완전히 독립된 워커로, 수요, 경쟁, 트렌드, 진입 전략을 LLM에게 맡깁니다.
 * - ch4에서는 SubAgentRegistry, ch5에서는 Tool, ch6/7에서는 Task/DAG 노드에서
 *   동일한 레지스트리 키 {@code "market-analysis"} 로 이 역할을 사용합니다.
 * - 최종 보고서에서는 기술 분석 결과와 병합되어 하나의 전략 보고서를 구성합니다.
 *
 * 모델:
 * - {@link Qualifier @Qualifier("gemini")} — 시장 맥락 서술용 (프로젝트 설정에 따름)
 *
 * 레지스트리 키:
 * - {@code "market-analysis"}
 *
 * 실행:
 * - {@link TechnicalAnalysisSubagent}와 의존 관계가 없어 병렬 실행 가능
 */
@Component
public class MarketAnalysisSubagent implements SubAgent {

    private static final String SYSTEM = """
            당신은 시장 전략가입니다. 사용자 요청과 관련된 수요, 경쟁, 트렌드, 시장 진입(Go-to-market) 관점을 분석합니다. 사용자가 다른 언어로 쓰지 않았다면 한국어로 작성합니다.
            """;

    private final ChatClient geminiClient;

    /**
     * MarketAnalysisSubagent
     *
     * 📌 시장/트렌드 분석용 서브에이전트를 구성합니다.
     *
     * @param geminiClient 시장 맥락 분석을 담당하는 LLM 클라이언트
     */
    public MarketAnalysisSubagent(@Qualifier("gpt") ChatClient geminiClient) {
        this.geminiClient = geminiClient;
    }

    @Override
    public String name() {
        return StrategicAgentKeys.MARKET_ANALYSIS;
    }

    @Override
    public String description() {
        return "시장·트렌드 관점에서 요청 주제를 분석한다.";
    }

    @Override
    public String execute(String userMessage) {
        return execute(userMessage, null);
    }

    @Override
    public String execute(String userMessage, String systemMessage) {
        String sys = systemMessage == null ? "" : systemMessage.trim();
        String effectiveSystem = sys.isEmpty() ? SYSTEM : sys;
        return geminiClient.prompt()
                .system(effectiveSystem)
                .user(userMessage)
                .call()
                .content();
    }
}

