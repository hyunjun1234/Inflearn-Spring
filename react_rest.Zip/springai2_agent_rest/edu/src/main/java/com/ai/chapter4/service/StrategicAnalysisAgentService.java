package com.ai.chapter4.service;

import com.ai.shared.agent.api.SubAgent;
import com.ai.shared.agent.api.SubAgentRegistry;
import com.ai.shared.agent.keys.StrategicAgentKeys;
import com.ai.shared.publisher.WorkflowStatusPublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * StrategicAnalysisAgentService
 *
 * 📌 Chapter 4 — HTTP 진입·상태 래핑 전용 서비스 (전략 분석 Multi-Agent)
 *
 * 아키텍처 개요:
 * 1️⃣ 본 클래스 — STARTED/AGENT/COMPLETED/ERROR 발행
 * 2️⃣ {@link StrategicAnalysisAgentOrchestrator} — 라우팅 → (STRATEGIC 시) 병렬 분석 → 평가·개선 루프
 *
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class StrategicAnalysisAgentService {

    /**
     * 🧭 메인 오케스트레이터
     *
     * 역할:
     * - Routing / SIMPLE / 병렬 분석 / Evaluator-Optimizer 루프 실행
     */
    private final StrategicAnalysisAgentOrchestrator strategicAnalysisAgentOrchestrator;

    /**
     * 📡 WorkflowStatusPublisher
     *
     * 역할:
     * - Redis Pub/Sub으로 SSE 단계(STARTED, ROUTING, ANALYZING 등) 발행
     */
    private final WorkflowStatusPublisher statusPublisher;

    /**
     * executeWithMonitoring
     *
     * 📌 workflowId 기준으로 전략 분석 파이프라인을 실행하고 최종 문자열을 반환합니다.
     *
     * @param workflowId 클라이언트·SSE와 매칭되는 추적용 UUID
     * @param input      사용자 프롬프트
     * @return           최종 보고서 또는 오류 메시지
     */
    public String executeWithMonitoring(UUID workflowId, String input) {

        publishStatus(workflowId, "STARTED", "Workflow started.");
        try {
            publishStatus(workflowId, "AGENT", "Java code workflow running...");
            String result = strategicAnalysisAgentOrchestrator.executeWithMonitoring(workflowId, input);
            publishStatus(workflowId, "COMPLETED", "Workflow completed");
            return result;
        } catch (Exception e) {
            log.error("[{}] Agent failed: {}", workflowId, e.getMessage(), e);
            publishStatus(workflowId, "ERROR", "Agent failed");
            return "Agent failed: " + e.getMessage();
        }
    }

    /**
     * publishStatus
     *
     * 📌 ch4 에이전트 워크플로우의 상태를 Redis Pub/Sub으로 발행하는 헬퍼 메서드입니다.
     *
     * 기능:
     * - 현재 {@code workflowId}·단계(step)·메시지를 조합해 {@link WorkflowStatusPublisher}로 전달
     * - 발행 중 예외가 나더라도 워크플로우 본 처리는 계속 진행되도록 예외를 로깅 수준으로만 처리합니다.
     *
     * @param workflowId SSE 스트림과 매칭되는 워크플로우 식별자
     * @param step       예: {@code STARTED}, {@code AGENT}, {@code COMPLETED}, {@code ERROR}
     * @param message    UI·로그용 사람 친화적 설명 메시지
     */
    private void publishStatus(UUID workflowId, String step, String message) {
        try {
            statusPublisher.publishStatus(workflowId, step, message);
        } catch (Exception ex) {
            log.warn("[{}] Status publish failed", workflowId, ex);
        }
    }
}
