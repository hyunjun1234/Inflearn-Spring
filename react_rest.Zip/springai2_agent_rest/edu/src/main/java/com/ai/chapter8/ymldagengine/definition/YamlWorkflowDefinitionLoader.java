package com.ai.chapter8.ymldagengine.definition;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * YamlWorkflowDefinitionLoader
 *
 * 📌 Chapter 8 — classpath 의 YAML 파일에서 {@link WorkflowDefinition} 로딩/캐시
 *
 * 현재 구현:
 * - {@code workflowDefinitionId}.yml 파일을 {@code classpath:chapter8/dagworkflow/} 아래에서 찾음
 * - 1회 로딩 후 메모리 캐시(ConcurrentHashMap)에 저장
 */
@Component
@Qualifier("chapter8Loader")
@Slf4j
public class YamlWorkflowDefinitionLoader implements WorkflowDefinitionLoader {

    private final Map<String, WorkflowDefinition> cache = new ConcurrentHashMap<>();

    /**
     * workflowDefinitionId 로 YAML 워크플로 정의를 로딩하거나, 이미 있으면 캐시에서 반환합니다.
     *
     * @param workflowDefinitionId YAML 파일 이름에서 확장자를 제외한 id
     * @return                     파싱된 {@link WorkflowDefinition} 또는 실패 시 {@code null}
     */
    public WorkflowDefinition load(String workflowDefinitionId) {
        return cache.computeIfAbsent(workflowDefinitionId, this::loadInternal);
    }

    /**
     * 실제 classpath 리소스에서 YAML 파일을 읽어 {@link WorkflowDefinition} 으로 변환합니다.
     *
     * <p>오류 발생 시 로그를 남기고 {@code null} 을 반환합니다.</p>
     */
    private WorkflowDefinition loadInternal(String workflowDefinitionId) {
        String path = "chapter8/dagworkflow/" + workflowDefinitionId + ".yml";
        ClassPathResource resource = new ClassPathResource(path);
        if (!resource.exists()) {
            log.warn("YAML 워크플로 정의 파일을 찾을 수 없습니다: {}", path);
            return null;
        }
        try (InputStream is = resource.getInputStream()) {
            Yaml yaml = new Yaml();
            @SuppressWarnings("unchecked")
            Map<String, Object> raw = yaml.load(is);
            if (raw == null) {
                log.warn("YAML 워크플로 정의를 파싱했지만 내용이 비어 있습니다: {}", path);
                return null;
            }
            WorkflowDefinition def = WorkflowDefinitionMapper.fromRawMap(raw);
            log.info("YAML 워크플로 정의 로딩 완료: id={}, nodes={}",
                    def.id(), def.nodes() != null ? def.nodes().size() : 0);
            return def;
        } catch (Exception e) {
            log.error("YAML 워크플로 정의 로딩 실패: {}", path, e);
            return null;
        }
    }
}

