package com.ai.shared.agent.subagent;

import com.ai.shared.agent.api.SubAgent;
import com.ai.shared.agent.keys.StrategicAgentKeys;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * ReportOptimizerSubagent
 *
 * 📌 평가 피드백을 반영해 보고서 본문을 개선하는 Optimizer입니다.
 * <p>
 * {@link SubAgent}를 구현해 {@code SubAgentRegistry}에서 {@code report-optimizer} 키로 조회할 수 있고,
 * {@link #optimize(String, String)} 으로 초안+피드백을 직접 넘기는 경로(예: Chapter 7 노드)도 그대로 둡니다.
 * <p>
 * 레지스트리 경로: {@link #combinedUserMessageForRegistry(String, String)} 로 한 문자열을 만든 뒤 {@link #execute(String)} 에 전달합니다.
 */
@Component
public class ReportOptimizerSubagent implements SubAgent {

    /** {@link #execute(String)} 파싱과 결합에 동일 문자열 사용 (외부에 노출하지 않음) */
    private static final String REGISTRY_PAYLOAD_SEPARATOR = "\n---FEEDBACK---\n";

    /**
     * 오케스트레이터·도구가 {@link SubAgentRegistry}로 이 빈을 호출할 때 사용하는 페이로드 조합.
     */
    public static String combinedUserMessageForRegistry(String report, String feedback) {
        String r = report == null ? "" : report;
        String f = feedback == null ? "" : feedback;
        return r + REGISTRY_PAYLOAD_SEPARATOR + f;
    }

    private static final String SYSTEM = """
            당신은 전략 보고서를 개선합니다. 현재 초안과 평가자 피드백을 받습니다. 원래 사용자 질문이 다른 언어가 아니라면 전체 개정안을 한국어로 작성하고, 기술분석·시장분석 구역이 있으면 구조를 유지합니다.
            """;

    private final ChatClient gptClient;

        /**
         * ReportOptimizerSubagent
         *
         * 📌 보고서 개선용 서브에이전트를 구성합니다.
         *
         * @param gptClient 개선 작업을 수행할 LLM 클라이언트
         */
    public ReportOptimizerSubagent(@Qualifier("gpt") ChatClient gptClient) {
        this.gptClient = gptClient;
    }

    @Override
    public String name() {
        return StrategicAgentKeys.REPORT_OPTIMIZER;
    }

    @Override
    public String description() {
        return "report + feedback을 받아 보고서를 개선";
    }

    /**
     * {@link #combinedUserMessageForRegistry(String, String)} 과 동일 규칙의 한 덩어리를 받아 개선합니다.
     */
    @Override
    public String execute(String userMessage) {
        return execute(userMessage, null);
    }

    @Override
    public String execute(String userMessage, String systemMessage) {
        if (userMessage == null) {
            return "";
        }
        String[] parts = userMessage.split(REGISTRY_PAYLOAD_SEPARATOR, 2);
        String report = parts.length > 0 ? parts[0] : "";
        String feedback = parts.length > 1 ? parts[1] : "";
        return optimize(report, feedback, systemMessage);
    }

    /**
     * 현재 보고서와 평가 피드백을 받아 개선된 보고서 문자열을 반환한다.
         *
         * @param report   현재 초안 보고서
         * @param feedback 평가 피드백
         * @return         개선된 보고서 문자열
     */
    public String optimize(String report, String feedback) {
        return optimize(report, feedback, null);
    }

    /**
     * Tool에서 systemMessage를 주입하는 경우를 위한 오버로드.
         *
         * @param report        현재 초안 보고서
         * @param feedback      평가 피드백
         * @param systemMessage 외부에서 전달하는 system 프롬프트
         * @return              개선된 보고서 문자열
     */
    public String optimize(String report, String feedback, String systemMessage) {
        String sys = systemMessage == null ? "" : systemMessage.trim();
        String effectiveSystem = sys.isEmpty() ? SYSTEM : sys;
        String safeReport = report == null ? "" : report;
        String safeFeedback = feedback == null ? "" : feedback;
        return promptGpt(effectiveSystem, safeReport, safeFeedback);
    }

        /**
         * GPT에 실제 프롬프트를 보내 개선된 보고서를 생성합니다.
         *
         * @param system  시스템 프롬프트
         * @param report  현재 초안
         * @param feedback 평가 피드백
         * @return         GPT가 생성한 개선된 보고서
         */
    private String promptGpt(String system, String report, String feedback) {
        String userPayload = "현재 초안:\n" + report + "\n\n평가자 피드백:\n" + feedback;
        return gptClient.prompt()
                .system(system)
                .user(userPayload)
                .call()
                .content();
    }
}
