package com.ai.chapter2.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * OrchestratorService
 *
 * ✔ 여러 LLM을 오케스트레이션하는 서비스 클래스
 * ✔ GPT는 Orchestrator(계획 수립 및 최종 보고서 작성)
 * ✔ Llama, Gemini는 Worker 역할
 * ✔ 병렬 실행 + 예외 처리 + 단계별 로그 출력 포함
 */
@Slf4j
@Service
public class OrchestratorService {

    /**
     * Orchestrator 역할을 수행하는 ChatClient (예: GPT)
     * - 작업 분할(Planning)
     * - 최종 보고서 작성(Aggregation)
     */
    private final ChatClient gptClient;

    /**
     * Worker 1 (예: Llama)
     * - 데이터 요약 및 기술 기초 조사 담당
     */
    private final ChatClient llamaClient;

    /**
     * Worker 2 (예: Gemini)
     * - 최신 시장 트렌드 및 글로벌 사례 조사 담당
     */
    private final ChatClient geminiClient;

    /**
     * 병렬 실행을 위한 고정 스레드풀
     * - 워커 수에 맞춰 2개 스레드 생성
     * - ForkJoinPool 대신 명시적 Executor 사용
     */
    private final ExecutorService executor = Executors.newFixedThreadPool(2);

    /**
     * 생성자
     *
     * @Qualifier를 사용하여 각각의 LLM Bean을 주입받음
     */
    public OrchestratorService(
            @Qualifier("llama") ChatClient llamaClient,
            @Qualifier("gpt") ChatClient gptClient,
            @Qualifier("gemini") ChatClient geminiClient) {

        this.gptClient = gptClient;
        this.llamaClient = llamaClient;
        this.geminiClient = geminiClient;
    }

    /**
     * 복합 작업 실행 메서드
     *
     * 전체 흐름:
     * 1️⃣ Planning (작업 분할)
     * 2️⃣ Execution (워커 병렬 실행)
     * 3️⃣ Aggregation (결과 취합 및 최종 보고서 작성)
     *
     * @param userInput 사용자의 요청
     * @return 최종 보고서
     */
    public String executeComplexTask(String userInput) {

        /* ===============================
           1️⃣ Planning 단계
           =============================== */
        log.info("=== 단계 1: 계획 수립 시작 ===");

        String plan;

        try {
            // GPT를 이용해 워커별 작업 지시서 생성
            plan = gptClient.prompt()
                    .system("""
                        당신은 프로젝트 매니저입니다. 사용자의 요청을 해결하기 위해 두 명의 워커에게 줄 업무 지시서를 작성하세요.
                        - Worker_Llama: 데이터의 핵심 요약 및 기술적 기초 조사 담당
                        - Worker_Gemini: 최신 시장 트렌드 및 글로벌 사례 조사 담당
                        형식: [Worker_Llama: 지시내용], [Worker_Gemini: 지시내용]
                        """)
                    .user(userInput)
                    .call()
                    .content();

            log.info("계획 수립 완료: {}", plan);

        } catch (Exception e) {
            // 계획 단계 실패 시 즉시 종료
            log.error("계획 수립 단계에서 오류 발생", e);
            return "계획 수립 단계에서 오류 발생: " + e.getMessage();
        }

        /* ===============================
           2️⃣ Execution 단계 (병렬 처리)
           =============================== */
        log.info("=== 단계 2: 워커 작업 실행 (병렬) 시작 ===");

        /**
         * Worker_Llama 비동기 실행
         */
        CompletableFuture<String> llamaTask = CompletableFuture.supplyAsync(() -> {
            try {
                // 계획에서 Llama 지시사항 추출
                String instruction = extractInstruction(plan, "Worker_Llama");
                log.info("Worker_Llama 작업 시작: {}", instruction);

                // Llama 모델 호출
                String result = llamaClient.prompt()
                        .user("지시사항: " + instruction)
                        .call()
                        .content();

                log.info("Worker_Llama 작업 완료");
                return result;

            } catch (Exception e) {
                log.error("Worker_Llama 작업 실패", e);
                return "Llama 작업 실패: " + e.getMessage();
            }
        }, executor);

        /**
         * Worker_Gemini 비동기 실행
         */
        CompletableFuture<String> geminiTask = CompletableFuture.supplyAsync(() -> {
            try {
                // 계획에서 Gemini 지시사항 추출
                String instruction = extractInstruction(plan, "Worker_Gemini");
                log.info("Worker_Gemini 작업 시작: {}", instruction);

                // Gemini 모델 호출
                String result = geminiClient.prompt()
                        .user("지시사항: " + instruction)
                        .call()
                        .content();

                log.info("Worker_Gemini 작업 완료");
                return result;

            } catch (Exception e) {
                log.error("Worker_Gemini 작업 실패", e);
                return "Gemini 작업 실패: " + e.getMessage();
            }
        }, executor);

        /* ===============================
           3️⃣ Aggregation 단계
           =============================== */
        log.info("=== 단계 3: 결과 취합 및 최종 보고서 작성 시작 ===");

        String finalReport = CompletableFuture
                .allOf(llamaTask, geminiTask)  // 두 워커 모두 완료 대기
                .thenApply(v -> {

                    // 각 워커 결과 취합
                    String combinedWork = String.format(
                            "Llama 결과: %s\nGemini 결과: %s",
                            llamaTask.join(),
                            geminiTask.join()
                    );

                    log.info("워커 결과 취합 완료:\n{}", combinedWork);
                    log.info("최종 보고서 작성[GPT] 진행");

                    try {
                        // GPT가 최종 보고서 작성
                        String report = gptClient.prompt()
                                .system("워커들의 조사 결과물을 바탕으로 사용자에게 전달할 최종 보고서를 작성하세요.")
                                .user(combinedWork)
                                .call()
                                .content();

                        log.info("최종 보고서 작성 완료");
                        return report;

                    } catch (Exception e) {
                        log.error("최종 보고서 작성 실패", e);
                        return "최종 보고서 작성 실패: " + e.getMessage();
                    }
                })
                .join(); // 최종 결과 대기

        log.info("=== 전체 작업 완료 ===");

        return finalReport;
    }

    /**
     * 계획 문자열에서 특정 워커의 지시사항을 추출하는 메서드
     *
     * 예시 포맷:
     * [Worker_Llama: 데이터 요약 수행]
     *
     * @param plan 전체 계획 문자열
     * @param workerName 워커 이름
     * @return 해당 워커의 지시사항
     */
    private String extractInstruction(String plan, String workerName) {

        // 정규식: [WorkerName: 내용]
        Pattern pattern = Pattern.compile("\\[" + workerName + ":\\s*(.*?)\\]");
        Matcher matcher = pattern.matcher(plan);

        if (matcher.find()) {
            return matcher.group(1).trim();
        }

        // 포맷이 일치하지 않을 경우 기본값
        return "일반 분석 수행";
    }

    /**
     * Spring 컨테이너 종료 시 ExecutorService 종료
     * - 리소스 누수 방지
     */
    @PreDestroy
    public void shutdownExecutor() {
        log.info("ExecutorService 종료");
        executor.shutdown();
    }
}
