package com.ai.shared.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "strategic.evaluator")
public class StrategicEvaluatorProperties {

    private int approvalThreshold = 75;

    public int getApprovalThreshold() {
        return approvalThreshold;
    }

    public void setApprovalThreshold(int approvalThreshold) {
        this.approvalThreshold = approvalThreshold;
    }
}
