package com.ai.shared.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI eduOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Edu REST API")
                        .description("Spring AI 강의용 REST API (React `frontend_agent` 등에서 호출)")
                        .version("0.0.1"));
    }
}
