package com.ai.chapter5.tool;

import com.ai.chapter5.tool.api.StrategicTool;
import com.ai.shared.agent.api.SubAgentRegistry;
import com.ai.chapter5.tool.registry.ToolRegistry;
import org.springframework.stereotype.Component;

/**
 * RoutingTool
 *
 * 📌 Chapter 5 — 사용자의 요청을 SIMPLE / STRATEGIC 두 가지 카테고리로 분류하는 StrategicTool.
 *
 * 역할:
 * - {@link ToolRegistry} 에 {@code "routing"} 이름으로 등록되어,
 *   메인 오케스트레이터가 가장 먼저 호출하는 진입 도구입니다.
 * - 실제 분류 로직은 {@link SubAgentRegistry} 를 통해
 *   같은 이름의 서브에이전트({@code strategic-router.md})가 수행하며,
 *   이 도구는 결과를 정규화하여 "SIMPLE" 또는 "STRATEGIC" 문자열만 반환합니다.
 */
@Component
public class RoutingTool implements StrategicTool {

    private static final String TOOL_NAME = "routing";
    private final SubAgentRegistry subAgentRegistry;

    /**
     * RoutingTool
     *
     * 📌 서브에이전트 레지스트리를 주입받아 라우팅 전용 Tool 인스턴스를 생성합니다.
     *
     * @param subAgentRegistry 이름 기반으로 서브에이전트를 조회·호출하는 레지스트리
     */
    public RoutingTool(SubAgentRegistry subAgentRegistry) {
        this.subAgentRegistry = subAgentRegistry;
    }

    @Override
    public String name() {
        return TOOL_NAME;
    }

    @Override
    public String description() {
        return "사용자 요청을 SIMPLE 또는 STRATEGIC으로 분류";
    }

    /**
     * 라우팅 지시문을 도구에 두면 오케스트레이터는 분기만 결정하고, 분류 규칙·예시·출력 형식은
     * 이 한곳에서 관리할 수 있습니다. 프롬프트 수정 시 레지스트리·호출부를 건드리지 않아도 되고,
     * 동일 도구를 다른 에이전트에서 재사용할 때도 행동이 일관됩니다.
     */
    @Override
    public String systemMessage() {
        return """
            당신은 라우터입니다. 사용자 메시지를 읽고 정확히 한 단어만 출력하세요. **SIMPLE** 또는 **STRATEGIC** 중 하나입니다.
            **STRATEGIC**: 구조화된 비즈니스·수익모델, 기술적 과제, 비교, 로드맵, 기술+시장 통합 인사이트가 필요할 때 사용합니다.
            **SIMPLE**: 인사 및 안부 관련 질문 등 공식 보고서가 불필요할 때 사용합니다.
            
            우선순위 규칙:
            - 아래 표현이 있으면 기본적으로 STRATEGIC을 선택합니다:
              분석, 비교, 전략, 로드맵, 기술적 과제, 도입 방안, 수익 모델, 시장성, 사업성, 리스크, 전망, 인사이트
            - "분석해줘", "정리해줘", "평가해줘"처럼 보고서/검토 의도가 보이면 STRATEGIC입니다.
            - 인사/안부/가벼운 대화(예: 안녕, 고마워, 오늘 어때?)만 SIMPLE입니다.
            - 애매하면 STRATEGIC을 선택합니다.
            
            예시:
            - "도심형 항공 모빌리티(UAM) 서비스의 국내 도입을 위한 기술적 과제와 예상 수익 모델을 분석해줘" -> STRATEGIC
            - "안녕? 오늘 날씨 어때?" -> SIMPLE
            
            출력 규칙:
            - `SIMPLE` 또는 `STRATEGIC`만 출력합니다(부호·설명 없음).
                """;
    }

    /**
     * execute
     *
     * 📌 사용자 입력을 라우팅 서브에이전트에 전달해 SIMPLE/STRATEGIC 중 하나를 판정하고, 결과를 정규화합니다.
     *
     * 동작:
     * - {@link SubAgentRegistry}에서 {@code "routing"} 서브에이전트를 조회한 뒤,
     *   {@link #systemMessage()}와 함께 실행합니다.
     * - 서브에이전트 결과가 null 이거나 예상치 못한 문자열인 경우에도,
     *   기본값을 SIMPLE로 두고 "STRATEGIC" 문자열만 엄격히 유지합니다.
     *
     * @param input 사용자 원문 입력
     * @return      "SIMPLE" 또는 "STRATEGIC"
     */
    @Override
    public String execute(String input) {
        String result = subAgentRegistry.require(name()).execute(input, systemMessage());
        if (result == null) {
            return "SIMPLE";
        }
        String normalized = result.trim().toUpperCase();
        return "STRATEGIC".equals(normalized) ? "STRATEGIC" : "SIMPLE";
    }

}
