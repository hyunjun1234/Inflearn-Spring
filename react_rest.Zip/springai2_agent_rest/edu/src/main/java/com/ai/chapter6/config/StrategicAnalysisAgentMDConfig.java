package com.ai.chapter6.config;

import com.ai.shared.publisher.WorkflowStatusPublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.google.genai.GoogleGenAiChatModel;
import org.springframework.ai.ollama.OllamaChatModel;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * StrategicAnalysisAgentMDConfig
 *
 * 📌 strategic-analysis-agent-system.md 를 system prompt로 사용하는
 *    TaskTool 기반 전략 분석 ChatClient 예제 구성입니다.
 *
 * - 기존 {@link StrategicAnalysisAgentConfig} 는 코드 내 상수 system prompt 를 사용하고,
 *   이 설정은 {@code classpath:/prompts/strategic-analysis-agent-system.md} 파일을 로드해 사용합니다.
 * - 서브에이전트·TaskTool·TodoWrite 조립은 {@link StrategicTaskChatClientFactory}를 공유합니다.
 */
@Configuration
@Slf4j
public class StrategicAnalysisAgentMDConfig {

    /**
     * strategic-analysis-agent-system.md 를 system prompt로 사용하는 ChatClient 예제 빈입니다.
     * Bean 이름은 {@code strategicAnalysisAgentMd} 로 두어 기존 구성과 구분합니다.
     */
    @Bean("strategicAnalysisAgentMd")
    public ChatClient strategicAnalysisAgentMd(
            OpenAiChatModel openAiChatModel,
            OllamaChatModel ollamaChatModel,
            GoogleGenAiChatModel googleGenAiChatModel,
            WorkflowStatusPublisher statusPublisher) {

        String systemPrompt = loadSystemPromptFromMarkdown();

        return StrategicTaskChatClientFactory.buildStrategicTaskChatClient(
                openAiChatModel,
                ollamaChatModel,
                googleGenAiChatModel,
                statusPublisher,
                () -> UUID.randomUUID(),
                systemPrompt,
                "AGENT_TODO_MD");
    }

    /**
     * classpath 상의 {@code prompts/strategic-analysis-agent-system.md} 파일을 읽어
     * system prompt 문자열로 로드합니다.
     *
     * <p>파일 로드에 실패할 경우, 경고 로그를 남기고 간단한 기본 프롬프트 문자열로 대체합니다.</p>
     *
     * @return Markdown 파일에서 읽어온 system prompt 문자열 또는 기본 프롬프트
     */
    private String loadSystemPromptFromMarkdown() {
        ClassPathResource resource =
                new ClassPathResource("chapter6/prompts/strategic-analysis-agent-system.md");
        try {
            byte[] bytes = resource.getInputStream().readAllBytes();
            return new String(bytes, StandardCharsets.UTF_8);
        } catch (IOException e) {
            log.warn("strategic-analysis-agent-system.md 로드 실패, 단순 기본 프롬프트로 대체합니다.", e);
            return """
                    당신은 전략 분석 오케스트레이터입니다.
                    TaskTool과 TodoWrite를 사용하여 routing/analysis/evaluation/optimization 단계를 수행하세요.
                    """;
        }
    }
}
