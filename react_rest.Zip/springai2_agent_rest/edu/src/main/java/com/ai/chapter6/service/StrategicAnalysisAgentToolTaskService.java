package com.ai.chapter6.service;

import com.ai.chapter6.context.StrategicWorkflowContext;
import com.ai.shared.publisher.WorkflowStatusPublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * StrategicAnalysisAgentToolTaskService
 *
 * 📌 Chapter 6 — Task tool + Agent Registry 기반 전략 분석
 *
 * 아키텍처 개요:
 * - {@link org.springaicommunity.agent.tools.task.TaskTool} 으로 Markdown 서브에이전트 위임
 * - {@link org.springaicommunity.agent.tools.TodoWriteTool} 로 진행 단계 표시
 * - Redis/SSE는 {@link WorkflowStatusPublisher} + {@link StrategicWorkflowContext} 로 연결
 *
 * 특징:
 * - 흐름 제어(라우팅/병렬/반복)는 Java 오케스트레이터가 담당
 * - 각 단계의 실제 생성은 TaskTool 기반 서브에이전트에 위임
 *
 * workflowId 전달 규칙:
 * - 본 클래스는 진입 경계에서 {@link StrategicWorkflowContext}를 set/clear 합니다.
 * - 에이전트 호출에는 workflowId를 사용자 메시지 본문에 명시 포함합니다.
 * - 상세 규칙: {@code src/main/resources/docs/workflow-context-guidelines.md}
 */
@Service
@Slf4j
public class StrategicAnalysisAgentToolTaskService {

    private final StrategicAnalysisTaskToolOrchestrator orchestrator;

    /**
     * 📡 WorkflowStatusPublisher
     *
     * STARTED / AGENT / COMPLETED / ERROR 및 AGENT_TODO 단계 발행
     */
    private final WorkflowStatusPublisher statusPublisher;

    /**
     * StrategicAnalysisAgentToolTaskService
     *
     * 📌 TaskTool 기반 전략 분석 오케스트레이터와 상태 발행 컴포넌트를 주입받는 생성자입니다.
     *
     * @param orchestrator      TaskTool 기반 전략 분석 메인 오케스트레이터
     * @param statusPublisher   SSE/Redis 로 상태를 내보내는 퍼블리셔
     */
    public StrategicAnalysisAgentToolTaskService(
            StrategicAnalysisTaskToolOrchestrator orchestrator,
            WorkflowStatusPublisher statusPublisher) {
        this.orchestrator = orchestrator;
        this.statusPublisher = statusPublisher;
    }

    /**
     * executeWithMonitoring
     *
     * 📌 Task tool 에이전트 실행 (SSE workflowId와 매칭)
     *
     * 처리 흐름:
     *   1. STARTED 발행
     *   2. {@link StrategicWorkflowContext}에 workflowId 설정 → Todo 이벤트가 동일 ID로 발행되도록
     *   3. Java 오케스트레이터 실행
     *   4. COMPLETED 또는 ERROR
     *   5. finally 에서 ThreadLocal 정리
     *
     * @param workflowId  상태 추적용 UUID (클라이언트가 생성)
     * @param input       사용자 프롬프트
     * @return            에이전트 최종 응답 문자열
     */
    public String executeWithMonitoring(UUID workflowId, String input) {
        log.info("[{}] 워크플로우 시작 (agent)", workflowId);
        publishStatus(workflowId, "STARTED", "워크플로우가 시작되었습니다.");

        StrategicWorkflowContext.setWorkflowId(workflowId);
        try {
            publishStatus(workflowId, "AGENT", "에이전트 오케스트레이션 실행 중...");
            String result = orchestrator.executeWithMonitoring(workflowId, input);

            publishStatus(workflowId, "COMPLETED", "에이전트 실행 완료");
            return result;
        } catch (Exception e) {
            log.error("[{}] Agent 실행 실패: {}", workflowId, e.getMessage(), e);
            publishStatus(workflowId, "ERROR", "에이전트 실행 실패");
            return "에이전트 실행 실패: " + e.getMessage();
        } finally {
            StrategicWorkflowContext.clear();
        }
    }

    /**
     * publishStatus
     *
     * 📌 ch6 TaskTool 경로에서 공통으로 사용하는 상태 발행 헬퍼 메서드입니다.
     *
     * 기능:
     * - 로그로 현재 단계와 메시지를 남기고, {@link WorkflowStatusPublisher}를 통해 Redis/SSE 로 단계 정보를 전파합니다.
     * - 상태 발행 중 예외가 발생해도 워크플로 처리 자체는 계속 진행되도록, 예외를 경고 로그로만 처리합니다.
     *
     * @param workflowId 워크플로우 추적용 UUID
     * @param step       예: {@code STARTED}, {@code AGENT}, {@code COMPLETED}, {@code ERROR}
     * @param message    UI·운영자용 설명 메시지
     */
    private void publishStatus(UUID workflowId, String step, String message) {
        log.info("[{}] 상태 업데이트: {} - {}", workflowId, step, message);
        try {
            statusPublisher.publishStatus(workflowId, step, message);
        } catch (Exception ex) {
            log.warn("[{}] 상태 발행 실패", workflowId, ex);
        }
    }
}
