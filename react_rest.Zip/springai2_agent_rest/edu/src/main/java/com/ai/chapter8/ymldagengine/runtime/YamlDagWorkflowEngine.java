package com.ai.chapter8.ymldagengine.runtime;

import com.ai.chapter8.ymldagengine.definition.WorkflowDefinition;
import com.ai.chapter8.ymldagengine.definition.WorkflowDefinitionLoader;
import com.ai.chapter8.ymldagengine.registry.WorkflowNodeRegistry;
import com.ai.shared.util.EvaluationApprovalDecider;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.CompletableFuture;

/**
 * YamlDagWorkflowEngine
 *
 * 📌 YAML 기반 DAG 정의를 읽어 {@link WorkflowNode}들을 동적으로 실행하는 엔진
 * (Chapter 8/9 공용 — {@link WorkflowDefinitionLoader} 구현체만 바꿔 끼웁니다.)
 *
 * - {@link WorkflowDefinitionLoader} 로 YAML을 파싱해 {@link WorkflowDefinition}을 로딩
 * - {@code dependsOn} 관계로 위상 정렬 후, {@link WorkflowNodeRegistry} 로 {@code handler} → 노드 실행
 */
@Slf4j
public class YamlDagWorkflowEngine {

    private final WorkflowDefinitionLoader definitionLoader;
    private final WorkflowNodeRegistry workflowNodeRegistry;

    public YamlDagWorkflowEngine(
            WorkflowDefinitionLoader definitionLoader,
            WorkflowNodeRegistry workflowNodeRegistry
    ) {
        this.definitionLoader = definitionLoader;
        this.workflowNodeRegistry = workflowNodeRegistry;
    }

    /**
     * 🧵 YAML DAG 실행용 스레드 풀 ({@link java.util.concurrent.Executors#newFixedThreadPool(int)} — 크기 4).
     *
     * <p>노드 실행 시 {@link WorkflowNode#execute(WorkflowContext, java.util.concurrent.Executor)}에
     * 전달되며, Tomcat 등 호출 스레드를 직접 블로킹하지 않도록 합니다.</p>
     */
    private final java.util.concurrent.ExecutorService executor =
            java.util.concurrent.Executors.newFixedThreadPool(4);

    /**
     * YAML 워크플로 id + 컨텍스트 기반 실행.
     *
     * 1) YAML 정의를 읽어 {@link WorkflowDefinition} 확보
     * 2) {@code dependsOn} 관계로 위상 정렬(topological order) 생성
     * 3) 정렬된 순서대로 {@link WorkflowNode} 실행
     *    - {@code handler} 값을 {@link WorkflowNodeRegistry#get(String)} 으로 매핑
     *    - {@code when} 조건은 간단한 형태(route.category)만 평가
     *
     * @param workflowDefinitionId YAML 워크플로 정의 id (예: "strategic-analysis")
     * @param ctx                  실행 컨텍스트
     * @return                     최종 응답 문자열을 지닌 CompletableFuture
     */
    public CompletableFuture<String> run(String workflowDefinitionId, WorkflowContext ctx) {
        WorkflowDefinition definition = definitionLoader.load(workflowDefinitionId);
        if (definition == null || definition.nodes() == null || definition.nodes().isEmpty()) {
            log.warn("YAML 워크플로 정의(id={})를 찾지 못했습니다.", workflowDefinitionId);
            ctx.publish("ERROR", "YAML 워크플로 정의를 찾을 수 없습니다: " + workflowDefinitionId);
            return CompletableFuture.completedFuture("YAML 워크플로 정의를 찾을 수 없습니다: " + workflowDefinitionId);
        }

        log.info("YAML 워크플로 정의(id={}) 사용: nodes={}", definition.id(), definition.nodes().size());
        ctx.publish("STARTED", "YAML DAG 워크플로우가 시작되었습니다.");

        return CompletableFuture.supplyAsync(() -> {
            try {
                java.util.List<WorkflowDefinition.NodeDefinition> ordered = topologicalSort(definition);
                for (WorkflowDefinition.NodeDefinition nodeDef : ordered) {
                    if (!shouldRun(nodeDef, ctx)) {
                        log.debug("노드 when 조건 불만족으로 건너뜀: {}", nodeDef.id());
                        continue;
                    }
                    String handlerId = nodeDef.handler();
                    if (handlerId == null || handlerId.isBlank()) {
                        log.debug("handler 가 없는 노드(id={})는 스킵합니다.", nodeDef.id());
                        continue;
                    }
                    // 평가/개선 루프는 YAML config 를 해석해 별도 처리
                    if ("eval-opt-loop".equals(handlerId)) {
                        log.debug("평가/개선 루프 노드 실행 시작: yamlId={}", nodeDef.id());
                        String loopResult = runEvalOptLoop(nodeDef, ctx).join();
                        if (loopResult == null) {
                            ctx.publish("ERROR", "평가/개선 루프 실행 실패");
                            return "YAML DAG 노드 실패(" + handlerId + "): 평가/개선 루프 실행 실패";
                        }
                        continue;
                    }
                    WorkflowNode node = workflowNodeRegistry.get(handlerId);
                    if (node == null) {
                        log.warn("handler '{}' 에 해당하는 WorkflowNode 를 찾지 못해 스킵합니다. (nodeId={})",
                                handlerId, nodeDef.id());
                        continue;
                    }
                    log.debug("실행 노드: yamlId={}, handlerId={}", nodeDef.id(), handlerId);
                    NodeResult result = node.execute(ctx, executor).join();
                    if (!result.success()) {
                        ctx.publish("ERROR", result.errorMessage());
                        return "YAML DAG 노드 실패(" + handlerId + "): " + result.errorMessage();
                    }
                }

                // SIMPLE / STRATEGIC 분기 기준으로 최종 결과 선택
                String route = ctx.getRouteCategory();
                String result;
                if ("SIMPLE".equalsIgnoreCase(route)) {
                    result = ctx.getSimpleResponse();
                } else {
                    String report = ctx.getCurrentReport();
                    result = report != null ? report : ctx.getSimpleResponse();
                }
                ctx.publish("COMPLETED", "YAML DAG 워크플로우가 완료되었습니다.");
                return result;
            } catch (Exception e) {
                log.error("YAML DAG 워크플로 실행 중 예외 발생 (id={})", workflowDefinitionId, e);
                ctx.publish("ERROR", "YAML DAG 워크플로우 실행 실패");
                return "YAML DAG 워크플로우 실행 실패: " + e.getMessage();
            }
        }, executor);
    }

    /**
     * 간단한 when 조건 평가.
     *
     * <p>현재 지원되는 조건:</p>
     * <ul>
     *   <li>{@code route.category == 'SIMPLE'}</li>
     *   <li>{@code route.category == 'STRATEGIC'}</li>
     * </ul>
     *
     * @param def YAML 노드 정의
     * @param ctx 실행 컨텍스트 (분기 정보 보유)
     * @return    조건을 만족해 실행해야 하면 {@code true}, 아니면 {@code false}
     */
    private boolean shouldRun(WorkflowDefinition.NodeDefinition def, WorkflowContext ctx) {
        String when = def.when();
        if (when == null || when.isBlank()) {
            return true;
        }
        String cond = when.replace(" ", "");
        if (cond.startsWith("route.category==")) {
            String route = ctx.getRouteCategory();
            if (route == null) {
                return false;
            }
            if (cond.endsWith("'SIMPLE'") || cond.endsWith("\"SIMPLE\"")) {
                return "SIMPLE".equalsIgnoreCase(route);
            }
            if (cond.endsWith("'STRATEGIC'") || cond.endsWith("\"STRATEGIC\"")) {
                return "STRATEGIC".equalsIgnoreCase(route);
            }
        }
        // 정의되지 않은 식은 우선 실행하도록 둔다.
        return true;
    }

    /**
     * eval-opt-loop 노드를 위한 Evaluation/Optimization 루프 실행.
     *
     * <p>YAML config 예시:
     * <pre>
     *   config:
     *     maxRounds: 4
     *     evaluator: report-evaluator-ch8
     *     optimizer: report-optimizer-ch8
     *     approveThreshold: 0.8
     * </pre>
     *
     * @param def 루프 설정이 들어있는 YAML 노드 정의
     * @param ctx 실행 컨텍스트
     * @return 최종 승인(또는 최대 회차 이후)의 보고서 문자열
     */
    private CompletableFuture<String> runEvalOptLoop(
            WorkflowDefinition.NodeDefinition def,
            WorkflowContext ctx
    ) {
        java.util.Map<String, Object> config = def.config();
        if (config == null) {
            log.warn("eval-opt-loop 노드에 config 가 없습니다. (nodeId={})", def.id());
            return CompletableFuture.completedFuture(ctx.getCurrentReport());
        }

        int maxRounds = toInt(config.getOrDefault("maxRounds", 4));
        String evaluatorId = toString(config.getOrDefault("evaluator", "report-evaluator-ch8"));
        String optimizerId = toString(config.getOrDefault("optimizer", "report-optimizer-ch8"));
        double approveThreshold = toDouble(config.getOrDefault("approveThreshold", 0.8));

        WorkflowNode evaluatorNode = workflowNodeRegistry.get(evaluatorId);
        WorkflowNode optimizerNode = workflowNodeRegistry.get(optimizerId);

        if (evaluatorNode == null || optimizerNode == null) {
            log.error("평가/개선 루프에 필요한 노드를 찾지 못했습니다. evaluator={}, optimizer={}",
                    evaluatorId, optimizerId);
            return CompletableFuture.completedFuture(null);
        }

        return runEvalOptRound(ctx, 1, maxRounds, approveThreshold, evaluatorNode, optimizerNode);
    }

    /**
     * 한 회차 Evaluation → (미통과 시) Optimization 을 실행하고 필요 시 재귀적으로 다음 회차를 이어갑니다.
     */
    private CompletableFuture<String> runEvalOptRound(
            WorkflowContext ctx,
            int round,
            int maxRounds,
            double approveThreshold,
            WorkflowNode evaluatorNode,
            WorkflowNode optimizerNode
    ) {
        if (round > maxRounds) {
            return CompletableFuture.completedFuture(ctx.getCurrentReport());
        }
        ctx.setEvaluationRound(round);
        return evaluatorNode.execute(ctx, executor).thenCompose(evalNr -> {
            if (!evalNr.success()) {
                // 평가 자체 실패 시 다음 회차로 진행
                return runEvalOptRound(ctx, round + 1, maxRounds, approveThreshold, evaluatorNode, optimizerNode);
            }
            String evaluationText = ctx.getLastEvaluation();
            // approveThreshold (0~1 비율)를 0~100 점수로 변환해 승인 여부 판정
            int thresholdScore = (int) Math.round(approveThreshold * 100);
            if (EvaluationApprovalDecider.shouldApprove(evaluationText, thresholdScore)) {
                ctx.publish("APPROVED", "최종 승인 완료 (PASS 또는 " + thresholdScore + "점 이상)");
                return CompletableFuture.completedFuture(ctx.getCurrentReport());
            }
            return optimizerNode.execute(ctx, executor).thenCompose(optNr -> {
                if (!optNr.success()) {
                    ctx.publish("ERROR", optNr.errorMessage());
                }
                return runEvalOptRound(ctx, round + 1, maxRounds, approveThreshold, evaluatorNode, optimizerNode);
            });
        });
    }

    /**
     * kahn(방향 비순환 그래프(DAG)에서 위상 정렬 수행) 알고리즘으로 YAML 노드들의 위상 정렬을 수행합니다.
     *
     * <p>노드 id 기준으로 의존성을 구성하고, {@code dependsOn} 이 없는 노드부터 순차적으로 목록에 추가합니다.
     * 순회가 끝났을 때 정의된 노드 수와 정렬된 노드 수가 다르면 사이클 또는 누락 의존성을 경고 로그로 남깁니다.</p>
     *
     * @param definition YAML에서 파싱한 워크플로 정의
     * @return           실행 순서가 결정된 노드 정의 리스트
     */
    private java.util.List<WorkflowDefinition.NodeDefinition> topologicalSort(WorkflowDefinition definition) {
        java.util.Map<String, WorkflowDefinition.NodeDefinition> byId = new java.util.HashMap<>();
        java.util.Map<String, java.util.List<String>> outgoing = new java.util.HashMap<>();
        java.util.Map<String, Integer> indegree = new java.util.HashMap<>();

        for (WorkflowDefinition.NodeDefinition n : definition.nodes()) {
            byId.put(n.id(), n);
            outgoing.putIfAbsent(n.id(), new java.util.ArrayList<>());
            indegree.putIfAbsent(n.id(), 0);
        }

        for (WorkflowDefinition.NodeDefinition n : definition.nodes()) {
            if (n.dependsOn() == null) continue;
            for (String dep : n.dependsOn()) {
                if (!byId.containsKey(dep)) {
                    log.warn("YAML 워크플로 정의에 존재하지 않는 dependsOn 참조: {} -> {}", n.id(), dep);
                    continue;
                }
                outgoing.get(dep).add(n.id());
                indegree.put(n.id(), indegree.getOrDefault(n.id(), 0) + 1);
            }
        }

        java.util.Queue<String> queue = new java.util.ArrayDeque<>();
        for (java.util.Map.Entry<String, Integer> e : indegree.entrySet()) {
            if (e.getValue() == 0) {
                queue.add(e.getKey());
            }
        }

        java.util.List<WorkflowDefinition.NodeDefinition> ordered = new java.util.ArrayList<>();
        while (!queue.isEmpty()) {
            String id = queue.poll();
            WorkflowDefinition.NodeDefinition n = byId.get(id);
            if (n != null) {
                ordered.add(n);
            }
            for (String next : outgoing.getOrDefault(id, java.util.List.of())) {
                int d = indegree.computeIfPresent(next, (k, v) -> v - 1);
                if (d == 0) {
                    queue.add(next);
                }
            }
        }

        if (ordered.size() != byId.size()) {
            log.warn("YAML 워크플로 정의에 사이클이 있거나 일부 노드가 정렬되지 않았습니다. (expected={}, actual={})",
                    byId.size(), ordered.size());
        }

        return ordered;
    }

    // --- 간단한 타입 변환 유틸 ---

    private static int toInt(Object v) {
        if (v instanceof Number n) return n.intValue();
        try {
            return Integer.parseInt(String.valueOf(v));
        } catch (Exception e) {
            return 0;
        }
    }

    private static double toDouble(Object v) {
        if (v instanceof Number n) return n.doubleValue();
        try {
            return Double.parseDouble(String.valueOf(v));
        } catch (Exception e) {
            return 0.0;
        }
    }

    private static String toString(Object v) {
        return v != null ? String.valueOf(v) : null;
    }
}
