package com.ai.chapter3.service;

import com.ai.shared.publisher.WorkflowStatusPublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


/**
 * StrategicAnalysisService
 *
 * 📌 멀티 모델 기반 전략 분석 오케스트레이션 서비스
 *
 * 아키텍처 개요:
 * 1️⃣ Router (Llama)        → 요청 난이도 분류
 * 2️⃣ Parallel Workers      → 기술(GPT) + 시장(Gemini) 동시 분석
 * 3️⃣ Evaluator-Optimizer   → Gemini 평가 + GPT 개선 반복
 *
 * 특징:
 * - 병렬 처리 (CompletableFuture)
 * - Redis 기반 실시간 상태 모니터링
 * - 단계별 예외 처리
 *   - 반복적 품질 개선 루프
 */
@Service
@Slf4j
public class StrategicAnalysisService {

    /**
     * 🧠 Llama 모델
     *
     * 역할:
     * - 요청을 SIMPLE / STRATEGIC 으로 분류하는 Router 역할
     * - 비교적 비용이 낮은 모델 사용을 가정
     */
    private final ChatClient llamaClient;

    /**
     * 🤖 GPT 모델
     *
     * 역할:
     * - 기술 분석 담당 (Technical Worker)
     * - 평가 피드백 반영 수정 (Optimizer)
     */
    private final ChatClient gptClient;

    /**
     * 💎 Gemini 모델
     *
     * 역할:
     * - 시장 분석 담당 (Market Worker)
     * - 보고서 품질 평가 (Evaluator)
     */
    private final ChatClient geminiClient;

    /**
     * 📡 WorkflowStatusPublisher
     *
     * 역할:
     * - Redis Pub/Sub으로 상태 발행
     * - UI 실시간 모니터링 용도
     */
    private final WorkflowStatusPublisher statusPublisher;

    /**
     * 🧵 병렬 분석 전용 스레드 풀 ({@link Executors#newFixedThreadPool(int)} — 크기 4).
     *
     * <p><b>사용 이유</b>
     * <ul>
     *   <li>기술/시장 등 병렬 LLM 호출 시 공용 {@link java.util.concurrent.ForkJoinPool#commonPool()}에 부담을 주지 않고,
     *       I/O 블로킹이 있는 작업의 <strong>동시 실행 개수를 고정</strong>한다.</li>
     *   <li>싱글톤 서비스에서 공유되면 <strong>모든 HTTP 요청이 동일 풀을 사용</strong>한다.</li>
     * </ul>
     *
     * <p><b>부하·확장</b>: 동시에 처리할 수 있는 양은 코드와 인프라에서 함께 정하고, 넘치면
     * 거절·대기·수평 확장(인스턴스 증설) 등으로 다루는 것이 일반적이다.
     * 이 고정 풀은 <strong>애플리케이션 내부 병렬 단계의 동시 실행 상한</strong>만 나타내며,
     * 큐 적체 방지·전역 동시 요청 제한·타임아웃 등은 별도 설계가 필요할 수 있다.
     */
    private final ExecutorService analysisExecutor = Executors.newFixedThreadPool(4);

    /**
     * 생성자
     *
     * @Qualifier를 사용하여 각 모델을 역할별로 주입
     */
    public StrategicAnalysisService(
            @Qualifier("llama") ChatClient llamaClient,
            @Qualifier("gpt") ChatClient gptClient,
            @Qualifier("gemini") ChatClient geminiClient,
            WorkflowStatusPublisher statusPublisher) {

        this.llamaClient = llamaClient;
        this.gptClient = gptClient;
        this.geminiClient = geminiClient;
        this.statusPublisher = statusPublisher;
    }

    /**
     * executeWithMonitoring
     *
     * 📌 전략 분석 워크플로우 실행 메서드
     *
     * 처리 흐름:
     *   1. Routing
     *   2. Parallel Analysis
     *   3. Evaluator-Optimizer Loop
     *
     * @param workflowId  상태 추적용 UUID
     * @param input       사용자 입력
     * @return            최종 분석 보고서
     */
    public String executeWithMonitoring(UUID workflowId, String input) {


        // -------------------------------------------------
        // 🟢 0️⃣ 워크플로우 시작
        // -------------------------------------------------
        log.info("[{}] 워크플로우 시작", workflowId);
        publishStatus(workflowId, "STARTED", "워크플로우가 시작되었습니다.");

        // =================================================
        // 🟡 1️⃣ Routing 단계
        // =================================================

        publishStatus(workflowId, "ROUTING", "질문 카테고리를 분석 중...");

        String category; // SIMPLE or STRATEGIC 저장 변수

        try {
            // Llama 모델을 사용한 요청 분류
            category = llamaClient.prompt()
                    .system("요청을 'SIMPLE' 또는 'STRATEGIC'으로 분류하세요.")
                    .user(input)
                    .call()
                    .content()
                    .trim();

            log.info("[{}] Routing 결과: {}", workflowId, category);

        } catch (Exception e) {
            // Routing 실패 시 즉시 종료
            log.error("[{}] Routing 실패: {}", workflowId, e.getMessage(), e);
            publishStatus(workflowId, "ERROR", "Routing 단계 실패");

            return "Routing 단계 실패";
        }

        /**
         * SIMPLE 요청 처리 분기
         * - 추가 병렬 분석 없이 바로 응답 반환
         */
        if ("SIMPLE".equalsIgnoreCase(category)) {
            try {
                String result = llamaClient.prompt()
                        .user(input)
                        .call()
                        .content();

                publishStatus(workflowId, "COMPLETED", "단순 요청 처리 완료");
                return result;

            } catch (Exception e) {
                log.error("[{}] SIMPLE 처리 실패", workflowId, e);
                publishStatus(workflowId, "ERROR", "단순 요청 처리 실패");
                return "단순 요청 처리 실패";
            }
        }

        // =================================================
        // 🔵 2️⃣ Parallel Analysis 단계
        // =================================================

        publishStatus(workflowId, "ANALYZING", "기술 및 시장 데이터를 동시에 분석 중...");
        log.info("[{}] Parallel 분석 시작", workflowId);

        /**
         * 🔹 기술 분석 Future
         * - GPT 모델 사용
         * - analysisExecutor 사용
         */
        CompletableFuture<String> techFuture =
                CompletableFuture.supplyAsync(() -> {
                    try {
                        return gptClient.prompt()
                                .system("기술적 관점 분석")
                                .user(input)
                                .call()
                                .content();
                    } catch (Exception e) {
                        log.error("[{}] 기술 분석 실패", workflowId, e);
                        return "기술 분석 실패";
                    }
                }, analysisExecutor);

        /**
         * 🔹 시장 분석 Future
         * - Gemini 모델 사용
         */
        CompletableFuture<String> marketFuture =
                CompletableFuture.supplyAsync(() -> {
                    try {
                        return geminiClient.prompt()
                                .system("시장 트렌드 분석")
                                .user(input)
                                .call()
                                .content();
                    } catch (Exception e) {
                        log.error("[{}] 시장 분석 실패", workflowId, e);
                        return "시장 분석 실패";
                    }
                }, analysisExecutor);

        String rawReport; // 병렬 분석 결과 저장 변수

        try {
            /**
             * thenCombine()
             * - 두 Future 완료 후 실행
             * - 기술 + 시장 분석 결합
             */
            rawReport = techFuture
                    .thenCombine(marketFuture,
                            (tech, market) ->
                                    "기술분석: " + tech + "\n시장분석: " + market)
                    .join(); // blocking

            log.info("[{}] Parallel 분석 완료", workflowId);

        } catch (Exception e) {
            log.error("[{}] Parallel 처리 실패", workflowId, e);
            publishStatus(workflowId, "ERROR", "Parallel 분석 실패");
            return "병렬 분석 실패";
        }

        // =================================================
        // 🟣 3️⃣ Evaluator-Optimizer Loop
        // =================================================

        String finalReport = rawReport; // 반복 수정용 보고서 변수

        /**
         * 최대 4회 반복
         * - Gemini → 평가
         * - GPT → 수정
         */
        for (int i = 1; i <= 4; i++) {

            publishStatus(workflowId, "EVALUATING", i + "차 검토 중...");
            log.info("[{}] Draft #{} 평가 시작", workflowId, i);

            String evaluation; // 평가 결과 저장

            try {
                evaluation = geminiClient.prompt()
                        .system("보고서를 검토하고 80점 미만이면 개선사항을, 이상이면 PASS")
                        .user(finalReport)
                        .call()
                        .content();

            } catch (Exception e) {
                log.error("[{}] 평가 실패", workflowId, e);
                publishStatus(workflowId, "ERROR", "평가 실패");
                break;
            }

            // PASS이면 종료
            if (evaluation.contains("PASS")) {
                publishStatus(workflowId, "COMPLETED", "최종 승인 완료");
                log.info("[{}] Draft #{} 승인 완료", workflowId, i);
                break;
            }

            /**
             * Optimizer 단계
             * - GPT가 평가 피드백 반영
             */
            publishStatus(workflowId, "OPTIMIZING", "보고서 수정 중...");

            try {
                finalReport = gptClient.prompt()
                        .system("다음 피드백을 반영하여 보고서를 수정하세요: " + evaluation)
                        .user(finalReport)
                        .call()
                        .content();

            } catch (Exception e) {
                log.error("[{}] 수정 실패", workflowId, e);
                publishStatus(workflowId, "ERROR", "보고서 수정 실패");
                break;
            }
        }

        return finalReport;
    }

    /**
     * publishStatus
     *
     * 📌 상태 발행 공통 처리 메서드
     *
     * 기능:
     * - 로그 기록
     * - Redis Pub/Sub 발행
     * - Redis 실패 시에도 워크플로우 지속
     */
    private void publishStatus(UUID workflowId, String step, String message) {

        log.info("[{}] 상태 업데이트: {} - {}", workflowId, step, message);

        try {
            statusPublisher.publishStatus(workflowId, step, message);
        } catch (Exception ex) {
            log.warn("[{}] 상태 발행 실패", workflowId, ex);
        }
    }

    /**
     * shutdownExecutor
     *
     * 📌 애플리케이션 종료 시 ThreadPool 정리
     * - 스레드 누수 방지
     */
    @PreDestroy
    public void shutdownExecutor() {
        log.info("분석 Executor 종료");
        analysisExecutor.shutdown();
    }
}
