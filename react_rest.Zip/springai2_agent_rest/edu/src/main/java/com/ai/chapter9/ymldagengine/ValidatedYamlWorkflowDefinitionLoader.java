package com.ai.chapter9.ymldagengine;

import com.ai.chapter8.ymldagengine.definition.WorkflowDefinition;
import com.ai.chapter8.ymldagengine.definition.WorkflowDefinitionLoader;
import com.ai.chapter8.ymldagengine.definition.WorkflowDefinitionMapper;
import com.ai.chapter9.validation.WorkflowDefinitionValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Chapter 9. Validated Agent Workflow DSL — 검증 로더(로딩 파이프라인의 검증층).
 * <p>
 * {@code classpath:chapter9/dagworkflow/}에서 YAML을 로드하고,
 * 로딩 직후 {@link WorkflowDefinitionValidator}로 구조·의존성 검증을 통과한 정의만 캐시합니다.
 * 통과하지 못한 정의는 캐시되지 않아 엔진 스케줄링에 넘어가지 않습니다.
 */
@Component
@Qualifier("chapter9Loader")
@Slf4j
@RequiredArgsConstructor
public class ValidatedYamlWorkflowDefinitionLoader implements WorkflowDefinitionLoader {

    private final WorkflowDefinitionValidator workflowDefinitionValidator;

    private final Map<String, WorkflowDefinition> cache = new ConcurrentHashMap<>();

    @Override
    public WorkflowDefinition load(String workflowDefinitionId) {
        return cache.computeIfAbsent(workflowDefinitionId, this::loadInternal);
    }

    private WorkflowDefinition loadInternal(String workflowDefinitionId) {
        String path = "chapter9/dagworkflow/" + workflowDefinitionId + ".yml";
        ClassPathResource resource = new ClassPathResource(path);
        if (!resource.exists()) {
            log.warn("[Ch9] YAML 워크플로 정의 파일을 찾을 수 없습니다: {}", path);
            return null;
        }
        try (InputStream is = resource.getInputStream()) {
            Yaml yaml = new Yaml();
            @SuppressWarnings("unchecked")
            Map<String, Object> raw = yaml.load(is);
            if (raw == null) {
                log.warn("[Ch9] YAML 워크플로 정의를 파싱했지만 내용이 비어 있습니다: {}", path);
                return null;
            }
            WorkflowDefinition def = WorkflowDefinitionMapper.fromRawMap(raw);
            List<String> errors = workflowDefinitionValidator.validate(def);
            if (!errors.isEmpty()) {
                log.error("[Ch9] YAML 워크플로 검증 실패: id={}, errors={}", workflowDefinitionId, errors);
                return null;
            }
            log.info("[Ch9] YAML 워크플로 정의 로딩·검증 완료: id={}, nodes={}",
                    def.id(), def.nodes() != null ? def.nodes().size() : 0);
            return def;
        } catch (Exception e) {
            log.error("[Ch9] YAML 워크플로 정의 로딩 실패: {}", path, e);
            return null;
        }
    }
}
