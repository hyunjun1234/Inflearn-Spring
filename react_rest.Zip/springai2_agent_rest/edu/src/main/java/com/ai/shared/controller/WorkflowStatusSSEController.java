package com.ai.shared.controller;

import com.ai.shared.openapi.OpenApiExamples;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

/**
 * WorkflowStatusSSEController
 *
 * Redis Pub/Sub 기반으로 Workflow 상태를
 * Server-Sent Events(SSE) 방식으로 클라이언트에 실시간 스트리밍하는 컨트롤러
 *
 * 클라이언트는 특정 workflowId에 대한 상태 변경 이벤트를
 * HTTP 연결을 유지한 채 지속적으로 수신하게 됩니다.
 */
@RestController
@RequestMapping("/api/workflow") // 기본 URL 경로 설정
@RequiredArgsConstructor // final 필드에 대한 생성자를 자동 생성 (Lombok)
@Slf4j
public class WorkflowStatusSSEController {

    /**
     * Redis 메시지 리스너 컨테이너
     *
     * Redis Pub/Sub 채널을 구독하고
     * 메시지가 도착하면 해당 리스너를 실행해주는 핵심 컴포넌트
     */
    private final RedisMessageListenerContainer redisContainer;
    private final RedisTemplate<String, Object> redisTemplate;

    /**
     * 특정 workflowId에 대한 상태 스트리밍을 시작하는 엔드포인트
     *
     * @param workflowId 스트리밍 대상 워크플로우 ID
     * @return SseEmitter (클라이언트와 지속 연결되는 SSE 객체)
     */
    @GetMapping(
            value = "/stream/{workflowId}",
            produces = MediaType.TEXT_EVENT_STREAM_VALUE // SSE MIME 타입
    )
    public SseEmitter streamStatus(
            @Parameter(example = OpenApiExamples.WORKFLOW_ID_UUID) @PathVariable String workflowId) {

        /**
         * 1️⃣ SSE Emitter 생성
         *
         * - 900_000L = 15분 타임아웃
         * - 긴 LLM 워크플로우(평가/최적화 루프) 동안 연결 유지
         * - 타임아웃 또는 오류 발생 시 연결 종료
         */
        SseEmitter emitter = new SseEmitter(900_000L);

        /**
         * 2️⃣ Redis 구독 채널 이름 생성
         *
         * 예:
         * workflowId = 123
         * → channel = workflow:status:123
         */
        String channel = "workflow:status:" + workflowId;

        /**
         * 3️⃣ Redis 메시지 리스너 정의
         *
         * - Redis 채널에 메시지가 publish되면 실행됨
         * - message: Redis에서 전달된 실제 메시지
         * - pattern: 구독 패턴 (여기서는 사용하지 않음)
         */
        MessageListener listener = (message, pattern) -> {
            try {
                // Pub/Sub 바이트를 RedisTemplate Value 직렬화(Jackson JSON)와 동일하게 역직렬화 후 SSE로 전달
                Object payload = redisTemplate.getValueSerializer().deserialize(message.getBody());
                if (payload == null) {
                    return;
                }
                emitter.send(
                        SseEmitter.event()
                                .name("message")
                                .data(payload)
                );

            } catch (Exception e) {
                /**
                 * 메시지 전송 중 오류 발생 시
                 * SSE 연결을 에러 상태로 종료
                 */
                emitter.completeWithError(e);
            }
        };

        /**
         * 4️⃣ Redis 특정 채널 구독 시작
         */
        redisContainer.addMessageListener(
                listener,
                new ChannelTopic(channel)
        );

        // 최근 상태 이력을 재전송해, 느린 환경에서도 STARTED 등 초기 이벤트 유실을 줄인다.
        // 리스너를 먼저 등록했기 때문에 재전송 중 새 이벤트가 와도 놓치지 않는다.
        String historyKey = "workflow:status:history:" + workflowId;
        try {
            var history = redisTemplate.opsForList().range(historyKey, 0, -1);
            if (history != null) {
                for (Object item : history) {
                    emitter.send(
                            SseEmitter.event()
                                    .name("message")
                                    .data(item)
                    );
                }
            }
        } catch (Exception ex) {
            log.warn("SSE history replay failed. workflowId={}", workflowId, ex);
        }

        /**
         * 5️⃣ SSE 연결 종료 처리
         *
         * 연결 종료 / 타임아웃 / 에러 발생 시
         * Redis 리스너 제거 (메모리 누수 방지)
         */

        emitter.onCompletion(() ->
                redisContainer.removeMessageListener(listener)
        );

        emitter.onTimeout(() ->
                redisContainer.removeMessageListener(listener)
        );

        emitter.onError((e) ->
                redisContainer.removeMessageListener(listener)
        );

        /**
         * 6️⃣ SSE Emitter 반환
         */
        return emitter;
    }
}
