package com.ai.shared.agent.subagent;

import com.ai.shared.agent.api.SubAgent;
import com.ai.shared.agent.keys.StrategicAgentKeys;
import com.ai.shared.config.StrategicEvaluatorProperties;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * ReportEvaluatorSubagent
 *
 * 📌 병합된 초안 보고서에 대한 품질 평가(Evaluator 역할)를 수행하는 서브에이전트입니다.
 *
 * 개념:
 * - ch4~ch7 전체 파이프라인에서 “현재 draft가 충분히 좋은지”를 판단하는 심사위원 역할입니다.
 * - 점수(0~100)와 PASS 여부를 기준으로, 오케스트레이터가
 *   “여기서 멈출지 / ReportOptimizer로 한 번 더 돌릴지”를 결정할 수 있게 합니다.
 *
 * 모델:
 * - {@link Qualifier @Qualifier("gpt")} (프로젝트 설정에 따라 변경 가능)
 *
 * 레지스트리 키:
 * - {@code "report-evaluator"}
 *
 * 입력:
 * - {@code userMessage} 에 현재 초안 전체가 들어감 (오케스트레이션에서 {@code finalReport} 전달)
 *
 * 출력:
 * - 점수 기준 미달 시 개선 피드백, 통과 시 응답에 {@code PASS} 포함
 * - Chapter 4/5/6/7의 오케스트레이터는 이 출력에서 점수를 파싱하여
 *   SSE 상태 메시지(EVALUATION_SCORE)로 노출합니다.
 */
@Component
public class ReportEvaluatorSubagent implements SubAgent {
    private final ChatClient geminiClient;
    private final StrategicEvaluatorProperties evaluatorProperties;

    /**
     * ReportEvaluatorSubagent
     *
     * 📌 보고서 평가용 서브에이전트를 구성합니다.
     *
     * @param geminiClient        평가를 수행할 LLM 클라이언트
     * @param evaluatorProperties 승인 임계 점수 등 평가 규칙을 담은 설정
     */
    public ReportEvaluatorSubagent(
            @Qualifier("gpt") ChatClient geminiClient,
            StrategicEvaluatorProperties evaluatorProperties) {
        this.geminiClient = geminiClient;
        this.evaluatorProperties = evaluatorProperties;
    }

    @Override
    public String name() {
        return StrategicAgentKeys.REPORT_EVALUATOR;
    }

    @Override
    public String description() {
        return "병합된 초안 보고서를 검토하고 PASS 또는 구체적 개선 피드백을 제시한다.";
    }

    @Override
    public String execute(String userMessage) {
        return execute(userMessage, null);
    }

    @Override
    public String execute(String userMessage, String systemMessage) {
        String sys = systemMessage == null ? "" : systemMessage.trim();
        String effectiveSystem = sys.isEmpty() ? systemMessage() : sys;
        return geminiClient.prompt()
                .system(effectiveSystem)
                .user(userMessage)
                .call()
                .content();
    }

    /**
     * 평가 기준·JSON 스키마·PASS 규칙을 포함한 system 프롬프트를 생성합니다.
     *
     * @return 평가 서브에이전트에 사용할 system 메시지
     */
    private String systemMessage() {
        int threshold = evaluatorProperties.getApprovalThreshold();
        return """
                당신은 전략 보고서 심사관입니다. 반드시 JSON 하나만 반환하세요(코드블록/설명문 금지).
                
                평가 항목(합계 100):
                - clarity: 0~25 (표현 명확성)
                - completeness: 0~35 (근거·범위 완결성)
                - feasibility: 0~40 (실행 가능성·로드맵·KPI)
                
                강제 감점 규칙:
                - 시장/기술 근거가 약하면 completeness를 최소 10점 이상 감점
                - 수익모델 수치(가정·단위·민감도)가 없으면 feasibility를 최소 10점 이상 감점
                - 리스크/대응전략이 없으면 completeness를 최소 8점 이상 감점
                - 실행 로드맵(단계·기간·KPI)이 없으면 feasibility를 최소 8점 이상 감점
                
                점수 캘리브레이션:
                - 치명적 결함 1개라도 있으면 total_score는 84점 초과 금지
                - 중대한 결함 2개 이상이면 total_score는 74점 초과 금지
                - 모든 항목이 구체적 근거로 충족될 때만 90점 이상 허용
                
                PASS 규칙:
                - total_score >= %d 이고 must_fix가 비어 있을 때만 pass=true
                - 그 외에는 pass=false
                
                반드시 아래 스키마로만 응답:
                {"clarity":int,"completeness":int,"feasibility":int,"total_score":int,"pass":boolean,"must_fix":["..."],"reasons":["..."]}
                """.formatted(threshold);
    }
}

