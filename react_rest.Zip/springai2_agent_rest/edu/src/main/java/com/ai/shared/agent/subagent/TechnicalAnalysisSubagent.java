package com.ai.shared.agent.subagent;

import com.ai.shared.agent.api.SubAgent;
import com.ai.shared.agent.keys.StrategicAgentKeys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * TechnicalAnalysisSubagent
 *
 * 📌 STRATEGIC 경로에서 “기술/아키텍처 분석”을 담당하는 서브에이전트입니다.
 *
 * 개념:
 * - ch4에서는 SubAgentRegistry 기반 멀티 에이전트 구조의 “기술 분석 담당자” 역할을 하고,
 *   ch5에서는 Tool들이 이 서브에이전트에 위임해 기술 파트를 작성하며,
 *   ch6/7에서는 Task/DAG 노드가 이 서브에이전트와 동일한 역할을 수행합니다.
 * - 스택 선택, 리스크, 구현 시 유의점, 트레이드오프를 LLM에게 맡기되,
 *   Java 오케스트레이터는 언제/어떻게 이 출력을 사용할지(병합, 평가, 최적화)를 제어합니다.
 *
 * 모델:
 * - 1차: {@link Qualifier @Qualifier("gpt")} — 기술 서술·구조화 우선
 * - 장애 시 2차: {@link Qualifier @Qualifier("gemini")} — fallback 재시도
 *
 * 레지스트리 키:
 * - {@code "technical-analysis"}
 *
 * 실행:
 * - 사용자 원문을 system 지시와 함께 호출
 * - 1차 모델(gpt) 실패 시 gemini로 동일 입력 재시도
 */
@Component
@Slf4j
public class TechnicalAnalysisSubagent implements SubAgent {

    private static final String SYSTEM = """
            당신은 시니어 기술 분석가입니다. 사용자 요청을 엔지니어링·아키텍처 관점에서 분석하세요. 스택 선택, 리스크, 구현 시 유의점, 트레이드오프를 다룹니다. 사용자가 다른 언어로 쓰지 않았다면 한국어로 작성합니다.
            """;

    private final ChatClient primaryClient;
    private final ChatClient fallbackClient;

    /**
     * TechnicalAnalysisSubagent
     *
     * 📌 기술 분석용 서브에이전트를 구성합니다.
     *
     * @param primaryClient 1차 기술 분석 모델 (예: GPT)
     * @param fallbackClient 1차 실패 시 사용할 대체 모델 (예: Gemini)
     */
    public TechnicalAnalysisSubagent(
            @Qualifier("gpt") ChatClient primaryClient,
            @Qualifier("gemini") ChatClient fallbackClient) {
        this.primaryClient = primaryClient;
        this.fallbackClient = fallbackClient;
    }

    @Override
    public String name() {
        return StrategicAgentKeys.TECHNICAL_ANALYSIS;
    }

    @Override
    public String description() {
        return "기술적 관점에서 요청 주제를 분석한다.";
    }

    @Override
    public String execute(String userMessage) {
        return execute(userMessage, null);
    }

    @Override
    public String execute(String userMessage, String systemMessage) {
        String sys = systemMessage == null ? "" : systemMessage.trim();
        String effectiveSystem = sys.isEmpty() ? SYSTEM : sys;
        return callWithFallback(effectiveSystem, userMessage);
    }

    /**
     * 1차 모델 실패 시 fallback 모델로 동일 프롬프트를 재시도합니다.
     *
     * @param system      기술 분석 지침이 담긴 system 프롬프트
     * @param userMessage 사용자 입력
     * @return            기술 분석 결과 텍스트
     */
    private String callWithFallback(String system, String userMessage) {
        try {
            return primaryClient.prompt()
                    .system(system)
                    .user(userMessage)
                    .call()
                    .content();
        } catch (Exception primaryEx) {
            log.warn("technical-analysis primary model failed; fallback to gemini", primaryEx);
            return fallbackClient.prompt()
                    .system(system)
                    .user(userMessage)
                    .call()
                    .content();
        }
    }
}

