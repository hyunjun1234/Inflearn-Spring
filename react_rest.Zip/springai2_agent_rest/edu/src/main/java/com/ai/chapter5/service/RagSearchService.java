package com.ai.chapter5.service;

//import org.springframework.ai.vectorstore.SearchRequest;
//import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.stereotype.Service;

/**
 * RAG(Retrieval-Augmented Generation)를 위한 Vector Store 검색 서비스 예시.
 *
 * 교육용 예제로, 실제 ch5/ch6 워크플로에 바로 연결되지는 않으며
 * MarketAnalysisTool 등의 주석 예제에서 함께 참고하는 용도입니다.
 */
@Service
public class RagSearchService {
//
//    private final VectorStore vectorStore;
//
//    public RagSearchService(VectorStore vectorStore) {
//        this.vectorStore = vectorStore;
//    }
//
//    /**
//     * 주어진 질의에 대해 Vector Store에서 유사한 문서들을 검색하고,
//     * LLM에 바로 전달할 수 있는 텍스트 컨텍스트로 변환합니다.
//     */
//    public String searchAsContext(String query) {
//        List<Document> docs = vectorStore.similaritySearch(
//                SearchRequest.query(query).withTopK(5)
//        );
//
//        if (docs == null || docs.isEmpty()) {
//            return "관련 문서를 찾지 못했습니다.";
//        }
//
//        return docs.stream()
//                .map(doc -> """
//                        [문서 제목] %s
//                        [내용 요약] %s
//                        """.formatted(
//                        doc.getMetadata().getOrDefault("title", "제목 없음"),
//                        doc.getContent()
//                ))
//                .collect(Collectors.joining("\n\n"));
//    }
}

