package com.ai.shared.openapi;

/**
 * Swagger UI(OpenAPI) 예시 값 — {@code @Parameter(example = ...)} 에서 재사용.
 */
public final class OpenApiExamples {

    public static final String WORKFLOW_ID_UUID = "550e8400-e29b-41d4-a716-446655440000";

    /** Ch4~Ch9 strategic-analysis Swagger 예시 프롬프트 */
    public static final String PROMPT_STRATEGIC_UAM =
            "도심형 항공 모빌리티(UAM) 서비스의 국내 도입을 위한 기술적 과제와 예상 수익 모델을 분석해줘.";

    private OpenApiExamples() {}
}
