package com.ai.chapter8.ymldagengine.nodes;

import com.ai.chapter8.ymldagengine.runtime.NodeResult;
import com.ai.chapter8.ymldagengine.runtime.WorkflowContext;
import com.ai.chapter8.ymldagengine.runtime.WorkflowNode;
import com.ai.shared.agent.api.SubAgentRegistry;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Chapter 8 YAML DAG — SIMPLE 분기 단일 응답 (id: {@code simple-query-ch8}).
 */
@Component
@RequiredArgsConstructor
public class SimpleQueryCh8Node implements WorkflowNode {

    private static final String NODE_ID = "simple-query-ch8";
    private static final String AGENT_SIMPLE_QUERY = "simple-query";

    private final SubAgentRegistry subAgentRegistry;

    @Override
    public String id() {
        return NODE_ID;
    }

    @Override
    public CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            ctx.publish("SIMPLE", "단순 요청 처리 중...");
            try {
                String result = subAgentRegistry.require(AGENT_SIMPLE_QUERY).execute(ctx.getUserInput());
                ctx.setSimpleResponse(result);
                return NodeResult.ok(result);
            } catch (Exception e) {
                return NodeResult.fail("단순 요청 처리 실패: " + e.getMessage());
            }
        }, executor);
    }
}
