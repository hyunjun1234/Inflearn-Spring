package com.ai.chapter8.ymldagengine.nodes;

import com.ai.chapter8.ymldagengine.runtime.NodeResult;
import com.ai.chapter8.ymldagengine.runtime.WorkflowContext;
import com.ai.chapter8.ymldagengine.runtime.WorkflowNode;
import com.ai.shared.agent.subagent.ReportOptimizerSubagent;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Chapter 8 YAML DAG — 보고서 개선 (id: {@code report-optimizer-ch8}).
 */
@Component
@RequiredArgsConstructor
public class OptimizationCh8Node implements WorkflowNode {

    private static final String NODE_ID = "report-optimizer-ch8";

    private final ReportOptimizerSubagent reportOptimizerSubagent;

    @Override
    public String id() {
        return NODE_ID;
    }

    @Override
    public CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            int round = ctx.getEvaluationRound();
            ctx.publish("OPTIMIZING", round + "차 피드백 반영 중...");
            try {
                String updated = reportOptimizerSubagent.optimize(ctx.getCurrentReport(), ctx.getLastEvaluation());
                ctx.setCurrentReport(updated);
                return NodeResult.ok(updated);
            } catch (Exception e) {
                return NodeResult.fail("보고서 개선 실패: " + e.getMessage());
            }
        }, executor);
    }
}
