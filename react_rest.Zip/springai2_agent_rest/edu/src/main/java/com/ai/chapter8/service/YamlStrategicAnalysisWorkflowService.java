package com.ai.chapter8.service;

import com.ai.shared.publisher.WorkflowStatusPublisher;
import com.ai.chapter8.ymldagengine.runtime.WorkflowContext;
import com.ai.chapter8.ymldagengine.runtime.YamlDagWorkflowEngine;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * YamlStrategicAnalysisWorkflowService
 *
 * 📌 Chapter 8 — YAML 기반 DAG 워크플로 진입 서비스 (HTTP → YAML 엔진)
 *
 * 아키텍처 개요:
 * 1️⃣ 본 클래스 — {@link WorkflowContext} 조립 후 {@link YamlDagWorkflowEngine#run(String, WorkflowContext)} 호출
 * 2️⃣ {@link YamlDagWorkflowEngine} — YAML로 정의된 워크플로(id 기준)를 읽어 노드 그래프 실행
 *
 * 역할:
 * - 컨트롤러가 호출하는 유일한 서비스 진입점(동기 결과 반환)
 * - {@link WorkflowContext}에 workflowId·사용자 입력·{@link WorkflowStatusPublisher} 주입
 *
 * 특징:
 * - 엔진 내부는 {@link java.util.concurrent.CompletableFuture} 비동기 체인
 * - 본 클래스는 {@code join()}으로 최종 문자열을 동기 반환 (ch4~ch7 API와 동일 계약)
 * - 전략 분석 YAML의 routing 핸들러는 {@link com.ai.chapter8.ymldagengine.nodes.RoutingCh8Node}({@code routing-ch8})이며,
 *   동일 입력(trim)에 대한 SIMPLE/STRATEGIC 분류는 해당 빈의 인메모리 캐시로 재사용됩니다.
 */
@Service
@Slf4j
public class YamlStrategicAnalysisWorkflowService {

    private final YamlDagWorkflowEngine yamlDagWorkflowEngine;
    private final WorkflowStatusPublisher statusPublisher;

    public YamlStrategicAnalysisWorkflowService(
            @Qualifier("ch8Engine") YamlDagWorkflowEngine yamlDagWorkflowEngine,
            WorkflowStatusPublisher statusPublisher
    ) {
        this.yamlDagWorkflowEngine = yamlDagWorkflowEngine;
        this.statusPublisher = statusPublisher;
    }

    /**
     * executeWithMonitoring
     *
     * 📌 YAML로 정의된 전략 분석 워크플로(id 기준)를 실행하고, 최종 문자열을 동기 반환합니다.
     *
     * @param workflowId  SSE/Redis와 매칭되는 추적용 UUID
     * @param workflowDefinitionId 실행할 YAML 워크플로 정의 id (예: {@code strategic-analysis})
     * @param input       사용자 프롬프트
     * @return            최종 보고서 또는 오류 메시지 문자열
     */
    public String executeWithMonitoring(UUID workflowId, String workflowDefinitionId, String input) {
        WorkflowContext ctx = new WorkflowContext(workflowId, input, statusPublisher);
        try {
            return yamlDagWorkflowEngine.run(workflowDefinitionId, ctx).join();
        } catch (Exception e) {
            log.error("[{}] YAML DAG 워크플로우 실패 (definitionId={})", workflowId, workflowDefinitionId, e);
            ctx.publish("ERROR", "YAML DAG 워크플로우 실행 실패");
            return "YAML DAG 워크플로우 실행 실패: " + e.getMessage();
        }
    }
}

