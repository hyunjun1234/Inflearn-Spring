package com.ai.chapter7.dagengine.core;

/**
 * NodeResult
 *
 * 📌 단일 {@link WorkflowNode} 실행 결과를 담는 값 객체
 *
 * 필드:
 * - success — 논리적 성공 여부 (예외 없이 비즈니스 룰을 만족했는지)
 * - skipped — 현재 분기에서 이 노드를 실행하지 않은 경우(예: 향후 확장용, 현재는 거의 미사용)
 * - payload — 성공 시 부가 문자열 (라우팅 결과 등)
 * - errorMessage — 실패 시 사유
 */
public record NodeResult(boolean success, boolean skipped, String payload, String errorMessage) {

    /** 정상 완료 + 결과 문자열 */
    public static NodeResult ok(String payload) {
        return new NodeResult(true, false, payload, null);
    }

    /** 예외 또는 검증 실패 */
    public static NodeResult fail(String errorMessage) {
        return new NodeResult(false, false, null, errorMessage);
    }

    /**
     * 이 노드는 현재 분기에서 실행하지 않음
     * (record 컴포넌트 {@code skipped}와 이름 충돌을 피하기 위해 {@code notRun}으로 명명)
     */
    public static NodeResult notRun() {
        return new NodeResult(true, true, null, null);
    }
}
