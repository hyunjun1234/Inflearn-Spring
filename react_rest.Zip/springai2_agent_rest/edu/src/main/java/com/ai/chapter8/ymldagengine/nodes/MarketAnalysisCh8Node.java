package com.ai.chapter8.ymldagengine.nodes;

import com.ai.chapter8.ymldagengine.runtime.NodeResult;
import com.ai.chapter8.ymldagengine.runtime.WorkflowContext;
import com.ai.chapter8.ymldagengine.runtime.WorkflowNode;
import com.ai.shared.agent.api.SubAgentRegistry;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Chapter 8 YAML DAG — 시장 분석 (id: {@code market-analysis-ch8}).
 */
@Component
@RequiredArgsConstructor
public class MarketAnalysisCh8Node implements WorkflowNode {

    private static final String NODE_ID = "market-analysis-ch8";
    private static final String AGENT_MARKET_ANALYSIS = "market-analysis";

    private final SubAgentRegistry subAgentRegistry;

    @Override
    public String id() {
        return NODE_ID;
    }

    @Override
    public CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            ctx.publish("MARKET", "시장 관점 분석 중...");
            try {
                String market = subAgentRegistry.require(AGENT_MARKET_ANALYSIS).execute(ctx.getUserInput());
                ctx.setMarketAnalysis(market);
                return NodeResult.ok(market);
            } catch (Exception e) {
                ctx.setMarketAnalysis("시장 분석 실패");
                return NodeResult.ok("시장 분석 실패");
            }
        }, executor);
    }
}
