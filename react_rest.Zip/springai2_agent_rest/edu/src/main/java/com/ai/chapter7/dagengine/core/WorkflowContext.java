package com.ai.chapter7.dagengine.core;

import com.ai.shared.publisher.WorkflowStatusPublisher;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.util.UUID;

/**
 * WorkflowContext
 *
 * 📌 DAG 실행 동안 노드 간에 공유되는 가변 컨텍스트
 *
 * 역할:
 * - {@link java.util.UUID} 기준으로 Redis Pub/Sub 상태 발행
 * - Router 이후 분기 결과·병렬 분석 결과·초안·평가문을 누적 저장
 * - {@link DagWorkflowEngine}이 다음 노드에 전달할 입력을 여기서 읽음
 *
 * 주의:
 * - 한 HTTP 요청(또는 한 워크플로 실행)당 인스턴스 1개를 생성하는 것을 전제로 함
 */
@Getter
@Setter
@Slf4j
public class WorkflowContext {

    /** SSE/Redis와 동일한 워크플로 식별자 */
    private final UUID workflowId;
    /** 사용자 원문 요청 */
    private final String userInput;
    /** 단계별 상태를 UI로 전달하기 위한 발행기 */
    private final WorkflowStatusPublisher statusPublisher;

    /** Router 노드 결과: `SIMPLE` / `STRATEGIC` 등 (대소문자 무관 비교) */
    private String routeCategory;
    /** SIMPLE 분기 시 최종 응답 */
    private String simpleResponse;
    /** STRATEGIC: 기술 분석 출력 */
    private String technicalAnalysis;
    /** STRATEGIC: 시장 분석 출력 */
    private String marketAnalysis;
    /**
     * Merge 이후 평가/최적화가 갱신하는 현재 보고서 본문.
     * Evaluator-Optimizer 루프에서 반복 갱신됨.
     */
    private String currentReport;
    /** 직전 Evaluation 노드 출력 (Optimizer 입력) */
    private String lastEvaluation;
    /**
     * Evaluation / Optimization 노드 로그 메시지에 붙는 회차 (1~4)
     * — 엔진의 {@link DagWorkflowEngine#runEvaluatorOptimizerLoop}에서 설정
     */
    private int evaluationRound;

    /**
     * WorkflowContext
     *
     * 📌 단일 DAG 실행(단일 HTTP 요청)에 사용될 컨텍스트를 생성합니다.
     *
     * @param workflowId        SSE/Redis와 매칭되는 워크플로 ID
     * @param userInput         사용자 원문 입력
     * @param statusPublisher   단계별 상태를 발행할 퍼블리셔
     */
    public WorkflowContext(UUID workflowId, String userInput, WorkflowStatusPublisher statusPublisher) {
        this.workflowId = workflowId;
        this.userInput = userInput;
        this.statusPublisher = statusPublisher;
    }

    /**
     * Redis Pub/Sub으로 상태 발행 (실패 시 로그만 남기고 흐름은 유지)
     */
    public void publish(String step, String message) {
        try {
            statusPublisher.publishStatus(workflowId, step, message);
        } catch (Exception ex) {
            log.warn("[{}] 상태 발행 실패", workflowId, ex);
        }
    }
}
