package com.ai.chapter6.service;

import com.ai.shared.publisher.WorkflowStatusPublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * StrategicAnalysisAgentToolTaskMDService
 *
 * 📌 Chapter 6 — strategic-analysis-agent-system.md 기반 TaskTool 에이전트 실행 서비스
 *
 * 아키텍처 개요:
 * - {@link org.springaicommunity.agent.tools.task.TaskTool} + strategic-*.md 서브에이전트
 * - {@link org.springaicommunity.agent.tools.TodoWriteTool} 로 진행 단계 표시
 * - 최상위 system prompt 는 {@code classpath:/prompts/strategic-analysis-agent-system.md}
 * - 워크플로 세부 플로우는 md(system prompt)에 정의하고, Java는 "진입/모니터링 래퍼" 역할만 수행
 *
 * workflowId 전달 규칙:
 * - 본 클래스는 진입 경계에서 md 기반 오케스트레이터를 호출하고,
 *   상태 변경은 {@link WorkflowStatusPublisher} 를 통해 SSE 로 전달합니다.
 * - md 안에서 TodoWrite를 적절히 호출한다고 가정하며,
 *   이 예제에서는 ThreadLocal 연동 없이 단순히 workflowId와 상태만 발행합니다.
 */
@Service
@Slf4j
public class StrategicAnalysisAgentToolTaskMDService {

    private final StrategicAnalysisTaskToolMDOrchestrator orchestrator;
    private final WorkflowStatusPublisher statusPublisher;

    /**
     * StrategicAnalysisAgentToolTaskMDService
     *
     * 📌 MD(system prompt) 기반 TaskTool 오케스트레이터와 상태 퍼블리셔를 주입받는 생성자입니다.
     *
     * @param orchestrator    md 기반 전략 분석 TaskTool 오케스트레이터
     * @param statusPublisher SSE/Redis 상태 발행 컴포넌트
     */
    public StrategicAnalysisAgentToolTaskMDService(
            StrategicAnalysisTaskToolMDOrchestrator orchestrator,
            WorkflowStatusPublisher statusPublisher) {
        this.orchestrator = orchestrator;
        this.statusPublisher = statusPublisher;
    }

    /**
     * md 기반 TaskTool 에이전트를 실행하고 SSE 와 workflowId 를 연동하는 진입 메서드입니다.
     *
     * @param workflowId 상태 추적용 UUID (클라이언트가 생성)
     * @param input      사용자 프롬프트
     * @return           에이전트 최종 응답 문자열
     */
    public String executeWithMonitoring(UUID workflowId, String input) {
        log.info("[{}] MD 워크플로우 시작 (agent-md)", workflowId);
        publishStatus(workflowId, "STARTED_MD", "MD 기반 워크플로우가 시작되었습니다.");

        try {
            publishStatus(workflowId, "AGENT_MD", "MD 기반 에이전트 오케스트레이션 실행 중...");
            String result = orchestrator.executeWithMonitoring(workflowId, input);

            publishStatus(workflowId, "COMPLETED_MD", "MD 기반 에이전트 실행 완료");
            return result;
        } catch (Exception e) {
            log.error("[{}] MD Agent 실행 실패: {}", workflowId, e.getMessage(), e);
            publishStatus(workflowId, "ERROR_MD", "MD 기반 에이전트 실행 실패");
            return "MD 기반 에이전트 실행 실패: " + e.getMessage();
        }
    }

    /**
     * publishStatus
     *
     * 📌 MD 기반 전략 분석 경로에서 상태를 Redis/SSE로 발행하는 헬퍼 메서드입니다.
     *
     * 기능:
     * - MD 전용 단계 태그(예: {@code STARTED_MD}, {@code AGENT_MD})와 함께 현재 상태를 기록합니다.
     * - 상태 발행이 실패하더라도 워크플로 자체는 계속 진행되도록, 예외를 경고 로그로만 처리합니다.
     *
     * @param workflowId 워크플로우 추적용 UUID
     * @param step       단계 코드 (예: {@code STARTED_MD}, {@code COMPLETED_MD}, {@code ERROR_MD})
     * @param message    UI·운영자용 설명 메시지
     */
    private void publishStatus(UUID workflowId, String step, String message) {
        log.info("[{}] 상태 업데이트(MD): {} - {}", workflowId, step, message);
        try {
            statusPublisher.publishStatus(workflowId, step, message);
        } catch (Exception ex) {
            log.warn("[{}] 상태 발행 실패(MD)", workflowId, ex);
        }
    }
}

