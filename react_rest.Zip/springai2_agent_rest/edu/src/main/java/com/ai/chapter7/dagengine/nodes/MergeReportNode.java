package com.ai.chapter7.dagengine.nodes;

import com.ai.chapter7.dagengine.core.NodeResult;
import com.ai.chapter7.dagengine.core.WorkflowContext;
import com.ai.chapter7.dagengine.core.WorkflowNode;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * MergeReportNode
 *
 * 📌 STRATEGIC 경로 — 병렬(Technical + Market) 산출물을 하나의 초안 문자열로 병합
 *
 * 아키텍처 개요:
 * 1️⃣ Technical/Market 노드 완료 후 실행
 * 2️⃣ 출력 형식: {@code 기술분석: ...\n시장분석: ...} (Chapter 4 오케스트레이터와 동일 취지)
 * 3️⃣ {@link WorkflowContext#setCurrentReport(String)} → Eval/Optimize 루프 입력
 *
 * 특징:
 * - 외부 LLM 호출 없음 (순수 조합 노드)
 */
@Component
public class MergeReportNode implements WorkflowNode {

    @Override
    public String id() {
        return "merge-report";
    }

        /**
         * execute
         *
         * 📌 기술/시장 분석 결과를 하나의 초안 보고서 문자열로 결합합니다.
         *
         * 동작:
         * - {@link WorkflowContext#getTechnicalAnalysis()}와 {@link WorkflowContext#getMarketAnalysis()}를 읽어
         *   {@code "기술분석: ...\n시장분석: ..."} 형식의 문자열을 생성합니다.
         * - 둘 다 비어 있으면 실패로 간주하고 {@link NodeResult#fail(String)}을 반환합니다.
         *
         * @param ctx      현재 워크플로 컨텍스트
         * @param executor 실행에 사용할 스레드 풀
         * @return         통합 초안 문자열을 담은 {@link NodeResult}
         */
    @Override
    public CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            ctx.publish("DRAFTING", "분석 결과를 초안 보고서로 통합 중...");
            String tech = ctx.getTechnicalAnalysis();
            String market = ctx.getMarketAnalysis();
            if (tech == null && market == null) {
                return NodeResult.fail("통합할 기술/시장 분석 결과가 없습니다.");
            }
            String draft = "기술분석: " + tech + "\n시장분석: " + market;
            ctx.setCurrentReport(draft);
            return NodeResult.ok(draft);
        }, executor);
    }
}
