package com.ai.shared.agent.subagent;

import com.ai.shared.agent.api.SubAgent;
import com.ai.shared.agent.keys.StrategicAgentKeys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * RoutingSubagent
 *
 * 📌 Chapter 4~6 공통으로 사용하는 “요청 라우팅” 서브에이전트입니다.
 *
 * 개념:
 * - 사용자 입력을 읽고, 이 요청을 <b>SIMPLE</b>로 처리할지,
 *   아니면 <b>STRATEGIC</b> 전략 분석 파이프라인으로 보낼지를 결정합니다.
 * - Multi-LLM 구조에서 <b>가장 가벼운 모델</b>을 사용해 1차 분기만 수행하고,
 *   실제 분석은 뒤 단계의 SubAgent/Tool/DAG 노드가 담당합니다.
 *
 * 모델:
 * - {@link Qualifier @Qualifier("llama")} — 비용·지연을 고려한 경량 분류에 사용 (1차)
 * - {@link Qualifier @Qualifier("gpt")} — Llama 호출 실패 시 동일 프롬프트로 재시도
 *
 * 레지스트리 키:
 * - {@link #name()} → {@code "routing"}
 *   - Chapter 4 SubAgentRegistry, Chapter 5 ToolRegistry, Chapter 6 TaskTool 모두
 *     이 문자열을 기준으로 라우팅 역할을 찾습니다.
 *
 * 출력:
 * - 프롬프트에 따라 {@code SIMPLE} 또는 {@code STRATEGIC} 등 문자열 (대소문자 무관 비교)
 * - 오케스트레이션 계층에서는 이 값을 기준으로
 *   “ch3 스타일 단일 답변” vs “멀티 단계 분석 파이프라인”을 선택합니다.
 */
@Component
@Slf4j
public class RoutingSubagent implements SubAgent {

    private static final String ROUTING_SYSTEM = """
            당신은 라우터입니다. 사용자 메시지를 읽고 정확히 한 단어만 출력하세요. **SIMPLE** 또는 **STRATEGIC** 중 하나입니다.
            **STRATEGIC**: 구조화된 비즈니스·수익모델, 기술적 과제, 비교, 로드맵, 기술+시장 통합 인사이트가 필요할 때 사용합니다.
            **SIMPLE**: 인사 및 안부 관련 질문 등 공식 보고서가 불필요할 때 사용합니다.
            
            우선순위 규칙:
            - 아래 표현이 있으면 기본적으로 STRATEGIC을 선택합니다:
              분석, 비교, 전략, 로드맵, 기술적 과제, 도입 방안, 수익 모델, 시장성, 사업성, 리스크, 전망, 인사이트
            - "분석해줘", "정리해줘", "평가해줘"처럼 보고서/검토 의도가 보이면 STRATEGIC입니다.
            - 인사/안부/가벼운 대화(예: 안녕, 고마워, 오늘 어때?)만 SIMPLE입니다.
            - 애매하면 STRATEGIC을 선택합니다.
            
            예시:
            - "도심형 항공 모빌리티(UAM) 서비스의 국내 도입을 위한 기술적 과제와 예상 수익 모델을 분석해줘" -> STRATEGIC
            - "안녕? 오늘 날씨 어때?" -> SIMPLE
            
            출력 규칙:
            - `SIMPLE` 또는 `STRATEGIC`만 출력합니다(부호·설명 없음).
            """;

    private final ChatClient primaryClient;
    private final ChatClient fallbackClient;

    /**
     * RoutingSubagent
     *
     * 📌 라우팅 전용 서브에이전트를 구성합니다.
     *
     * @param llamaClient Llama 기반 1차 분류 모델
     * @param gptClient   Llama 호출 실패 시 사용할 GPT fallback 모델
     */
    public RoutingSubagent(
            @Qualifier("llama") ChatClient llamaClient,
            @Qualifier("gpt") ChatClient gptClient) {
        this.primaryClient = llamaClient;
        this.fallbackClient = gptClient;
    }

    @Override
    public String name() {
        return StrategicAgentKeys.ROUTING;
    }

    @Override
    public String description() {
        return "사용자 요청을 SIMPLE(단순) 또는 STRATEGIC(전략 분석)으로 분류한다.";
    }

    @Override
    public String execute(String userMessage) {
        return execute(userMessage, null);
    }

    @Override
    public String execute(String userMessage, String systemMessage) {
        String sys = systemMessage == null ? "" : systemMessage.trim();
        String effectiveSystem = sys.isEmpty() ? ROUTING_SYSTEM : sys;
        return callWithFallback(effectiveSystem, userMessage);
    }

    /**
     * 1차 모델(Llama) 실패 시 동일 system·user로 GPT를 재시도합니다.
     *
     * @param system      라우팅 지침이 담긴 system 프롬프트
     * @param userMessage 사용자 입력
     * @return            SIMPLE 또는 STRATEGIC 문자열
     */
    private String callWithFallback(String system, String userMessage) {
        String safeUser = userMessage == null ? "" : userMessage;
        try {
            return primaryClient.prompt()
                    .system(system)
                    .user(safeUser)
                    .call()
                    .content()
                    .trim();
        } catch (Exception primaryEx) {
            log.warn("routing primary model (llama) failed; fallback to gpt", primaryEx);
            return fallbackClient.prompt()
                    .system(system)
                    .user(safeUser)
                    .call()
                    .content()
                    .trim();
        }
    }
}

