package com.ai.chapter2.controller;

import com.ai.chapter2.service.*;
import com.ai.shared.web.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Chapter 2. AI Workflow Controller
 *
 * 다양한 AI Workflow 패턴을 HTTP API 형태로 제공하는 컨트롤러
 *
 * - Chain Workflow (순차 실행)
 * - Parallel Workflow (병렬 실행)
 * - Routing Workflow (조건 기반 분기)
 * - Orchestrator Workers (오케스트레이션 패턴)
 * - Evaluator Optimizer (평가-개선 루프)
 */
@RestController
@RequestMapping("/ch2")   // 공통 URL Prefix
@Slf4j                    // Logger 자동 생성 (log 객체)
@RequiredArgsConstructor  // final 필드에 대한 생성자 자동 생성 (DI)
public class Ch2Controller {

    /**
     * 순차적(Chain) Workflow 처리 서비스
     * 여러 단계를 순서대로 실행하는 패턴
     */
    private final ChainWorkflowService chainWorkflowService;

    /**
     * 병렬(Parallel) Workflow 처리 서비스
     * 여러 AI 작업을 동시에 실행하고 결과를 통합
     */
    private final ParallelWorkflowService parallelWorkflowService;

    /**
     * 라우팅(Routing) Workflow 처리 서비스
     * 입력 내용에 따라 다른 모델/로직으로 분기 처리
     */
    private final RoutingWorkflowService routingWorkflowService;

    /**
     * Orchestrator 패턴 서비스
     * 중앙 오케스트레이터가 여러 Worker를 조합하여 복합 작업 수행
     */
    private final OrchestratorService orchestratorService;

    /**
     * 평가-최적화(Evaluator-Optimizer) Workflow 서비스
     * AI 결과를 평가하고 개선하는 반복 루프 패턴
     */
    private final EvaluationWorkflowService evaluationWorkflowService;


    // ==============================================================
    // 1. Chain Workflow (Sequential Processing)
    // ==============================================================

    /**
     * 순차적 AI 처리 Workflow
     *
     * Step1 → Step2 → Step3 순서대로 실행
     *
     * @param userPrompt 사용자 입력 프롬프트
     * @return 최종 AI 처리 결과 문자열
     */
    @PostMapping("/chain-workflow")
    public ResponseEntity<String> chainWorkFlow(@RequestParam("prompt") String userPrompt) {

        // 입력 로그 기록
        log.info("Chain Workflow Request: {}", userPrompt);

        // 순차 Workflow 실행
        return ApiResponses.textPlainOk(chainWorkflowService.executeWorkflow(userPrompt));
    }


    // ==============================================================
    // 2. Parallel Workflow (Concurrent Processing)
    // ==============================================================

    /**
     * 병렬 AI 분석 Workflow
     *
     * 여러 분석 작업을 동시에 수행 후 결과 통합
     *
     * @param userPrompt 사용자 입력 프롬프트
     * @return 병렬 분석 결과 객체 (AnalysisResult)
     */
    @PostMapping("/parallel-workflow")
    public ResponseEntity<ParallelWorkflowService.AnalysisResult> parallelWorkFlow(
            @RequestParam("prompt") String userPrompt) {

        // 입력 로그 기록
        log.info("Parallel Workflow Request: {}", userPrompt);

        // 병렬 Workflow 실행
        return ApiResponses.jsonOk(parallelWorkflowService.executeParallelWorkflow(userPrompt));
    }


    // ==============================================================
    // 3. Routing Workflow (Conditional Branching)
    // ==============================================================

    /**
     * 입력 내용에 따라 다른 모델/로직으로 분기 처리
     *
     * 예:
     * - 기술 질문 → Tech Model
     * - 마케팅 질문 → Marketing Model
     *
     * @param userPrompt 사용자 입력 프롬프트
     * @return 라우팅 후 처리 결과
     */
    @PostMapping("/routing-workflow")
    public ResponseEntity<String> routingWorkFlow(@RequestParam("prompt") String userPrompt) {

        // 입력 로그 기록
        log.info("Routing Workflow Request: {}", userPrompt);

        // 라우팅 실행
        return ApiResponses.textPlainOk(routingWorkflowService.executeRouting(userPrompt));
    }


    // ==============================================================
    // 4. Orchestrator-Workers Pattern
    // ==============================================================

    /**
     * 오케스트레이터 패턴
     *
     * 중앙 Orchestrator가 여러 Worker를 제어하여
     * 복합적인 AI 작업을 수행
     *
     * @param userPrompt 사용자 입력 프롬프트
     * @return 복합 작업 수행 결과
     */
    @PostMapping("/orchestrator-workers")
    public ResponseEntity<String> orchestratorWorkers(@RequestParam("prompt") String userPrompt) {

        // 입력 로그 기록
        log.info("Orchestrator Workflow Request: {}", userPrompt);

        // 복합 작업 실행
        return ApiResponses.textPlainOk(orchestratorService.executeComplexTask(userPrompt));
    }


    // ==============================================================
    // 5. Evaluator-Optimizer Loop
    // ==============================================================

    /**
     * 평가 → 개선 반복 루프 Workflow
     *
     * 1. AI 결과 생성
     * 2. 평가 모델이 결과 평가
     * 3. 부족하면 개선
     * 4. 반복 수행
     *
     * @param userPrompt 사용자 입력 프롬프트
     * @return 최적화된 결과
     */
    @PostMapping("/evaluator-optimizer")
    public ResponseEntity<String> evaluatorOptimizer(@RequestParam("prompt") String userPrompt) {

        // 입력 로그 기록
        log.info("Evaluator-Optimizer Request: {}", userPrompt);

        // 평가-최적화 루프 실행
        return ApiResponses.textPlainOk(evaluationWorkflowService.executeOptimizerLoop(userPrompt));
    }
}

