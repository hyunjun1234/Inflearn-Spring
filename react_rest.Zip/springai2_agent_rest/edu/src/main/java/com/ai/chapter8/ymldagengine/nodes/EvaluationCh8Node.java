package com.ai.chapter8.ymldagengine.nodes;

import com.ai.chapter8.ymldagengine.runtime.NodeResult;
import com.ai.chapter8.ymldagengine.runtime.WorkflowContext;
import com.ai.chapter8.ymldagengine.runtime.WorkflowNode;
import com.ai.shared.agent.api.SubAgentRegistry;
import com.ai.shared.util.EvaluationApprovalDecider;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Chapter 8 YAML DAG — 보고서 평가 (id: {@code report-evaluator-ch8}).
 */
@Component
@RequiredArgsConstructor
public class EvaluationCh8Node implements WorkflowNode {

    private static final String NODE_ID = "report-evaluator-ch8";
    private static final String AGENT_REPORT_EVALUATOR = "report-evaluator";

    private final SubAgentRegistry subAgentRegistry;

    @Override
    public String id() {
        return NODE_ID;
    }

    @Override
    public CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            int round = ctx.getEvaluationRound();
            ctx.publish("EVALUATING", round + "차 품질 평가 중...");
            try {
                String evaluation = subAgentRegistry.require(AGENT_REPORT_EVALUATOR).execute(ctx.getCurrentReport());
                ctx.setLastEvaluation(evaluation);
                Integer score = EvaluationApprovalDecider.extractScore(evaluation);
                if (score != null) {
                    ctx.publish("EVALUATION_SCORE", round + "차 평가 점수: " + score + "점");
                } else {
                    ctx.publish("EVALUATION_SCORE", round + "차 평가 점수: 추출 실패");
                }
                return NodeResult.ok(evaluation);
            } catch (Exception e) {
                return NodeResult.fail("평가 실패: " + e.getMessage());
            }
        }, executor);
    }
}
