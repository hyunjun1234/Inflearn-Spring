package com.ai.chapter8.ymldagengine.nodes;

import com.ai.chapter8.ymldagengine.runtime.NodeResult;
import com.ai.chapter8.ymldagengine.runtime.WorkflowContext;
import com.ai.chapter8.ymldagengine.runtime.WorkflowNode;
import com.ai.shared.agent.api.SubAgentRegistry;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Chapter 8 YAML DAG — 기술 분석 (id: {@code technical-analysis-ch8}).
 */
@Component
@RequiredArgsConstructor
public class TechnicalAnalysisCh8Node implements WorkflowNode {

    private static final String NODE_ID = "technical-analysis-ch8";
    private static final String AGENT_TECHNICAL_ANALYSIS = "technical-analysis";

    private final SubAgentRegistry subAgentRegistry;

    @Override
    public String id() {
        return NODE_ID;
    }

    @Override
    public CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            ctx.publish("TECH", "기술 관점 분석 중...");
            try {
                String tech = subAgentRegistry.require(AGENT_TECHNICAL_ANALYSIS).execute(ctx.getUserInput());
                ctx.setTechnicalAnalysis(tech);
                return NodeResult.ok(tech);
            } catch (Exception e) {
                ctx.setTechnicalAnalysis("기술 분석 실패");
                return NodeResult.ok("기술 분석 실패");
            }
        }, executor);
    }
}
