package com.ai.chapter8.ymldagengine.runtime;

import com.ai.shared.publisher.WorkflowStatusPublisher;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.util.UUID;

/**
 * WorkflowContext (ch8)
 *
 * 📌 Chapter 8 YAML DAG 전용 실행 컨텍스트
 *
 * <p>Chapter 7 {@link com.ai.chapter7.dagengine.core.WorkflowContext} 타입을 <strong>참조하지 않고</strong>,
 * 동일한 필드와 {@link #publish(String, String)} 계약을 이 클래스 안에 독립적으로 둡니다.</p>
 *
 * <p>YAML DAG 경로에서는 {@code com.ai.chapter8.ymldagengine.nodes} 의 노드가
 * 이 타입만 사용합니다({@link com.ai.chapter8.ymldagengine.registry.WorkflowNodeRegistry}에 등록).</p>
 */
@Getter
@Setter
@Slf4j
public class WorkflowContext {

    /** SSE/Redis와 동일한 워크플로 식별자 */
    private final UUID workflowId;
    /** 사용자 원문 요청 */
    private final String userInput;
    /** 단계별 상태를 UI로 전달하기 위한 발행기 */
    private final WorkflowStatusPublisher statusPublisher;

    /** Router 노드 결과: {@code SIMPLE} / {@code STRATEGIC} 등 (대소문자 무관 비교) */
    private String routeCategory;
    /** SIMPLE 분기 시 최종 응답 */
    private String simpleResponse;
    /** STRATEGIC: 기술 분석 출력 */
    private String technicalAnalysis;
    /** STRATEGIC: 시장 분석 출력 */
    private String marketAnalysis;
    /**
     * Merge 이후 평가/최적화가 갱신하는 현재 보고서 본문.
     * Evaluator-Optimizer 루프에서 반복 갱신됨.
     */
    private String currentReport;
    /** 직전 Evaluation 노드 출력 (Optimizer 입력) */
    private String lastEvaluation;
    /**
     * Evaluation / Optimization 노드 로그 메시지에 붙는 회차 (1~4)
     */
    private int evaluationRound;

    /**
     * @param workflowId      SSE/Redis와 매칭되는 워크플로 ID
     * @param userInput       사용자 원문 입력
     * @param statusPublisher 단계별 상태를 발행할 퍼블리셔
     */
    public WorkflowContext(UUID workflowId, String userInput, WorkflowStatusPublisher statusPublisher) {
        this.workflowId = workflowId;
        this.userInput = userInput;
        this.statusPublisher = statusPublisher;
    }

    /**
     * Redis Pub/Sub으로 상태 발행 (실패 시 로그만 남기고 흐름은 유지)
     */
    public void publish(String step, String message) {
        try {
            statusPublisher.publishStatus(workflowId, step, message);
        } catch (Exception ex) {
            log.warn("[{}] 상태 발행 실패", workflowId, ex);
        }
    }
}
