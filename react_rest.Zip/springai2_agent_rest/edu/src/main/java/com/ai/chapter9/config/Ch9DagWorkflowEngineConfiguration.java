package com.ai.chapter9.config;

import com.ai.chapter8.ymldagengine.definition.WorkflowDefinitionLoader;
import com.ai.chapter8.ymldagengine.registry.WorkflowNodeRegistry;
import com.ai.chapter8.ymldagengine.runtime.YamlDagWorkflowEngine;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Chapter 9. Validated Agent Workflow DSL — {@link YamlDagWorkflowEngine}에 검증 로더({@code chapter9Loader})를 주입합니다.
 * <p>
 * 엔진 클래스는 Chapter 8과 동일하고, 차이는 로더가 {@code chapter9/dagworkflow/} YAML을 검증 통과분만 캐시한다는 점입니다.
 * {@link WorkflowNodeRegistry} 는 Chapter 8과 동일한 컴포넌트를 재사용합니다.
 */
@Configuration
public class Ch9DagWorkflowEngineConfiguration {

    @Bean
    @Qualifier("ch9Engine")
    public YamlDagWorkflowEngine yamlDagWorkflowEngineCh9(
            @Qualifier("chapter9Loader") WorkflowDefinitionLoader chapter9Loader,
            WorkflowNodeRegistry workflowNodeRegistry
    ) {
        return new YamlDagWorkflowEngine(chapter9Loader, workflowNodeRegistry);
    }
}
