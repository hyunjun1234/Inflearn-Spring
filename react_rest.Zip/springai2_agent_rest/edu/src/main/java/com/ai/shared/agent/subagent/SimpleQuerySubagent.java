package com.ai.shared.agent.subagent;

import com.ai.shared.agent.api.SubAgent;
import com.ai.shared.agent.keys.StrategicAgentKeys;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * SimpleQuerySubagent
 *
 * 📌 SIMPLE 분기 전용 서브에이전트 — “보고서 수준 분석”까지 가지 않고,
 *    사용자의 일상적인 질문에 바로 답을 주는 가벼운 경로입니다.
 *
 * 개념:
 * - ch4~ch6 전체 파이프라인에서, Routing 결과가 SIMPLE 이면
 *   기술/시장 분석, 평가/최적화 같은 단계는 모두 건너뛰고
 *   이 서브에이전트 하나로 답변을 마무리합니다.
 * - 내부 워크플로(라우팅, Task, Tool 등)는 언급하지 않고
 *   “일반 챗봇 답변”에 가깝게 동작합니다.
 *
 * 모델:
 * - {@link Qualifier @Qualifier("llama")} — 라우터와 동일 계열로 일관성 유지 (프로젝트 설정에 따름)
 *
 * 레지스트리 키:
 * - {@code "simple-query"}
 *
 * 호출 조건:
 * - {@link RoutingSubagent} 결과가 SIMPLE 일 때만 오케스트레이션에서 호출됩니다.
 */
@Component
public class SimpleQuerySubagent implements SubAgent {

    private static final String SYSTEM = """
            당신은 도움이 되는 어시스턴트입니다. 사용자 메시지에 명확하고 간결하게 답하세요. 라우팅이나 내부 워크플로는 언급하지 마세요.
            """;

    private final ChatClient llamaClient;

    /**
     * SimpleQuerySubagent
     *
     * 📌 SIMPLE 분기용 서브에이전트를 구성합니다.
     *
     * @param llamaClient 간단 응답 생성을 담당하는 Llama 클라이언트
     */
    public SimpleQuerySubagent(@Qualifier("llama") ChatClient llamaClient) {
        this.llamaClient = llamaClient;
    }

    @Override
    public String name() {
        return StrategicAgentKeys.SIMPLE_QUERY;
    }

    @Override
    public String description() {
        return "분류 결과가 SIMPLE인 요청에 대해 별도 심층 분석 없이 직접 답변한다.";
    }

    @Override
    public String execute(String userMessage) {
        return execute(userMessage, null);
    }

    @Override
    public String execute(String userMessage, String systemMessage) {
        String sys = systemMessage == null ? "" : systemMessage.trim();
        String effectiveSystem = sys.isEmpty() ? SYSTEM : sys;
        return llamaClient.prompt()
                .system(effectiveSystem)
                .user(userMessage)
                .call()
                .content();
    }
}

