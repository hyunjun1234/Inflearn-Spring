package com.ai.chapter8.ymldagengine.nodes;

import com.ai.chapter8.ymldagengine.runtime.NodeResult;
import com.ai.chapter8.ymldagengine.runtime.WorkflowContext;
import com.ai.chapter8.ymldagengine.runtime.WorkflowNode;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Chapter 8 YAML DAG — 기술/시장 결과 병합 (id: {@code merge-report-ch8}).
 */
@Component
public class MergeReportCh8Node implements WorkflowNode {

    private static final String NODE_ID = "merge-report-ch8";

    @Override
    public String id() {
        return NODE_ID;
    }

    @Override
    public CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            ctx.publish("DRAFTING", "분석 결과를 초안 보고서로 통합 중...");
            String tech = ctx.getTechnicalAnalysis();
            String market = ctx.getMarketAnalysis();
            if (tech == null && market == null) {
                return NodeResult.fail("통합할 기술/시장 분석 결과가 없습니다.");
            }
            String draft = "기술분석: " + tech + "\n시장분석: " + market;
            ctx.setCurrentReport(draft);
            return NodeResult.ok(draft);
        }, executor);
    }
}
