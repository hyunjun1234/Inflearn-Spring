package com.ai.chapter2.service;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.concurrent.*;

/**
 * ParallelWorkflowService
 *
 * 여러 AI 모델(ChatClient)을 병렬로 호출하여
 * 1) 기술 분석
 * 2) 시장 분석
 * 3) 글로벌 분석
 * 을 동시에 수행한 뒤,
 * 최종적으로 종합 리포트를 생성하는 서비스 클래스.
 *
 * 병렬 처리 + 타임아웃 + 예외 처리 + 로깅을 포함한 실무형 구현.
 */
@Slf4j
@Service
public class ParallelWorkflowService {

    /**
     * LLaMA 모델용 ChatClient
     * - 기술적 구현 가능성 분석에 사용
     */
    private final ChatClient llamaClient;

    /**
     * GPT 모델용 ChatClient
     * - 시장 분석 및 최종 종합 보고서 작성에 사용
     */
    private final ChatClient gptClient;

    /**
     * Gemini 모델용 ChatClient
     * - 글로벌 확장성 및 규제 분석에 사용
     */
    private final ChatClient geminiClient;

    /**
     * 병렬 실행을 위한 고정 스레드 풀
     * - 동시에 3개 작업 실행
     * - ForkJoinPool 대신 명시적 Executor 사용
     */
    private final ExecutorService executor = Executors.newFixedThreadPool(3);

    /**
     * 생성자 기반 의존성 주입
     *
     * @param llamaClient  LLaMA 모델 Bean
     * @param gptClient    GPT 모델 Bean
     * @param geminiClient Gemini 모델 Bean
     */
    public ParallelWorkflowService(
            @Qualifier("llama") ChatClient llamaClient,
            @Qualifier("gpt") ChatClient gptClient,
            @Qualifier("gemini") ChatClient geminiClient) {
        this.llamaClient = llamaClient;
        this.gptClient = gptClient;
        this.geminiClient = geminiClient;
    }

    /**
     * 분석 결과를 담는 DTO
     *
     * Lombok을 활용하여:
     * - getter/setter 자동 생성
     * - builder 패턴 지원
     * - 생성자 자동 생성
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AnalysisResult {

        /** 기술 분석 결과 */
        private String techAnalysis;

        /** 시장 분석 결과 */
        private String marketAnalysis;

        /** 글로벌 분석 결과 */
        private String globalAnalysis;

        /** 최종 종합 리포트 */
        private String finalReport;
    }

    /**
     * 병렬 워크플로우 실행 메서드
     *
     * 처리 흐름:
     * 1. 3개 모델을 병렬 실행
     * 2. 최대 130초 동안 완료 대기
     * 3. 결과 집계
     * 4. GPT로 최종 종합 보고서 생성
     *
     * @param rawIdea 사용자가 입력한 사업 아이디어
     * @return 분석 결과 DTO
     */
    public AnalysisResult executeParallelWorkflow(String rawIdea) {

        // ================================
        // 0️⃣ 워크플로우 시작 로그
        // ================================
        log.info("Workflow 시작: {}", rawIdea);

        // ================================
        // 1️⃣ 기술 분석 (LLaMA)
        // ================================
        CompletableFuture<String> techAnalysis =
                CompletableFuture.supplyAsync(() -> {

                            log.info("[기술 분석: LLAMA] 시작");

                            // LLaMA 모델 호출
                            String result = llamaClient.prompt()
                                    .system("기술적 구현 가능성을 분석하세요.")
                                    .user(rawIdea)
                                    .call()
                                    .content();

                            log.info("[기술 분석] 완료");
                            return result;

                        }, executor) // Executor 지정
                        .exceptionally(e -> {
                            // 개별 모델 실패 시 예외 처리
                            log.error("[기술 분석] 실패: {}", e.getMessage());
                            return "기술 분석 실패";
                        });

        // ================================
        // 2️⃣ 시장 분석 (GPT)
        // ================================
        CompletableFuture<String> marketAnalysis =
                CompletableFuture.supplyAsync(() -> {

                            log.info("[시장 분석:GPT] 시작");

                            String result = gptClient.prompt()
                                    .system("시장성 및 타겟 고객을 분석하세요.")
                                    .user(rawIdea)
                                    .call()
                                    .content();

                            log.info("[시장 분석] 완료");
                            return result;

                        }, executor)
                        .exceptionally(e -> {
                            log.error("[시장 분석] 실패: {}", e.getMessage());
                            return "시장 분석 실패";
                        });

        // ================================
        // 3️⃣ 글로벌 분석 (Gemini)
        // ================================
        CompletableFuture<String> globalAnalysis =
                CompletableFuture.supplyAsync(() -> {

                            log.info("[글로벌 분석:GEMINI] 시작");

                            String result = geminiClient.prompt()
                                    .system("글로벌 확장성 및 규제를 분석하세요.")
                                    .user(rawIdea)
                                    .call()
                                    .content();

                            log.info("[글로벌 분석] 완료");
                            return result;

                        }, executor)
                        .exceptionally(e -> {
                            log.error("[글로벌 분석] 실패: {}", e.getMessage());
                            return "글로벌 분석 실패";
                        });

        try {

            // ================================
            // 4️⃣ 모든 병렬 작업 완료 대기
            // - 최대 130초 제한
            // ================================
            CompletableFuture.allOf(
                    techAnalysis,
                    marketAnalysis,
                    globalAnalysis
            ).get(130, TimeUnit.SECONDS);

            // ================================
            // 5️⃣ 결과 수집
            // ================================
            String techResult = techAnalysis.getNow("기술 분석 미완료");
            String marketResult = marketAnalysis.getNow("시장 분석 미완료");
            String globalResult = globalAnalysis.getNow("글로벌 분석 미완료");

            log.info("모든 분석 완료, 결과 집계");

            // ================================
            // 6️⃣ 결과 통합 문자열 생성
            // ================================
            String combinedResults = String.format("""
                    [기술 분석]: %s
                    [시장 분석]: %s
                    [글로벌 분석]: %s
                    """, techResult, marketResult, globalResult);

            // ================================
            // 7️⃣ 최종 종합 보고서 생성 (GPT 사용)
            // ================================
            log.info("[최종 보고서] 작성 시작");

            String finalReport = gptClient.prompt()
                    .system("다음 세 가지 분석 결과를 바탕으로 최종 사업 전략 리포트를 작성하세요.")
                    .user(combinedResults)
                    .call()
                    .content();

            log.info("[최종 보고서] 작성 완료");

            log.info("[기술 분석] {}", techResult);
            log.info("[시장 분석] {}", marketResult);
            log.info("[글로벌 분석] {}", globalResult);

            log.info("[최종 보고서] {}", finalReport);

            // ================================
            // 8️⃣ DTO 반환
            // ================================
            return AnalysisResult.builder()
                    .techAnalysis(techResult)
                    .marketAnalysis(marketResult)
                    .globalAnalysis(globalResult)
                    .finalReport(finalReport)
                    .build();

        }
        // ================================
        // 타임아웃 발생 처리
        // ================================
        catch (TimeoutException te) {

            log.error("병렬 분석 타임아웃 발생: {}", te.getMessage());

            return AnalysisResult.builder()
                    .techAnalysis("타임아웃")
                    .marketAnalysis("타임아웃")
                    .globalAnalysis("타임아웃")
                    .finalReport("타임아웃으로 인해 최종 보고서 생성 실패")
                    .build();
        }
        // ================================
        // 기타 예외 처리
        // ================================
        catch (Exception e) {

            log.error("병렬 처리 중 오류 발생", e);

            return AnalysisResult.builder()
                    .techAnalysis("오류")
                    .marketAnalysis("오류")
                    .globalAnalysis("오류")
                    .finalReport("오류로 인해 최종 보고서 생성 실패")
                    .build();
        }
    }
}
