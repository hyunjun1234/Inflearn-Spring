package com.ai.chapter2.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.function.Supplier;

/**
 * ChainWorkflowService
 *
 * 여러 AI 모델을 체인(Chain) 구조로 연결하여
 * 1) 아이디어 분석 → 2) 마케팅 문구 생성 → 3) 비즈니스 톤 다듬기 및 번역
 * 의 워크플로우를 수행하는 서비스 클래스
 */
@Service // Spring Service Bean 등록
@Slf4j   // Lombok 로그 객체 자동 생성
public class ChainWorkflowService {

    /**
     * Llama 모델용 ChatClient
     * - 역할: 아이디어 분석 및 핵심 키워드 추출
     */
    private final ChatClient llamaClient;

    /**
     * GPT 모델용 ChatClient
     * - 역할: 키워드를 기반으로 마케팅 문구 작성
     */
    private final ChatClient gptClient;

    /**
     * Gemini 모델용 ChatClient
     * - 역할: 문구 검수 및 영어 번역
     */
    private final ChatClient geminiClient;

    /**
     * 생성자 주입 (Constructor Injection)
     * @Qualifier를 사용하여 각각의 모델 Bean을 구분하여 주입
     */
    public ChainWorkflowService(
            @Qualifier("llama") ChatClient llamaClient,
            @Qualifier("gpt") ChatClient gptClient,
            @Qualifier("gemini") ChatClient geminiClient) {
        this.llamaClient = llamaClient;
        this.gptClient = gptClient;
        this.geminiClient = geminiClient;
    }

    /**
     * 전체 AI 체인 워크플로우 실행 메서드
     *
     * @param rawIdea 사용자가 입력한 원본 아이디어
     * @return 최종 가공된 결과 문자열
     */
    public String executeWorkflow(String rawIdea) {

        // =========================
        // Step 1: Llama - 키워드 추출
        // =========================
        String keywords = callAI(() ->
                        llamaClient.prompt()
                                .system("사용자의 복잡한 아이디어를 분석하여 핵심 키워드 3개만 추출하세요.")
                                .user(rawIdea)
                                .call()
                                .content(),
                "Llama 분석");


        // =========================
        // Step 2: GPT - 홍보 문구 작성
        // =========================
        String marketingText = callAI(() ->
                        gptClient.prompt()
                                .system("제공된 키워드를 기반으로 블로그 포스팅용 홍보 문구를 한 문장으로 작성하세요.")
                                .user("키워드: " + keywords)
                                .call()
                                .content(),
                "GPT 문구 작성");


        // =========================
        // Step 3: Gemini - 검수 및 번역
        // =========================
        String finalResult = callAI(() ->
                        geminiClient.prompt()
                                .system("문구를 비즈니스 톤으로 다듬고, 영어 번역본을 함께 제공하세요.")
                                .user("대상 문구: " + marketingText)
                                .call()
                                .content(),
                "Gemini 검수/번역");


        // =========================
        // 최종 결과 반환
        // =========================
        return String.format("""
                [Workflow 완성]
                최종 결과: %s
                """, finalResult);
    }


    /**
     * 공통 AI 호출 메서드
     *
     * ✔ AI 모델 호출
     * ✔ 예외 처리
     * ✔ 결과 trim 처리
     * ✔ 단계별 로그 출력
     *
     * @param aiCall  실제 AI 호출 로직 (람다식으로 전달)
     * @param stepName 현재 단계 이름 (로그 및 예외 메시지용)
     * @return 정리된 AI 응답 문자열
     */
    private String callAI(Supplier<String> aiCall, String stepName) {
        try {
            // AI 호출 실행
            String result = aiCall.get();

            // null 체크 후 공백 제거
            if (result != null) {
                result = result.trim();
            }

            // 단계별 결과 로그 출력
            log.info("{} 결과: {}", stepName, result);

            return result;

        } catch (Exception e) {
            // 단계별 에러 로그 출력
            log.error("{} 단계에서 오류 발생", stepName, e);

            // 상위 계층으로 예외 전달
            throw new RuntimeException(stepName + " 단계 실패", e);
        }
    }
}
