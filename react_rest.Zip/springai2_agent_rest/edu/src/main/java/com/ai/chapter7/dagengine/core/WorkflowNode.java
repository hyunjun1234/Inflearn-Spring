package com.ai.chapter7.dagengine.core;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * WorkflowNode
 *
 * 📌 DAG의 실행 단위(노드) 인터페이스
 *
 * 계약:
 * - {@link #id()} — 로그·디버깅용 식별자. Chapter 7에서는 {@link com.ai.app.service.ch4.api.SubAgent#name()}
 *   과 동일한 값을 쓰는 노드가 있으며(예: {@code routing}, {@code report-evaluator}),
 *   레지스트리에 없는 단계는 {@code report-optimizer}, {@code merge-report} 처럼 짝을 맞춘 별도 id를 둡니다.
 * - {@link #execute(WorkflowContext, Executor)} — 비동기 실행; 블로킹 호출은
 *   {@link Executor}로 넘겨 호출 스레드(예: Tomcat)를 막지 않도록 함
 *
 * 구현체는 {@link WorkflowContext}를 읽고 갱신하며, 필요 시 {@link WorkflowContext#publish}로 단계 알림
 */
public interface WorkflowNode {

    /**
     * id
     *
     * 📌 워크플로 노드의 논리적 식별자입니다.
     *
     * 규칙:
     * - 가능하면 SubAgent/Tool 레지스트리 키와 동일한 값을 사용합니다
     *   (예: {@code routing}, {@code simple-query}, {@code report-evaluator}, {@code report-optimizer} 등).
     * - 로그, 모니터링, 디버깅 시 어떤 노드에서 에러가 났는지 구분하는 데 사용됩니다.
     *
     * @return 노드 식별자 문자열
     */
    String id();

    /**
     * execute
     *
     * 📌 주어진 {@link WorkflowContext}와 {@link Executor}를 사용해 노드를 비동기로 실행합니다.
     *
     * 계약:
     * - 블로킹 I/O나 LLM 호출은 반드시 전달받은 {@code executor} 위에서 수행해야 합니다.
     * - 실행 성공/실패/스킵 여부는 {@link NodeResult}로 표현하며,
     *   필요 시 {@link WorkflowContext}의 필드를 갱신하고 {@link WorkflowContext#publish(String, String)}로 상태를 발행합니다.
     *
     * @param ctx      DAG 실행 컨텍스트 (입력/중간 상태/발행기 포함)
     * @param executor 비동기 실행에 사용할 {@link Executor} (스레드 풀 등)
     * @return         실행 결과를 담은 {@link NodeResult}의 Future
     */
    CompletableFuture<NodeResult> execute(WorkflowContext ctx, Executor executor);
}
