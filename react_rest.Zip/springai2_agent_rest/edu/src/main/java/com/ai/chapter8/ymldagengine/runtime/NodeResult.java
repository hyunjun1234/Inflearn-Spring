package com.ai.chapter8.ymldagengine.runtime;

/**
 * NodeResult (ch8)
 *
 * 📌 Chapter 8 — YAML 엔진에서 사용하는 노드 실행 결과 DTO
 *
 * ch7의 {@code com.ai.app.service.ch7.engine.NodeResult} 를 독립적으로 복사한 형태입니다.
 */
public record NodeResult(boolean success, boolean skipped, String payload, String errorMessage) {

    /** 정상 완료 + 결과 문자열 */
    public static NodeResult ok(String payload) {
        return new NodeResult(true, false, payload, null);
    }

    /** 예외 또는 검증 실패 */
    public static NodeResult fail(String errorMessage) {
        return new NodeResult(false, false, null, errorMessage);
    }

    /**
     * 이 노드는 현재 분기에서 실행하지 않음
     */
    public static NodeResult notRun() {
        return new NodeResult(true, true, null, null);
    }
}

