package com.ai.chapter8.ymldagengine.definition;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * SnakeYAML 로 읽은 루트 맵을 {@link WorkflowDefinition}으로 변환합니다.
 * Chapter 8/9 로더가 공통으로 사용합니다.
 */
public final class WorkflowDefinitionMapper {

    private WorkflowDefinitionMapper() {
    }

    @SuppressWarnings("unchecked")
    public static WorkflowDefinition fromRawMap(Map<String, Object> raw) {
        String id = (String) raw.get("id");
        String description = (String) raw.getOrDefault("description", "");
        List<Map<String, Object>> rawNodes = (List<Map<String, Object>>) raw.get("nodes");
        List<WorkflowDefinition.NodeDefinition> nodes = new ArrayList<>();
        if (rawNodes != null) {
            for (Map<String, Object> n : rawNodes) {
                String nodeId = (String) n.get("id");
                String type = (String) n.get("type");
                String handler = (String) n.get("handler");
                List<String> dependsOn = (List<String>) n.get("dependsOn");
                String when = (String) n.get("when");
                Map<String, String> outputs = (Map<String, String>) n.get("outputs");
                Map<String, Object> config = (Map<String, Object>) n.get("config");
                nodes.add(new WorkflowDefinition.NodeDefinition(
                        nodeId, type, handler, dependsOn, when, outputs, config
                ));
            }
        }
        return new WorkflowDefinition(id, description, nodes);
    }
}
