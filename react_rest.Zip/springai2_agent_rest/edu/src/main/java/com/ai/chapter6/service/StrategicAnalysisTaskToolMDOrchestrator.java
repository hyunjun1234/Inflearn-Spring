package com.ai.chapter6.service;

import com.ai.shared.publisher.WorkflowStatusPublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * StrategicAnalysisTaskToolMDOrchestrator
 *
 * 📌 strategic-analysis-agent-system.md 를 system prompt 로 사용하는
 *    TaskTool 에이전트를 그대로 호출하는 간단한 오케스트레이터 예제입니다.
 *
 * - 기존 {@link StrategicAnalysisTaskToolOrchestrator} 가
 *   Java 코드에서 단계별 라우팅/병렬 분석/평가-개선을 직접 제어하는 반면,
 *   이 클래스는 대부분의 워크플로 플래닝을 에이전트(system md)에 맡깁니다.
 *
 * - HTTP / 컨트롤러에서는 이 오케스트레이터의 {@link #executeWithMonitoring(UUID, String)}
 *   메서드를 호출하는 것만으로, md 기반 전략 분석 파이프라인을 사용할 수 있습니다.
 *   (현재는 예제용으로만 추가되며, 컨트롤러 연결은 별도 작업입니다.)
 */
@Service
@Slf4j
public class StrategicAnalysisTaskToolMDOrchestrator {

    private final WorkflowStatusPublisher statusPublisher;
    private final ChatClient strategicAgentMd;

    /**
     * StrategicAnalysisTaskToolMDOrchestrator
     *
     * 📌 MD 기반 전략 분석용 ChatClient와 상태 퍼블리셔를 주입받는 생성자입니다.
     *
     * @param statusPublisher   SSE/Redis 상태 발행 컴포넌트
     * @param strategicAgentMd  {@code strategic-analysis-agent-system.md} 를 system prompt 로 사용하는 ChatClient
     */
    public StrategicAnalysisTaskToolMDOrchestrator(
            WorkflowStatusPublisher statusPublisher,
            @Qualifier("strategicAnalysisAgentMd") ChatClient strategicAgentMd) {
        this.statusPublisher = statusPublisher;
        this.strategicAgentMd = strategicAgentMd;
    }

    /**
     * md 기반 TaskTool 에이전트에 전체 입력을 넘기고,
     * 결과를 그대로 반환하는 가장 단순한 형태의 오케스트레이션입니다.
     *
     * - strategic-analysis-agent-system.md 안에서 routing/analysis/eval/optimize/TodoWrite 규칙을
     *   모두 정의하고 있다는 가정 하에, Java 쪽에서는 별도 단계 제어를 하지 않습니다.
     */
    public String executeWithMonitoring(UUID workflowId, String input) {
        publishStatus(workflowId, "START", "MD 기반 전략 분석을 시작합니다.");
        try {
            String result = strategicAgentMd.prompt()
                    .user(input)
                    .call()
                    .content();
            publishStatus(workflowId, "COMPLETED", "MD 기반 전략 분석이 완료되었습니다.");
            return result;
        } catch (Exception e) {
            log.error("[{}] MD 기반 전략 분석 실패", workflowId, e);
            publishStatus(workflowId, "ERROR", "MD 기반 전략 분석 중 오류가 발생했습니다.");
            return "MD 기반 전략 분석 중 오류가 발생했습니다.";
        }
    }

    /**
     * publishStatus
     *
     * 📌 MD 구성에서 사용되는 단순 상태 발행 헬퍼입니다.
     *
     * @param workflowId 워크플로우 추적용 UUID
     * @param step       단계 코드 (예: {@code START}, {@code COMPLETED}, {@code ERROR})
     * @param message    UI·운영자용 설명 메시지
     */
    private void publishStatus(UUID workflowId, String step, String message) {
        try {
            statusPublisher.publishStatus(workflowId, step, message);
        } catch (Exception ex) {
            log.warn("[{}] 상태 발행 실패(MD 구성)", workflowId, ex);
        }
    }
}

