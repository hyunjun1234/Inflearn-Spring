package com.ai.chapter3.service;

import com.ai.shared.publisher.WorkflowStatusPublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Supplier;
/**
 * PrecisionExecutionService
 *
 * 여러 AI 모델을 오케스트레이션하여
 * 1) 아이디어 구체화
 * 2) 작업 분할
 * 3) 코드/문서 병렬 생성
 * 4) 결과 취합
 * 을 수행하는 워크플로우 서비스
 *
 * 특징:
 * - 단계별 상태 모니터링 (Redis 등 외부 시스템 발행)
 * - 전용 ThreadPool 사용
 * - 안전한 예외 처리
 * - 단계별 로그 기록
 */
@Service
@Slf4j
public class PrecisionExecutionService {

    /**
     * GPT 기반 ChatClient
     * - Orchestrator 역할
     * - Code Worker 역할
     */
    private final ChatClient gptClient;

    /**
     * LLaMA 기반 ChatClient
     * - Refiner 역할 (아이디어 → SRS 변환)
     */
    private final ChatClient llamaClient;

    /**
     * Gemini 기반 ChatClient
     * - 문서 작성 Worker 역할
     */
    private final ChatClient geminiClient;

    /**
     * 워크플로우 상태를 외부 시스템(Redis 등)에 발행하는 퍼블리셔
     */
    private final WorkflowStatusPublisher statusPublisher;

    /**
     * 🧵 비동기 Worker·병렬 AI 호출용 스레드 풀 ({@link Executors#newFixedThreadPool(int)} — 크기 4).
     *
     * <p><b>사용 이유</b>
     * <ul>
     *   <li>공용 {@link java.util.concurrent.ForkJoinPool#commonPool()} 대신 명시적 풀을 써서
     *       병렬 AI 호출 시 <strong>동시 실행 개수를 고정</strong>하고 안정성을 확보한다.</li>
     *   <li>싱글톤 서비스에서 공유되면 <strong>모든 HTTP 요청이 동일 풀을 사용</strong>한다.</li>
     * </ul>
     *
     * <p><b>부하·확장</b>: 동시에 처리할 수 있는 양은 코드와 인프라에서 함께 정하고, 넘치면
     * 거절·대기·수평 확장(인스턴스 증설) 등으로 다루는 것이 일반적이다.
     * 이 고정 풀은 <strong>애플리케이션 내부 병렬 단계의 동시 실행 상한</strong>만 나타내며,
     * 큐 적체 방지·전역 동시 요청 제한·타임아웃 등은 별도 설계가 필요할 수 있다.
     */
    private final ExecutorService executor = Executors.newFixedThreadPool(4);

    /**
     * 생성자
     *
     * @param llamaClient   Refiner 모델
     * @param gptClient     Orchestrator + Code Worker 모델
     * @param geminiClient  문서 작성 Worker 모델
     * @param statusPublisher 상태 발행 컴포넌트
     */
    public PrecisionExecutionService(
            @Qualifier("llama") ChatClient llamaClient,
            @Qualifier("gpt") ChatClient gptClient,
            @Qualifier("gemini") ChatClient geminiClient,
            WorkflowStatusPublisher statusPublisher) {

        this.gptClient = gptClient;
        this.geminiClient = geminiClient;
        this.llamaClient = llamaClient;
        this.statusPublisher = statusPublisher;
    }

    /**
     * 모니터링이 포함된 워크플로우 실행 메서드
     *
     * @param workflowId 워크플로우 추적을 위한 UUID
     * @param rawIdea    사용자의 초기 아이디어
     * @return 코드 + 문서 결과 문자열
     */
    public String executeWithMonitoring(UUID workflowId, String rawIdea) {

        log.info("[{}] 워크플로우 시작: rawIdea={}", workflowId, rawIdea);

        try {

            // =========================================================
            // 1단계: Refiner (아이디어 → 요구사항 정의서 SRS 변환)
            // =========================================================
            publishStatus(workflowId, "Refining", "아이디어 구체화 시작");

            String refinedIdea = safeCall(() ->
                            llamaClient.prompt()
                                    .system("모호한 아이디어를 구체적인 요구사항 정의서(SRS)로 변환하세요.")
                                    .user(rawIdea)
                                    .call()
                                    .content(),
                    "Refining");

            // =========================================================
            // 2단계: Orchestrator (작업 분할)
            // 요구사항 기반으로 Worker_A, Worker_B 할당 정의
            // =========================================================
            publishStatus(workflowId, "Orchestrator", "작업 분할 시작");

            String tasks = safeCall(() ->
                            gptClient.prompt()
                                    .system("PM으로서 다음 요구사항을 해결하기 위한 Worker_A(코드), Worker_B(문서)의 할당량을 정하세요.")
                                    .user(refinedIdea)
                                    .call()
                                    .content(),
                    "Orchestrator");

            // =========================================================
            // 3단계: Workers 병렬 실행
            // Code Worker + Doc Worker 동시에 수행
            // =========================================================
            publishStatus(workflowId, "Workers", "하위 작업 수행 시작");

            // Code Worker 비동기 실행
            CompletableFuture<String> codeWorker =
                    CompletableFuture.supplyAsync(() ->
                                    safeCall(() ->
                                                    gptClient.prompt()
                                                            .system("코드를 작성하세요.")
                                                            .user(tasks)
                                                            .call()
                                                            .content(),
                                            "Code Worker"),
                            executor);

            // Doc Worker 비동기 실행
            CompletableFuture<String> docWorker =
                    CompletableFuture.supplyAsync(() ->
                                    safeCall(() ->
                                                    geminiClient.prompt()
                                                            .system("가이드 문서를 한글로 작성하세요.")
                                                            .user(tasks)
                                                            .call()
                                                            .content(),
                                            "Doc Worker"),
                            executor);

            // =========================================================
            // 4단계: Aggregation (결과 취합)
            // =========================================================
            publishStatus(workflowId, "Aggregation", "결과 취합 시작");

            // 모든 비동기 작업 완료 대기
            String codeResult = codeWorker.join();
            String docResult = docWorker.join();

            log.info("[{}] 워크플로우 완료", workflowId);
            publishStatus(workflowId, "COMPLETED", "결과 취합 완료");

            // 최종 결과 반환
            return String.format(
                    "--- 개발 코드 ---\n%s\n\n--- 사용 설명서 ---\n%s",
                    codeResult,
                    docResult
            );

        } catch (Exception ex) {

            // 전체 워크플로우 레벨 예외 처리
            log.error("[{}] 워크플로우 중 오류 발생: {}", workflowId, ex.getMessage(), ex);
            publishStatus(workflowId, "Error", ex.getMessage());

            return "워크플로우 실행 중 오류가 발생했습니다.";
        }
    }

    /**
     * AI API 호출을 안전하게 감싸는 공통 메서드
     *
     * @param supplier 실제 실행 로직
     * @param stage    현재 단계 이름
     * @return 결과 문자열 (실패 시 에러 메시지 포함)
     */
    private String safeCall(Supplier<String> supplier, String stage) {
        try {
            String result = supplier.get();

            log.info("[{}] 단계 완료: 결과 길이={}",
                    stage,
                    result != null ? result.length() : 0);

            return result;

        } catch (Exception ex) {

            log.error("[{}] 단계 실패: {}",
                    stage,
                    ex.getMessage(),
                    ex);

            return stage + " 단계에서 오류 발생: " + ex.getMessage();
        }
    }

    /**
     * 워크플로우 상태를 외부 시스템에 발행
     *
     * @param workflowId 워크플로우 식별자
     * @param step       현재 단계
     * @param message    상태 메시지
     */
    private void publishStatus(UUID workflowId, String step, String message) {

        log.info("[{}] 상태 업데이트: {} - {}",
                workflowId,
                step,
                message);

        try {
            statusPublisher.publishStatus(workflowId, step, message);
        } catch (Exception ex) {
            // 상태 발행 실패는 워크플로우를 중단시키지 않음
            log.warn("[{}] 상태 발행 실패: {}",
                    workflowId,
                    ex.getMessage(),
                    ex);
        }
    }

    /**
     * 애플리케이션 종료 시 ThreadPool 안전 종료
     */
    @PreDestroy
    public void shutdown() {
        log.info("ExecutorService 종료 중...");
        executor.shutdown();
    }
}
