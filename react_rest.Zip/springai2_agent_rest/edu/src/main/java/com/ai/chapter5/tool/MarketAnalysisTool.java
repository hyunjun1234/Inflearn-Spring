package com.ai.chapter5.tool;

import com.ai.chapter5.tool.api.StrategicTool;
import com.ai.shared.agent.api.SubAgentRegistry;
import com.ai.chapter5.service.StrategicAnalysisAgentToolOrchestrator;
import com.ai.chapter5.tool.registry.ToolRegistry;
import org.springframework.stereotype.Component;

/**
 * MarketAnalysisTool
 *
 * 📌 Chapter 5 — Tool-Orchestrated Multi-Agent 구조에서
 *     "시장/트렌드/Go-to-market 분석" 역할을 담당하는 StrategicTool 구현체입니다.
 *
 * 역할:
 * - {@link ToolRegistry} 에 이름 {@code "market-analysis"} 로 등록되어,
 *   메인 오케스트레이터({@link StrategicAnalysisAgentToolOrchestrator})가
 *   필요할 때 이름으로 조회해 호출합니다.
 * - 실제 LLM 호출은 {@link SubAgentRegistry} 를 통해
 *   같은 이름의 서브에이전트({@code strategic-market.md})에 위임합니다.
 *
 * 확장 포인트:
 * - 외부 API / Database / Vector Store(RAG)에서 수집한 시장 데이터·리포트를
 *   프롬프트에 포함하는 예시가 주석으로 포함되어 있어,
 *   ch5에서 "Tool + RAG/DB 연동" 패턴을 설명할 때 참고용으로 사용할 수 있습니다.
 */
@Component
public class MarketAnalysisTool implements StrategicTool {

    private static final String TOOL_NAME = "market-analysis";
    private final SubAgentRegistry subAgentRegistry;

    /**
     * MarketAnalysisTool
     *
     * 📌 시장/트렌드 분석 전용 StrategicTool 인스턴스를 생성합니다.
     *
     * @param subAgentRegistry 시장 분석 서브에이전트를 이름으로 조회하는 레지스트리
     */
    public MarketAnalysisTool(SubAgentRegistry subAgentRegistry) {
        this.subAgentRegistry = subAgentRegistry;
    }

    @Override
    public String name() {
        return TOOL_NAME;
    }

    @Override
    public String description() {
        return "시장/트렌드/Go-to-market 분석";
    }

    /**
     * 시장 분석 관점을 도구 단위로 정의하면, 나중에 RAG·외부 API로 입력만 붙여도
     * {@link #systemMessage()}와 함께 같은 계약으로 SubAgent를 호출할 수 있습니다.
     * 비즈니스 톤과 분석 축이 코드 한곳에 모여 있어 팀 간 공유·리뷰도 수월합니다.
     */
    @Override
    public String systemMessage() {
        return """
                당신은 시장 전략가입니다. 사용자 요청과 관련된 수요, 경쟁, 트렌드, 시장 진입(Go-to-market) 관점을 분석합니다. 사용자가 다른 언어로 쓰지 않았다면 한국어로 작성합니다.
                """;
    }

    /**
     * execute
     *
     * 📌 STRATEGIC 분기에서 시장·트렌드·Go-to-market 관점의 분석 초안을 생성합니다.
     *
     * 동작:
     * - {@link SubAgentRegistry}에서 {@code "market-analysis"} 서브에이전트를 조회해
     *   {@link #systemMessage()}와 함께 호출합니다.
     * - 출력은 기술 분석 결과와 함께 병합되어, 최종 전략 보고서의 시장 섹션을 구성합니다.
     *
     * @param input 사용자 프롬프트 또는 상위 단계에서 가공한 입력
     * @return      시장/트렌드 분석 결과 텍스트
     */
    @Override
    public String execute(String input) {
        return subAgentRegistry.require(name()).execute(input, systemMessage());
    }

    /*
     * 예시 1: 외부 데이터(API / Database)를 조회해서
     *      SubAgent에 전달하는 형태로 확장하고 싶다면
     *      아래와 같이 별도 메서드에서 데이터를 모으고,
     *      최종 프롬프트에 포함시키는 패턴으로 구현할 수 있습니다.
     *
     * // 가상의 외부 API / DB 클라이언트
     * private final MarketPriceClient marketPriceClient;
     * private final TrendRepository trendRepository;
     *
     * public String executeWithExternalData(String input) {
     *     // 1) 외부 API 호출 (예: 경쟁사 가격/프로모션 정보)
     *     ExternalPriceResponse priceInfo = marketPriceClient.fetchPrices(input);
     *
     *     // 2) DB 조회 (예: 내부 판매 실적·리텐션 지표)
     *     List<Trend> trends = trendRepository.findRecentTrends(input);
     *
     *     // 3) LLM에 전달할 통합 컨텍스트 구성
     *     String prompt = """
     *             [사용자 요청]
     *             %s
     *
     *             [외부 가격/프로모션 데이터]
     *             %s
     *
     *             [내부 트렌드/실적 데이터]
     *             %s
     *             """.formatted(
     *             input,
     *             priceInfo.toSummaryText(),
     *             trends.stream()
     *                     .map(Trend::toSummaryText)
     *                     .collect(Collectors.joining("\\n"))
     *     );
     *
     *     // 4) SubAgent를 통해 멀티-LLM 호출
     *     return subAgentRegistry.require(name()).execute(prompt, systemMessage());
     * }
     *
     *
     *
     *
     *
     *
     *
     *
     * 예시 2: Vector Store(RAG)를 이용해 관련 문서를 검색한 뒤,
     *      strategic-rag-search 서브에이전트에 넘기는 패턴도 사용할 수 있습니다.
     *
     * // 가상의 RAG 검색 서비스 (Spring AI VectorStore 기반)
     * private final RagSearchService ragSearchService;
     *
     * public String executeWithRag(String input) {
     *     // 1) Vector Store에서 관련 문서 검색
     *     String context = ragSearchService.searchAsContext(input);
     *
     *     // 2) SubAgent에 넘길 통합 프롬프트 구성
     *     String prompt = """
     *             [사용자 질문]
     *             %s
     *
     *             [검색된 시장/기술 문서 컨텍스트]
     *             %s
     *             """.formatted(input, context);
     *
     *     // 3) RAG 전용 서브에이전트 호출 (strategic-rag-search.md 의 name:)
     *     return subAgentRegistry.require("strategic-rag-search")
     *             .execute(prompt, systemMessage());
     * }
     */

}
