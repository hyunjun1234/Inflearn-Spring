package com.ai.shared.controller;

import com.ai.shared.web.ApiResponses;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ApiRootController {

    @GetMapping("/")
    public ResponseEntity<Map<String, Object>> root() {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("application", "edu");
        body.put("description", "REST API server (Thymeleaf 제거)");
        body.put("swaggerUi", "/swagger-ui.html");
        body.put("openApiJson", "/v3/api-docs");
        return ApiResponses.jsonOk(body);
    }
}
