package com.ai.chapter5.tool;

import com.ai.chapter5.tool.api.StrategicTool;
import com.ai.shared.agent.api.SubAgentRegistry;
import com.ai.chapter5.tool.registry.ToolRegistry;
import org.springframework.stereotype.Component;

/**
 * SimpleQueryTool
 *
 * 📌 Chapter 5 — routing 결과가 SIMPLE 일 때,
 *     라우팅/내부 워크플로를 노출하지 않고 간단한 최종 응답만 생성하는 StrategicTool.
 *
 * 역할:
 * - {@link ToolRegistry} 에 {@code "simple-query"} 이름으로 등록됩니다.
 * - 실제 응답 생성은 {@link SubAgentRegistry} 를 통해
 *   같은 이름의 서브에이전트({@code strategic-simple.md})에 위임합니다.
 */
@Component
public class SimpleQueryTool implements StrategicTool {

    private static final String TOOL_NAME = "simple-query";
    private final SubAgentRegistry subAgentRegistry;

    /**
     * SimpleQueryTool
     *
     * 📌 SIMPLE 분기에서 사용할 간단 응답용 Tool 인스턴스를 생성합니다.
     *
     * @param subAgentRegistry 라우팅·단순 응답 서브에이전트를 이름으로 조회하는 레지스트리
     */
    public SimpleQueryTool(SubAgentRegistry subAgentRegistry) {
        this.subAgentRegistry = subAgentRegistry;
    }

    @Override
    public String name() {
        return TOOL_NAME;
    }

    @Override
    public String description() {
        return "SIMPLE 분기의 단일 응답 생성";
    }

    /**
     * 간단 응답용 시스템 메시지를 도구로 묶으면 SIMPLE 경로만의 톤·금지 사항(내부 워크플로 비노출 등)을
     * 한 클래스에서 고정할 수 있습니다. 복잡한 STRATEGIC 파이프라인과 프롬프트가 섞이지 않아 유지보수와
     * 테스트가 쉬워집니다.
     */
    @Override
    public String systemMessage() {
        return """
                당신은 도움이 되는 어시스턴트입니다. 사용자 메시지에 명확하고 간결하게 답하세요. 라우팅이나 내부 워크플로는 언급하지 마세요.
                """;
    }

    /**
     * execute
     *
     * 📌 SIMPLE 경로에서 사용자 입력을 받아, 간단한 최종 응답을 생성합니다.
     *
     * 동작:
     * - {@link SubAgentRegistry}에서 {@code "simple-query"} 서브에이전트를 조회한 뒤,
     *   {@link #systemMessage()}와 함께 실행합니다.
     * - 오케스트레이터는 라우팅 결과에 따라 이 메서드를 한 번만 호출하며,
     *   내부 워크플로·라우팅 여부는 응답에 드러나지 않습니다.
     *
     * @param input 사용자 프롬프트
     * @return      단순 응답 텍스트
     */
    @Override
    public String execute(String input) {
        return subAgentRegistry.require(name()).execute(input, systemMessage());
    }

}
