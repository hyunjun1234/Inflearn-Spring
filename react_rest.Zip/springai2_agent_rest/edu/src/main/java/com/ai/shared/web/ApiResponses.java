package com.ai.shared.web;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

/**
 * 컨트롤러에서 공통 {@link ResponseEntity} 생성.
 */
public final class ApiResponses {

    private static final MediaType TEXT_PLAIN_UTF8 =
            MediaType.parseMediaType(MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8");

    public static ResponseEntity<String> textPlainOk(String body) {
        return ResponseEntity.ok().contentType(TEXT_PLAIN_UTF8).body(body);
    }

    public static <T> ResponseEntity<T> jsonOk(T body) {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(body);
    }

    private ApiResponses() {}
}
