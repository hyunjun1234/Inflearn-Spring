package com.ai.chapter9.controller;

import com.ai.chapter9.service.ValidatedYamlStrategicAnalysisWorkflowService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

/**
 * Chapter 9. Validated Agent Workflow DSL — REST 진입점.
 * <p>
 * (스키마·의존성 검증으로 신뢰하는 YAML 워크플로 DSL)
 * 엔진·DSL 어휘는 Ch8과 동일하고, {@code chapter9/dagworkflow/*.yml} 로딩 직후 {@code WorkflowDefinitionValidator} 통과분만 캐시하는 검증층이 본질.
 * classpath: {@code chapter9/dagworkflow/}
 *
 * <p>{@code POST /ch9/strategic-analysis}
 */
@RestController
@RequestMapping("/ch9")
@Slf4j
@RequiredArgsConstructor
public class Ch9Controller {

    private final ValidatedYamlStrategicAnalysisWorkflowService validatedYamlStrategicAnalysisWorkflowService;

    @PostMapping("/strategic-analysis")
    public String strategicAnalysis(
            @RequestParam("prompt") String userPrompt,
            @RequestParam String workflowId,
            @RequestParam(name = "workflowDefinition", defaultValue = "strategic-analysis") String workflowDefinitionId
    ) {
        UUID id = UUID.fromString(workflowId);
        log.info("Ch9 StrategicAnalysis (Validated Agent Workflow DSL) 요청: prompt={}, definition={}", userPrompt, workflowDefinitionId);
        return validatedYamlStrategicAnalysisWorkflowService.executeWithMonitoring(id, workflowDefinitionId, userPrompt);
    }
}
