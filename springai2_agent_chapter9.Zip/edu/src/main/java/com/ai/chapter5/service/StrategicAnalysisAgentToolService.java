package com.ai.chapter5.service;

import com.ai.shared.publisher.WorkflowStatusPublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * StrategicAnalysisAgentToolTaskService
 *
 * 📌 Chapter 5 — HTTP 진입·상태 래핑 전용 서비스 (Tool 오케스트레이션)
 *
 * 아키텍처 개요:
 * 1️⃣ 본 클래스 — STARTED/AGENT/COMPLETED/ERROR 발행
 * 2️⃣ {@link StrategicAnalysisAgentToolOrchestrator} — ToolRegistry 기반 단계 실행
 *
 * 특징:
 * - ch4 {@link StrategicAnalysisAgentService}와 동일한 책임 분리
 * - 비즈니스 로직은 오케스트레이터에만 두고, 여기서는 경계·누수 방지만 담당
 *
 */
@Service("ch5StrategicAnalysisAgentToolTaskService")
@Slf4j
@RequiredArgsConstructor
public class StrategicAnalysisAgentToolService {

    /** Tool 오케스트레이션 본체 */
    private final StrategicAnalysisAgentToolOrchestrator strategicAnalysisAgentToolOrchestrator;

    /** Redis/SSE 상태 발행 */
    private final WorkflowStatusPublisher statusPublisher;

    /**
     * executeWithMonitoring
     *
     * 📌 workflowId와 연동된 전략 분석 실행 (ch5 /ch5/strategic-analysis)
     *
     * @param workflowId 클라이언트 생성 UUID
     * @param input      사용자 입력
     * @return           최종 결과 문자열
     */
    public String executeWithMonitoring(UUID workflowId, String input) {
        publishStatus(workflowId, "STARTED", "Workflow started.");
        try {
            publishStatus(workflowId, "AGENT", "Java code workflow running...");
            String result = strategicAnalysisAgentToolOrchestrator.executeWithMonitoring(workflowId, input);
            publishStatus(workflowId, "COMPLETED", "Workflow completed");
            return result;
        } catch (Exception e) {
            log.error("[{}] Agent failed: {}", workflowId, e.getMessage(), e);
            publishStatus(workflowId, "ERROR", "Agent failed");
            return "Agent failed: " + e.getMessage();
        }
    }

    /**
     * publishStatus
     *
     * 📌 ch5 Tool 기반 전략 분석 워크플로의 현재 상태를 Redis Pub/Sub으로 발행하는 헬퍼 메서드입니다.
     *
     * 기능:
     * - HTTP 엔드포인트 호출 단위로 생성된 {@code workflowId}와 단계(step), 사람이 읽기 좋은 메시지를
     *   {@link WorkflowStatusPublisher}에 위임해 SSE 구독자에게 전달합니다.
     * - 상태 발행 실패는 워크플로 자체 실패로 보지 않고, 예외를 로깅 수준으로만 처리해 본 처리는 계속 진행합니다.
     *
     * @param workflowId 클라이언트·SSE와 매칭되는 추적용 UUID
     * @param step       예: {@code STARTED}, {@code AGENT}, {@code COMPLETED}, {@code ERROR}
     * @param message    UI 및 운영자용 상태 설명 메시지
     */
    private void publishStatus(UUID workflowId, String step, String message) {
        try {
            statusPublisher.publishStatus(workflowId, step, message);
        } catch (Exception ex) {
            log.warn("[{}] Status publish failed", workflowId, ex);
        }
    }
}
