package com.ai.chapter7.controller;

import com.ai.chapter7.dagengine.core.WorkflowContext;
import com.ai.chapter7.service.StrategicAnalysisDagWorkflowService;
import com.ai.chapter7.dagengine.core.DagWorkflowEngine;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

/**
 * Ch7Controller
 *
 * 📌 Chapter 7 — DAG Workflow ({@link DagWorkflowEngine}) 기반 전략 분석 REST API
 *
 * 역할:
 * - Chapter 4와 동일한 비즈니스(라우팅·병렬 분석·평가/개선)를
 *   노드 클래스로 쪼개 {@link DagWorkflowEngine}이 {@link java.util.concurrent.CompletableFuture}로 조립
 * - 화면/SSE는 ch4·ch6와 동일 패턴 ({@code pages/ch7/1_strategic_analysis})
 *
 * 엔드포인트:
 * - {@code POST /ch7/strategic-analysis}
 *
 * 요청:
 * - {@code prompt}, {@code workflowId} — ch4와 동일
 *
 * 응답:
 * - 최종 보고서 문자열 (서비스 내부에서 {@code CompletableFuture#join()}으로 동기 반환)
 */
@RestController
@RequestMapping("/ch7")
@Slf4j
@RequiredArgsConstructor
public class Ch7Controller {

    /**
     * DAG 실행 진입점 — {@link WorkflowContext} 생성 후 엔진에 위임
     */
    private final StrategicAnalysisDagWorkflowService strategicAnalysisDagWorkflowService;

    /**
     * strategic-analysis
     *
     * 📌 Router → (Simple | 병렬 Tech/Market → Merge → Eval/Optimize) 그래프 실행
     *
     * @param userPrompt  사용자 입력
     * @param workflowId  SSE·상태 추적용 UUID
     * @return 최종 보고서 또는 오류 메시지
     */
    @PostMapping("/strategic-analysis")
    public String strategicAnalysis(
            @RequestParam("prompt") String userPrompt,
            @RequestParam String workflowId
    ) {
        UUID id = UUID.fromString(workflowId);
        log.info("Ch7 StrategicAnalysis(DAG) 요청: {}", userPrompt);
        return strategicAnalysisDagWorkflowService.executeWithMonitoring(id, userPrompt);
    }
}
